// ============================================================================
// Name		: BackUpSeeker.cpp
// Date		: Jan 11, 2026
// ============================================================================


#if 0

//============================================================================
// Name        : Seeker.cpp
// Author      : Bhavesh Kale
// Version     : V1.0.0
// Date        : 11 Jan 2026
//============================================================================


// ---------- Includes ----------
#include <string>
#include <chrono>
#include <iostream>

#include <stdlib.h>
#include <unistd.h>

#include <opencv2/opencv.hpp>

extern "C" {
#include <libavutil/time.h>
#include "libavutil/avutil.h"
#include "libavutil/pixfmt.h"
#include "libavutil/imgutils.h"
#include "libswscale/swscale.h"
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libavdevice/avdevice.h"
}


// ---------- NameSpace ----------
using namespace cv;
using namespace std;
using namespace std::chrono;



// ---------- TypeDef ----------
typedef char					Int8_t;
typedef unsigned char			UInt8_t;

typedef short int				Int16_t;
typedef unsigned short int		UInt16_t;

typedef int						Int32_t;
typedef unsigned int			UInt32_t;

typedef long long int			Int64_t;
typedef unsigned long long int	UInt64_t;



// ---------- Class Declaration ----------
class Seeker
{
private:
	string VideoSrc;
	bool SeekerStatus;

	UInt8_t UseRtspTcp;
	UInt16_t Width, Height, VidFPS;

	AVDictionary *avdic;
	AVInputFormat *inpFormat;
	AVCodecContext *pCodecCtx;
	AVFormatContext *pFormatCtx;

	AVPacket *packet;
	AVFrame *pFrame, *pFrameBgr;

	const AVCodec *pCodec;
	struct SwsContext *imgConvertCtx;

	UInt8_t *outBuffer;
	Int32_t numBytes, videoStream;

public:
	// Default Constructor
	Seeker(void);

	// Parameterized Constructor
	Seeker(const string &VideoSrc);

	// Destructor
	~Seeker(void);

	// Get Seeker Status
	bool GetSeekerStatus(void);

	// Set Parameters
	UInt8_t SetParameters(UInt16_t Width, UInt16_t Height, UInt16_t VidFPS, UInt8_t UseRtspTcp);

	// Open Video Source
	UInt8_t Open(const string &VideoSrc);

	// Read Video Frame (Default Timeout 3000 Ms)
	UInt8_t Read(Mat &VideoFrame, UInt16_t TimeOutMs = 3000U);

	// Close Video Source
	void Close(void);

};


// ---------- Default Constructor ----------
Seeker :: Seeker(void)
{
	this->VideoSrc = "";
	SeekerStatus = false;

	UseRtspTcp = 0;
	Width = 640;
	Height = 480;
	VidFPS = 30;

	avdic = nullptr;
	inpFormat = nullptr;
	pCodecCtx = nullptr;
	pFormatCtx = nullptr;

	packet = nullptr;
	pFrame = nullptr;
	pFrameBgr = nullptr;

	pCodec = nullptr;
	imgConvertCtx = nullptr;

	outBuffer = nullptr;
	numBytes = 0;
	videoStream = -1;

	return;
}


// ---------- Parameterized Constructor ----------
Seeker :: Seeker(const string &VideoSrc)
{
	this->VideoSrc = "";
	SeekerStatus = false;

	UseRtspTcp = 0;
	Width = 640;
	Height = 480;
	VidFPS = 30;

	avdic = nullptr;
	inpFormat = nullptr;
	pCodecCtx = nullptr;
	pFormatCtx = nullptr;

	packet = nullptr;
	pFrame = nullptr;
	pFrameBgr = nullptr;

	pCodec = nullptr;
	imgConvertCtx = nullptr;

	outBuffer = nullptr;
	numBytes = 0;
	videoStream = -1;

	// Open Video Source
	Open(VideoSrc);

	return;
}


// ---------- Destructor ----------
Seeker :: ~Seeker(void)
{
	// Close Video Source
	Close();

	return;
}


// ---------- Get Seeker Status ----------
bool Seeker :: GetSeekerStatus(void)
{
	return SeekerStatus;
}


// ---------- Set Parameters ----------
UInt8_t Seeker :: SetParameters(UInt16_t Width, UInt16_t Height, UInt16_t VidFPS, UInt8_t UseRtspTcp)
{
	if(SeekerStatus == true)
	{
		cerr << "Error: " + VideoSrc + " is already opened!" << endl;
		return 1;
	}

	this->Width = Width;
	this->Height = Height;
	this->VidFPS = VidFPS;
	this->UseRtspTcp = UseRtspTcp;

	return 0;
}


// ---------- Open Video Source ----------
UInt8_t Seeker :: Open(const string &VideoSrc)
{
	if(SeekerStatus == true)
	{
		cerr << "Error: " + VideoSrc + " is already opened!" << endl;
		return 1;
	}

	this->VideoSrc = VideoSrc;

	avdevice_register_all();
	avformat_network_init();

	/*
	// Working Logic
    if(VideoSrc.find("rtsp://") == 0)
    {
    	av_dict_set(&avdic, "rtsp_transport", "tcp", 0);
    	// av_dict_set(&avdic, "rtsp_transport", "udp", 0);
		av_dict_set(&avdic, "max_delay", "0", 0);
		av_dict_set(&avdic, "stimeout", "3000000", 0);   // 3 sec connect
		av_dict_set(&avdic, "rw_timeout", "3000000", 0); // 3 sec read

        if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
        {
        	cerr << "Error: avformat_open_input failed for RTSP stream" << endl;
            return 2;
        }
    }
    else if(VideoSrc.find("udp://") == 0 || VideoSrc.find("tcp://") == 0 || VideoSrc.find("rtp://") == 0)
    {
        av_dict_set(&avdic, "protocol_whitelist", "file,udp,rtp,tcp", 0);
        av_dict_set(&avdic, "timeout", "5000000", 0);

        if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
        {
        	cerr << "Error: avformat_open_input failed for TCP/UDP/RTP stream" << endl;
        	return 2;
        }
    }
    else if(VideoSrc.find("http://") == 0 || VideoSrc.find("https://") == 0)
    {
        av_dict_set(&avdic, "reconnect", "1", 0);
        av_dict_set(&avdic, "reconnect_streamed", "1", 0);
        av_dict_set(&avdic, "reconnect_delay_max", "2", 0);

        if(avformat_open_input(&pFormatCtx,VideoSrc.c_str(), nullptr, &avdic) < 0)
        {
        	cerr << "Error: avformat_open_input failed for HTTP/HTTPS stream" << endl;
        	return 2;
        }
    }
    else if(VideoSrc.find("/dev/video") == 0)
    {
    	inpFormat = av_find_input_format("video4linux2");
        av_dict_set(&avdic, "video_size", (to_string(Width) + "x" + to_string(Height)).c_str(), 0);
        av_dict_set(&avdic, "framerate", to_string(VidFPS).c_str(), 0);

        if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), inpFormat, &avdic) < 0)
        {
        	cerr << "Error: avformat_open_input failed for video device" << endl;
        	return 2;
        }
    }
    else
    {
        if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, nullptr) < 0)
        {
        	cerr << "Error: avformat_open_input failed for video files" << endl;
        	return 2;
        }
    }

    */


	if(VideoSrc.find("rtsp://") == 0)
	{
		// Use UDP for RTSP
	    if(UseRtspTcp == 0)
	    {
	    	av_dict_set(&avdic, "rtsp_transport", "udp", 0);
			av_dict_set(&avdic, "stimeout", "3000000", 0);
			av_dict_set(&avdic, "max_delay", "0", 0);
			av_dict_set(&avdic, "buffer_size", "102400", 0);
			av_dict_set(&avdic, "fflags", "nobuffer", 0);
			av_dict_set(&avdic, "flags", "low_delay", 0);
	    }
	    // Use TCP for RTSP
	    else
	    {
	        av_dict_set(&avdic, "rtsp_transport", "tcp", 0);
	        av_dict_set(&avdic, "stimeout", "3000000", 0);
	        av_dict_set(&avdic, "rw_timeout", "3000000", 0);
	        av_dict_set(&avdic, "fflags", "nobuffer", 0);
	        av_dict_set(&avdic, "flags", "low_delay", 0);
	        av_dict_set(&avdic, "max_delay", "0", 0);
	    }

	    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
	    {
	        cerr << "Error: avformat_open_input failed for RTSP stream" << endl;
	        return 2;
	    }
	}
	else if(VideoSrc.find("udp://") == 0 || VideoSrc.find("tcp://") == 0 || VideoSrc.find("rtp://") == 0)
	{
	    av_dict_set(&avdic, "protocol_whitelist", "file,udp,rtp,tcp", 0);
	    av_dict_set(&avdic, "timeout", "3000000", 0);
	    av_dict_set(&avdic, "fflags", "nobuffer", 0);
	    av_dict_set(&avdic, "flags", "low_delay", 0);
	    av_dict_set(&avdic, "buffer_size", "102400", 0);

	    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
	    {
	        cerr << "Error: avformat_open_input failed for TCP/UDP/RTP stream" << endl;
	        return 2;
	    }
	}
	else if(VideoSrc.find("http://") == 0 || VideoSrc.find("https://") == 0)
	{
	    av_dict_set(&avdic, "reconnect", "1", 0);
	    av_dict_set(&avdic, "reconnect_streamed", "1", 0);
	    av_dict_set(&avdic, "reconnect_delay_max", "1", 0);
	    av_dict_set(&avdic, "fflags", "nobuffer", 0);
	    av_dict_set(&avdic, "flags", "low_delay", 0);

	    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
	    {
	        cerr << "Error: avformat_open_input failed for HTTP/HTTPS stream" << endl;
	        return 2;
	    }
	}
	else if(VideoSrc.find("/dev/video") == 0)
	{
	    inpFormat = av_find_input_format("video4linux2");
	    av_dict_set(&avdic, "video_size", (to_string(Width) + "x" + to_string(Height)).c_str(), 0);
	    av_dict_set(&avdic, "framerate", to_string(VidFPS).c_str(), 0);
	    av_dict_set(&avdic, "fflags", "nobuffer", 0);

	    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), inpFormat, &avdic) < 0)
	    {
	        cerr << "Error: avformat_open_input failed for video device" << endl;
	        return 2;
	    }
	}
	else
	{
	    av_dict_set(&avdic, "fflags", "nobuffer", 0);

	    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
	    {
	        cerr << "Error: avformat_open_input failed for video files" << endl;
	        return 2;
	    }
	}

	if(avformat_find_stream_info(pFormatCtx, nullptr) < 0)
	{
		cerr << "Error: avformat_find_stream_info failed" << endl;
		return 3;
	}

	for(UInt32_t i = 0; i < pFormatCtx->nb_streams; i++)
	{
		if(pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			videoStream = i;
			break;
		}
	}

	if(videoStream < 0)
	{
		cerr << "Error: video stream not found" << endl;
		return 4;
	}

	pCodec = avcodec_find_decoder(pFormatCtx->streams[videoStream]->codecpar->codec_id);
	if(!pCodec)
	{
		cerr << "Error: decoder not found" << endl;
		return 5;
	}

	pCodecCtx = avcodec_alloc_context3(pCodec);
	if(!pCodecCtx)
	{
		cerr << "Error: avcodec_alloc_context3 failed" << endl;
		return 6;
	}

	if(avcodec_parameters_to_context(pCodecCtx, pFormatCtx->streams[videoStream]->codecpar) < 0)
	{
		cerr << "Error: avcodec_parameters_to_context failed" << endl;
		return 7;
	}

	if(avcodec_open2(pCodecCtx,pCodec,nullptr) < 0)
	{
		cerr << "Error: avcodec_open2 failed" << endl;
		return 8;
	}

	pFrame = av_frame_alloc();
	pFrameBgr = av_frame_alloc();
	packet = av_packet_alloc();

	if(!pFrame || !pFrameBgr || !packet)
	{
		cerr << "Error: frame or packet allocation failed" << endl;
		return 9;
	}

	numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1);
	outBuffer = (UInt8_t *)av_malloc(numBytes);

	if(!outBuffer)
	{
		cerr << "Error: av_malloc failed" << endl;
		return 10;
	}

	av_image_fill_arrays(pFrameBgr->data, pFrameBgr->linesize, outBuffer, AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1);

	imgConvertCtx = sws_getContext(pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt, pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BILINEAR, nullptr, nullptr, nullptr);

	if(!imgConvertCtx)
	{
		cerr << "Error: sws_getContext failed" << endl;
		return 11;
	}

	SeekerStatus = true;
	return 0;
}


// ---------- Read Video Frame (Default Timeout 3000 Ms) ----------
UInt8_t Seeker :: Read(Mat &VideoFrame, UInt16_t TimeOutMs)
{
	steady_clock::time_point timCntStart;
	struct timespec ts;

	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 5;		// 5 microseconds

	if(SeekerStatus == false)
	{
		cerr << "Error: VideoSrc is not opened!" << endl;
		return 1;
	}

	timCntStart = steady_clock::now();

	while(true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		if(av_read_frame(pFormatCtx, packet) < 0)
		{
			if(duration_cast<milliseconds>(steady_clock::now() - timCntStart).count() > TimeOutMs)
			{
				cerr << "Error: End of Stream" << endl;
				av_packet_unref(packet);
				return 2;
			}

			continue;
		}

		if(packet->stream_index == videoStream &&
		   avcodec_send_packet(pCodecCtx, packet) == 0 &&
		   avcodec_receive_frame(pCodecCtx, pFrame) == 0)
		{
			sws_scale(imgConvertCtx, pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameBgr->data, pFrameBgr->linesize);
			VideoFrame = Mat(pCodecCtx->height, pCodecCtx->width, CV_8UC3, pFrameBgr->data[0], pFrameBgr->linesize[0]);
			break;
		}
		else
		{
			cerr << "Error: Failed to decode frames" << endl;
			av_packet_unref(packet);
			return 3;
		}
	}

	av_packet_unref(packet);
	return 0;
}


// ---------- Close Video Source ----------
void Seeker :: Close(void)
{
    if(pFrame)
    {
        av_frame_free(&pFrame);
        pFrame = nullptr;
    }

    if(pFrameBgr)
    {
        av_frame_free(&pFrameBgr);
        pFrameBgr = nullptr;
    }

    if(outBuffer)
    {
        av_free(outBuffer);
        outBuffer = nullptr;
    }

    if(imgConvertCtx)
    {
        sws_freeContext(imgConvertCtx);
        imgConvertCtx = nullptr;
    }

    if(pCodecCtx)
    {
        avcodec_free_context(&pCodecCtx);
        pCodecCtx = nullptr;
    }

    if(pFormatCtx)
    {
        avformat_close_input(&pFormatCtx);
        pFormatCtx = nullptr;
    }

    if(avdic)
    {
        av_dict_free(&avdic);
        avdic = nullptr;
    }

    VideoSrc = "";
    SeekerStatus = false;

    Width = 640;
	Height = 480;
	VidFPS = 30;

	numBytes = 0;
	videoStream = -1;

	return;
}


int main(int argc,char *argv[])
{
    if(argc < 2)
    {
        cout << "Usage: ./app <VideoSrc>\n";
        return -1;
    }

    Seeker seeker(argv[1]);
    if(seeker.GetSeekerStatus() == false)
    {
        cout << "Failed to open source\n";
        return -1;
    }

    namedWindow("Live Video",WINDOW_AUTOSIZE);
    Mat frame;

    while(true)
    {
    	frame.release();
        if(seeker.Read(frame, 0) == 0)
        {
            imshow("Live Video",frame);
            if(waitKey(40)=='q')
            {
                break;
            }
        }
    }

    seeker.Close();
    return 0;
}


#endif


