











#if 1

// --------------------------------- Code 3 -----------------------------
// Working lo latancy video redingh code
// ----------------------------------------------------------------------


#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>

extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavdevice/avdevice.h>
#include <libavutil/imgutils.h>
#include <libavutil/time.h>
#include <libswscale/swscale.h>
}

using namespace std;
using namespace cv;

/* ================= GLOBAL VARIABLES ================= */

AVFormatContext *fmt_ctx;
AVCodecContext *dec_ctx;
AVInputFormat *input_fmt;
AVDictionary *options;
AVCodec *decoder;
SwsContext *sws_ctx;

int video_stream_index;
string input_url;

/* ================= CONFIGURE FUNCTION ================= */

int configure_input(const string &url)
{
    fmt_ctx = nullptr;
    dec_ctx = nullptr;
    input_fmt = nullptr;
    options = nullptr;
    decoder = nullptr;
    sws_ctx = nullptr;
    video_stream_index = -1;
    input_url = url;

    avdevice_register_all();
    avformat_network_init();

    if(url.find("rtsp://") == 0)
    {
        av_dict_set(&options,"rtsp_transport","tcp",0);
        av_dict_set(&options,"stimeout","5000000",0);
        av_dict_set(&options,"max_delay","500000",0);
        if(avformat_open_input(&fmt_ctx,url.c_str(),nullptr,&options) < 0)
        {
            cerr << "ERROR: cannot open RTSP stream\n";
            return -1;
        }
    }
    else if(url.find("udp://") == 0 || url.find("tcp://") == 0 || url.find("rtp://") == 0)
    {
        av_dict_set(&options,"protocol_whitelist","file,udp,rtp,tcp",0);
        av_dict_set(&options,"timeout","5000000",0);
        if(avformat_open_input(&fmt_ctx,url.c_str(),nullptr,&options) < 0)
        {
            cerr << "ERROR: cannot open UDP/TCP stream\n";
            return -1;
        }
    }
    else if(url.find("http://") == 0 || url.find("https://") == 0)
    {
        av_dict_set(&options,"reconnect","1",0);
        av_dict_set(&options,"reconnect_streamed","1",0);
        av_dict_set(&options,"reconnect_delay_max","2",0);
        if(avformat_open_input(&fmt_ctx,url.c_str(),nullptr,&options) < 0)
        {
            cerr << "ERROR: cannot open HTTP/HTTPS stream\n";
            return -1;
        }
    }
    else if(url.find("/dev/video") == 0)
    {
        input_fmt = av_find_input_format("video4linux2");
        av_dict_set(&options,"video_size","640x480",0);
        av_dict_set(&options,"framerate","30",0);
        if(avformat_open_input(&fmt_ctx,url.c_str(),input_fmt,&options) < 0)
        {
            cerr << "ERROR: cannot open video device\n";
            return -1;
        }
    }
    else
    {
        if(avformat_open_input(&fmt_ctx,url.c_str(),nullptr,nullptr) < 0)
        {
            cerr << "ERROR: cannot open file\n";
            return -1;
        }
    }

    if(avformat_find_stream_info(fmt_ctx,nullptr) < 0)
    {
        cerr << "ERROR: cannot find stream info\n";
        return -1;
    }

    for(unsigned int i=0;i<fmt_ctx->nb_streams;i++)
    {
        if(fmt_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            video_stream_index = i;
            break;
        }
    }

    if(video_stream_index < 0)
    {
        cerr << "ERROR: no video stream found\n";
        return -1;
    }

    decoder = avcodec_find_decoder(fmt_ctx->streams[video_stream_index]->codecpar->codec_id);
    if(!decoder)
    {
        cerr << "ERROR: decoder not found\n";
        return -1;
    }

    dec_ctx = avcodec_alloc_context3(decoder);
    avcodec_parameters_to_context(dec_ctx,fmt_ctx->streams[video_stream_index]->codecpar);
    if(avcodec_open2(dec_ctx,decoder,nullptr) < 0)
    {
        cerr << "ERROR: decoder open failed\n";
        return -1;
    }

    sws_ctx = sws_getContext(dec_ctx->width,dec_ctx->height,dec_ctx->pix_fmt,
                             dec_ctx->width,dec_ctx->height,AV_PIX_FMT_BGR24,
                             SWS_BILINEAR,nullptr,nullptr,nullptr);
    if(!sws_ctx)
    {
        cerr << "ERROR: sws_getContext failed\n";
        return -1;
    }

    return 0;
}

/* ================= MAIN ================= */

int main(int argc,char *argv[])
{
    AVPacket packet;
    AVFrame *frame;
    AVFrame *bgr_frame;
    uint8_t *bgr_buffer;
    int bgr_size;
    Mat image;

    if(argc<2)
    {
        cout << "Usage: ./receiver <rtsp|udp|tcp|http|https|/dev/videoX|file>\n";
        return -1;
    }

    if(configure_input(argv[1]) < 0)
    {
        cout << "Input configuration failed\n";
        return -1;
    }

    frame = av_frame_alloc();
    bgr_frame = av_frame_alloc();

    bgr_size = av_image_get_buffer_size(AV_PIX_FMT_BGR24,dec_ctx->width,dec_ctx->height,1);
    bgr_buffer = (uint8_t*)av_malloc(bgr_size);
    av_image_fill_arrays(bgr_frame->data,bgr_frame->linesize,bgr_buffer,AV_PIX_FMT_BGR24,
                         dec_ctx->width,dec_ctx->height,1);

    image = Mat(dec_ctx->height,dec_ctx->width,CV_8UC3);
    namedWindow("Live Video",WINDOW_AUTOSIZE);

    while(true)
    {
        if(av_read_frame(fmt_ctx,&packet) < 0)
        {
            break;
        }

        if(packet.stream_index == video_stream_index)
        {
            if(avcodec_send_packet(dec_ctx,&packet) == 0)
            {
                while(avcodec_receive_frame(dec_ctx,frame) == 0)
                {
                    sws_scale(sws_ctx,frame->data,frame->linesize,0,dec_ctx->height,
                              bgr_frame->data,bgr_frame->linesize);
                    memcpy(image.data,bgr_frame->data[0],bgr_size);
                }
            }
        }

        imshow("Live Video",image);
        if(waitKey(1)=='q')
        {
            av_packet_unref(&packet);
            goto exit_loop;
        }

        av_packet_unref(&packet);
    }

exit_loop:
    av_free(bgr_buffer);
    av_frame_free(&frame);
    av_frame_free(&bgr_frame);
    sws_freeContext(sws_ctx);
    avcodec_free_context(&dec_ctx);
    avformat_close_input(&fmt_ctx);

    return 0;
}

#endif






















#if 0

// --------------------------------- Code 2 -----------------------------
// Working lo latancy video redingh code
// ----------------------------------------------------------------------




#include <iostream>
#include <string>

#include <opencv2/opencv.hpp>

extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavdevice/avdevice.h>
#include <libavutil/imgutils.h>
#include <libavutil/time.h>
#include <libswscale/swscale.h>
}

using namespace std;
using namespace cv;

/* ================= GLOBAL VARIABLES ================= */

AVFormatContext *fmt_ctx;
AVCodecContext *dec_ctx;
AVInputFormat *input_fmt;
AVDictionary *options;
AVCodec *decoder;
SwsContext *sws_ctx;

int video_stream_index;
string input_url;

/* ================= CONFIGURE FUNCTION ================= */

int configure_input(const string &url)
{
    fmt_ctx = nullptr;
    dec_ctx = nullptr;
    input_fmt = nullptr;
    options = nullptr;
    decoder = nullptr;
    sws_ctx = nullptr;
    video_stream_index = -1;
    input_url = url;

    avdevice_register_all();
    avformat_network_init();

    if(url.find("rtsp://") == 0)
    {
        av_dict_set(&options, "rtsp_transport", "udp", 0);
        av_dict_set(&options, "stimeout", "5000000", 0);
        av_dict_set(&options, "max_delay", "500000", 0);

        if(avformat_open_input(&fmt_ctx, url.c_str(), nullptr, &options) < 0)
        {
            cerr << "ERROR: cannot open RTSP stream\n";
            return -1;
        }
    }
    else if(url.find("rtp://") == 0)
    {
        av_dict_set(&options, "protocol_whitelist", "file,udp,rtp,tcp", 0);
        av_dict_set(&options, "timeout", "5000000", 0);

        if(avformat_open_input(&fmt_ctx, url.c_str(), nullptr, &options) < 0)
        {
            cerr << "ERROR: cannot open RTP stream\n";
            return -1;
        }
    }
    else if(url.find("http://") == 0 || url.find("https://") == 0)
    {
        av_dict_set(&options, "reconnect", "1", 0);
        av_dict_set(&options, "reconnect_streamed", "1", 0);
        av_dict_set(&options, "reconnect_delay_max", "2", 0);

        if (avformat_open_input(&fmt_ctx, url.c_str(), nullptr, &options) < 0)
        {
            cerr << "ERROR: cannot open HTTP/HTTPS stream\n";
            return -1;
        }
    }
    else if(url.find("/dev/video") == 0)
    {
        input_fmt = av_find_input_format("video4linux2");
        av_dict_set(&options, "video_size", "640x480", 0);
        av_dict_set(&options, "framerate", "30", 0);

        if(avformat_open_input(&fmt_ctx, url.c_str(), input_fmt, &options) < 0)
        {
            cerr << "ERROR: cannot open video device\n";
            return -1;
        }
    }
    else
    {
        if(avformat_open_input(&fmt_ctx, url.c_str(), nullptr, nullptr) < 0)
        {
            cerr << "ERROR: cannot open file\n";
            return -1;
        }
    }

    if(avformat_find_stream_info(fmt_ctx, nullptr) < 0)
    {
        cerr << "ERROR: cannot find stream info\n";
        return -1;
    }

    for(unsigned int i = 0; i < fmt_ctx->nb_streams; i++)
    {
        if(fmt_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            video_stream_index = i;
            break;
        }
    }

    if(video_stream_index < 0)
    {
        cerr << "ERROR: no video stream found\n";
        return -1;
    }

    decoder = avcodec_find_decoder(fmt_ctx->streams[video_stream_index]->codecpar->codec_id);

    if(!decoder)
    {
        cerr << "ERROR: decoder not found\n";
        return -1;
    }

    dec_ctx = avcodec_alloc_context3(decoder);
    avcodec_parameters_to_context(dec_ctx, fmt_ctx->streams[video_stream_index]->codecpar);

    if(avcodec_open2(dec_ctx, decoder, nullptr) < 0)
    {
        cerr << "ERROR: decoder open failed\n";
        return -1;
    }

    sws_ctx = sws_getContext(dec_ctx->width, dec_ctx->height, dec_ctx->pix_fmt,
                             dec_ctx->width, dec_ctx->height, AV_PIX_FMT_BGR24,
                             SWS_BILINEAR, nullptr, nullptr, nullptr);

    if(!sws_ctx)
    {
        cerr << "ERROR: sws_getContext failed\n";
        return -1;
    }

    return 0;
}

/* ================= MAIN ================= */

int main(int argc, char *argv[])
{
    AVPacket packet;
    AVFrame *frame;
    AVFrame *bgr_frame;

    uint8_t *bgr_buffer;
    int bgr_size;

    Mat image;

    if(argc < 2)
    {
        cout << "Usage: ./app <rtsp|rtp|http|https|/dev/videoX|file>\n";
        return -1;
    }

    if(configure_input(argv[1]) < 0)
    {
        cout << "Input configuration failed\n";
        return -1;
    }

    frame = av_frame_alloc();
    bgr_frame = av_frame_alloc();

    bgr_size = av_image_get_buffer_size(AV_PIX_FMT_BGR24, dec_ctx->width, dec_ctx->height, 1);
    bgr_buffer = (uint8_t *)av_malloc(bgr_size);

    av_image_fill_arrays(bgr_frame->data, bgr_frame->linesize, bgr_buffer, AV_PIX_FMT_BGR24,
                         dec_ctx->width, dec_ctx->height, 1);

    image = Mat(dec_ctx->height, dec_ctx->width, CV_8UC3);

    namedWindow("Live Video", WINDOW_AUTOSIZE);

    while(true)
    {
        if(av_read_frame(fmt_ctx, &packet) < 0)
        {
            break;
        }

        if(packet.stream_index == video_stream_index)
        {
            if(avcodec_send_packet(dec_ctx, &packet) == 0)
            {
                while(avcodec_receive_frame(dec_ctx, frame) == 0)
                {
                    sws_scale(sws_ctx, frame->data, frame->linesize, 0, dec_ctx->height,
                              bgr_frame->data, bgr_frame->linesize);
                    memcpy(image.data, bgr_frame->data[0], bgr_size);
                }
            }
        }

        imshow("Live Video", image);
        if(waitKey(1) == 'q')
        {
            av_packet_unref(&packet);
            goto exit_loop;
        }

        av_packet_unref(&packet);
    }

exit_loop:

    av_free(bgr_buffer);
    av_frame_free(&frame);
    av_frame_free(&bgr_frame);
    sws_freeContext(sws_ctx);
    avcodec_free_context(&dec_ctx);
    avformat_close_input(&fmt_ctx);

    return 0;
}

#endif























#if 0

// --------------------------------- Code 1 -----------------------------
// Working lo latancy video redingh code
// ----------------------------------------------------------------------


#include <iostream>
#include <string>

#include <opencv2/opencv.hpp>

extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavdevice/avdevice.h>
#include <libavutil/imgutils.h>
#include <libavutil/time.h>
#include <libswscale/swscale.h>
}

using namespace std;
using namespace cv;

/* ================= GLOBAL VARIABLES ================= */

AVFormatContext *fmt_ctx;
AVCodecContext *dec_ctx;
AVInputFormat *input_fmt;
AVDictionary *options;
AVCodec *decoder;
SwsContext *sws_ctx;

int video_stream_index;
string input_url;

/* ================= CONFIGURE FUNCTION ================= */

int configure_input(const string &url)
{
    fmt_ctx = nullptr;
    dec_ctx = nullptr;
    input_fmt = nullptr;
    options = nullptr;
    decoder = nullptr;
    sws_ctx = nullptr;
    video_stream_index = -1;
    input_url = url;

    avdevice_register_all();
    avformat_network_init();

    if(url.find("rtsp://") == 0 || url.find("rtp://") == 0)
    {
        av_dict_set(&options, "rtsp_transport", "udp", 0);
        av_dict_set(&options, "stimeout", "5000000", 0);
        av_dict_set(&options, "max_delay", "500000", 0);

//        av_dict_set(&options, "rtsp_transport", "tcp", 0);
//        av_dict_set(&options, "max_delay", "0", 0);

        if(avformat_open_input(&fmt_ctx, url.c_str(), nullptr, &options) < 0)
        {
            return -1;
        }
    }
    else if(url.find("http://") == 0 || url.find("https://") == 0)
    {
        av_dict_set(&options, "reconnect", "1", 0);
        av_dict_set(&options, "reconnect_streamed", "1", 0);
        av_dict_set(&options, "reconnect_delay_max", "2", 0);

        if (avformat_open_input(&fmt_ctx, url.c_str(), nullptr, &options) < 0)
        {
            return -1;
        }
    }
    else if(url.find("/dev/video") == 0)
    {
        input_fmt = av_find_input_format("video4linux2");
        av_dict_set(&options, "video_size", "640x480", 0);
        av_dict_set(&options, "framerate", "30", 0);

        if(avformat_open_input(&fmt_ctx, url.c_str(), input_fmt, &options) < 0)
        {
            return -1;
        }
    }
    else
    {
        if(avformat_open_input(&fmt_ctx, url.c_str(), nullptr, nullptr) < 0)
        {
            return -1;
        }
    }

    if(avformat_find_stream_info(fmt_ctx, nullptr) < 0)
    {
        return -1;
    }

    for(unsigned int i = 0; i < fmt_ctx->nb_streams; i++)
    {
        if(fmt_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            video_stream_index = i;
            break;
        }
    }

    if(video_stream_index < 0)
    {
        return -1;
    }

    decoder = avcodec_find_decoder(fmt_ctx->streams[video_stream_index]->codecpar->codec_id);

    if(!decoder)
    {
        return -1;
    }

    dec_ctx = avcodec_alloc_context3(decoder);
    avcodec_parameters_to_context(dec_ctx, fmt_ctx->streams[video_stream_index]->codecpar);

    if(avcodec_open2(dec_ctx, decoder, nullptr) < 0)
    {
        return -1;
    }

    sws_ctx = sws_getContext(dec_ctx->width, dec_ctx->height, dec_ctx->pix_fmt, dec_ctx->width, dec_ctx->height, AV_PIX_FMT_BGR24, SWS_BILINEAR, nullptr, nullptr, nullptr);

    if(!sws_ctx)
    {
        return -1;
    }

    return 0;
}

/* ================= MAIN ================= */

int main(int argc, char *argv[])
{
    AVPacket packet;
    AVFrame *frame;
    AVFrame *bgr_frame;

    uint8_t *bgr_buffer;
    int bgr_size;

    Mat image;

    if(argc < 2)
    {
        cout << "Usage: ./app <rtsp|rtp|http|https|/dev/videoX|file>\n";
        return -1;
    }

    if(configure_input(argv[1]) < 0)
    {
        cout << "Input configuration failed\n";
        return -1;
    }

    frame = av_frame_alloc();
    bgr_frame = av_frame_alloc();

    bgr_size = av_image_get_buffer_size(AV_PIX_FMT_BGR24, dec_ctx->width, dec_ctx->height, 1);
    bgr_buffer = (uint8_t *)av_malloc(bgr_size);

    av_image_fill_arrays(bgr_frame->data, bgr_frame->linesize, bgr_buffer, AV_PIX_FMT_BGR24, dec_ctx->width, dec_ctx->height, 1);

    image = Mat(dec_ctx->height, dec_ctx->width, CV_8UC3);

    while(true)
    {
        if(av_read_frame(fmt_ctx, &packet) < 0)
        {
            break;
        }

        if(packet.stream_index == video_stream_index)
        {
            if(avcodec_send_packet(dec_ctx, &packet) == 0)
            {
                while(avcodec_receive_frame(dec_ctx, frame) == 0)
                {
                    sws_scale(sws_ctx, frame->data, frame->linesize, 0, dec_ctx->height, bgr_frame->data, bgr_frame->linesize);
                    memcpy(image.data, bgr_frame->data[0], bgr_size);
                }
            }
        }

        imshow("Live Video", image);
		if(waitKey(1) == 'q')
		{
			av_packet_unref(&packet);
			goto exit_loop;
		}

        av_packet_unref(&packet);
    }

exit_loop:

    av_free(bgr_buffer);
    av_frame_free(&frame);
    av_frame_free(&bgr_frame);
    sws_freeContext(sws_ctx);
    avcodec_free_context(&dec_ctx);
    avformat_close_input(&fmt_ctx);

    return 0;
}


#endif
