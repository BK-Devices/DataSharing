// ============================================================================
// Name		: Working_1.1.cpp
// Date		: May 2, 2026
// ============================================================================



#if 0


#include <gst/gst.h>
#include <gst/rtsp-server/rtsp-server.h>
#include <gst/app/gstappsrc.h>

#include <opencv2/opencv.hpp>

#include <pthread.h>
#include <atomic>
#include <ctime>
#include <iostream>

using namespace std;

// --------------------------------------------------
// GLOBAL OBJECTS
// --------------------------------------------------

cv::VideoCapture cap;

cv::Mat StreamFrame;

std::atomic<bool> frameReady(false);

pthread_mutex_t frameMutex = PTHREAD_MUTEX_INITIALIZER;

GstElement *appsrc;

GstClockTime timestamp = 0;


// --------------------------------------------------
// WORK 1
// PUSH FRAME TO RTSP SERVER
// --------------------------------------------------

gboolean push_frame()
{

	// WORK 0
	// check if RTSP client connected

	if(appsrc == NULL)
	{
	    return TRUE;
	}


    cv::Mat localFrame;

    // WORK 1.1
    // copy frame safely from shared memory

    pthread_mutex_lock(&frameMutex);

    if(frameReady == false)
    {
        pthread_mutex_unlock(&frameMutex);
        return TRUE;
    }

    localFrame = StreamFrame.clone();

    frameReady = false;

    pthread_mutex_unlock(&frameMutex);


    // WORK 1.2
    // buffer creation

    int size = localFrame.total() * localFrame.elemSize();

    GstBuffer *buffer = gst_buffer_new_allocate(NULL , size , NULL);

    GstMapInfo map;

    gst_buffer_map(buffer , &map , GST_MAP_WRITE);

    memcpy(map.data , localFrame.data , size);

    gst_buffer_unmap(buffer , &map);


    // WORK 1.3
    // timestamp handling

    GST_BUFFER_PTS(buffer) = timestamp;

    GST_BUFFER_DTS(buffer) = timestamp;

    GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale_int(1 , GST_SECOND , 30);

    timestamp += GST_BUFFER_DURATION(buffer);


    // WORK 1.4
    // push buffer to RTSP pipeline

    gst_app_src_push_buffer(GST_APP_SRC(appsrc) , buffer);

    return TRUE;
}


// --------------------------------------------------
// THREAD FUNCTION
// WAIT FOR FRAME AND STREAM
// --------------------------------------------------

void* RtspThread(void *arg)
{

    // WORK 2.1
    // infinite streaming loop

    while(true)
    {

        if(frameReady == true)
        {
            push_frame();
        }

        // WORK 2.2
        // small delay

        usleep(1000);
    }

    return NULL;
}


// --------------------------------------------------
// RTSP MEDIA CONFIGURE
// --------------------------------------------------

static void media_configure(GstRTSPMediaFactory *factory , GstRTSPMedia *media , gpointer user_data)
{
    GstElement *element;

    element = gst_rtsp_media_get_element(media);

    appsrc = gst_bin_get_by_name_recurse_up(GST_BIN(element) , "mysrc");


    // WORK 3.1
    // configure appsrc

    g_object_set(G_OBJECT(appsrc),
                 "format", GST_FORMAT_TIME,
                 "is-live", TRUE,
                 "block", TRUE,
                 NULL);


    // WORK 3.2
    // set caps

    GstCaps *caps;

    caps = gst_caps_new_simple(
            "video/x-raw",
            "format", G_TYPE_STRING, "BGR",
            "width", G_TYPE_INT, 640,
            "height", G_TYPE_INT, 480,
            "framerate", GST_TYPE_FRACTION, 30, 1,
            NULL);

    gst_app_src_set_caps(GST_APP_SRC(appsrc) , caps);

    gst_caps_unref(caps);

    gst_object_unref(element);
}



// --------------------------------------------------
// MAIN
// --------------------------------------------------

int main(int argc , char *argv[])
{

    // WORK 4.1
    // initialize gstreamer

    gst_init(&argc , &argv);


    // WORK 4.2
    // open camera

    cap.open(0);

    if(cap.isOpened() == false)
    {
        cout << "Camera open failed\n";
        return -1;
    }


    // WORK 4.3
    // create RTSP server

    GstRTSPServer *server;

    GstRTSPMountPoints *mounts;

    GstRTSPMediaFactory *factory;

    server = gst_rtsp_server_new();

    mounts = gst_rtsp_server_get_mount_points(server);

    factory = gst_rtsp_media_factory_new();


    // WORK 4.4
    // pipeline launch

    gst_rtsp_media_factory_set_launch(factory,
    "( appsrc name=mysrc is-live=true block=true format=time "
    "! videoconvert "
    "! video/x-raw,format=I420 "
    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 "
    "! rtph264pay name=pay0 pt=96 )");


    // WORK 4.5
    // connect callback

    g_signal_connect(factory ,
                     "media-configure" ,
                     (GCallback)media_configure ,
                     NULL);


    gst_rtsp_mount_points_add_factory(mounts ,
                                      "/stream" ,
                                      factory);

    g_object_unref(mounts);


    gst_rtsp_server_attach(server , NULL);


    cout << "RTSP Stream Ready\n";

    cout << "rtsp://127.0.0.1:8554/stream\n";


    // WORK 4.6
    // start RTSP streaming thread

    pthread_t tid;

    pthread_create(&tid , NULL , RtspThread , NULL);


    // WORK 5
    // MAIN LOOP : CAMERA CAPTURE

    while(true)
    {

        cv::Mat frame;


        // WORK 5.1
        // capture frame

        cap.read(frame);

        if(frame.empty())
        {
            continue;
        }


        // WORK 5.2
        // resize frame

        cv::resize(frame , frame , cv::Size(640 , 480));


        // WORK 5.3
        // timestamp

        time_t now = time(0);

        char *dt = ctime(&now);

        cv::putText(frame ,
                    dt ,
                    cv::Point(20 , 40) ,
                    cv::FONT_HERSHEY_SIMPLEX ,
                    1 ,
                    cv::Scalar(0 , 255 , 0) ,
                    2);


        // WORK 5.4
        // display frame

        cv::imshow("Camera" , frame);

        char key = cv::waitKey(1);

        if(key == 'q')
        {
            std::cout<<"Stopping application"<<std::endl;
            cap.release();


            cv::destroyAllWindows();

            StreamFrame.release();


            break;
        }


        // WORK 5.5
        // store frame for streaming

        pthread_mutex_lock(&frameMutex);

        StreamFrame = frame.clone();

        frameReady = true;

        pthread_mutex_unlock(&frameMutex);

    }


    return 0;
}




#endif

