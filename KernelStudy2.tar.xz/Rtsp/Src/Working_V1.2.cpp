// ============================================================================
// Name		: Working_V1.2.cpp
// Date		: May 2, 2026
// ============================================================================



#if 0



#include <opencv2/opencv.hpp>
#include <gst/gst.h>
#include <gst/app/gstappsrc.h>
#include <gst/rtsp-server/rtsp-server.h>

#include <pthread.h>
#include <atomic>
#include <unistd.h>

using namespace std;

// --------------------------------------------------
// GLOBAL STREAM FRAMES
// --------------------------------------------------

cv::Mat StreamFrameBGR;
cv::Mat StreamFrameGRAY;

std::atomic<bool> frameReadyBGR(false);
std::atomic<bool> frameReadyGRAY(false);

pthread_mutex_t frameMutexBGR = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t frameMutexGRAY = PTHREAD_MUTEX_INITIALIZER;

GstElement *appsrc_bgr = NULL;
GstElement *appsrc_gray = NULL;

GstClockTime timestamp = 0;

// --------------------------------------------------
// BGR STREAM PUSH
// --------------------------------------------------

gboolean push_frame_bgr()
{

    if(appsrc_bgr == NULL)
        return TRUE;

    cv::Mat localFrame;

    pthread_mutex_lock(&frameMutexBGR);

    if(frameReadyBGR == false)
    {
        pthread_mutex_unlock(&frameMutexBGR);
        return TRUE;
    }

    localFrame = StreamFrameBGR.clone();

    frameReadyBGR = false;

    pthread_mutex_unlock(&frameMutexBGR);

    int size = localFrame.total() * localFrame.elemSize();

    GstBuffer *buffer = gst_buffer_new_allocate(NULL , size , NULL);

    GstMapInfo map;

    gst_buffer_map(buffer , &map , GST_MAP_WRITE);

    memcpy(map.data , localFrame.data , size);

    gst_buffer_unmap(buffer , &map);

    GST_BUFFER_PTS(buffer) = timestamp;
    GST_BUFFER_DTS(buffer) = timestamp;
    GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale_int(1 , GST_SECOND , 30);

    timestamp += GST_BUFFER_DURATION(buffer);

    gst_app_src_push_buffer(GST_APP_SRC(appsrc_bgr) , buffer);

    return TRUE;
}


// --------------------------------------------------
// GRAY STREAM PUSH
// --------------------------------------------------

gboolean push_frame_gray()
{

    if(appsrc_gray == NULL)
        return TRUE;

    cv::Mat localFrame;

    pthread_mutex_lock(&frameMutexGRAY);

    if(frameReadyGRAY == false)
    {
        pthread_mutex_unlock(&frameMutexGRAY);
        return TRUE;
    }

    localFrame = StreamFrameGRAY.clone();

    frameReadyGRAY = false;

    pthread_mutex_unlock(&frameMutexGRAY);

    int size = localFrame.total() * localFrame.elemSize();

    GstBuffer *buffer = gst_buffer_new_allocate(NULL , size , NULL);

    GstMapInfo map;

    gst_buffer_map(buffer , &map , GST_MAP_WRITE);

    memcpy(map.data , localFrame.data , size);

    gst_buffer_unmap(buffer , &map);

    GST_BUFFER_PTS(buffer) = timestamp;
    GST_BUFFER_DTS(buffer) = timestamp;
    GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale_int(1 , GST_SECOND , 30);

    timestamp += GST_BUFFER_DURATION(buffer);

    gst_app_src_push_buffer(GST_APP_SRC(appsrc_gray) , buffer);

    return TRUE;
}


// --------------------------------------------------
// THREAD BGR
// --------------------------------------------------

void* RtspThreadBGR(void *arg)
{

    while(true)
    {

        if(frameReadyBGR == true)
            push_frame_bgr();

        usleep(1000);
    }

    return NULL;
}


// --------------------------------------------------
// THREAD GRAY
// --------------------------------------------------

void* RtspThreadGRAY(void *arg)
{

    while(true)
    {

        if(frameReadyGRAY == true)
            push_frame_gray();

        usleep(1000);
    }

    return NULL;
}


// --------------------------------------------------
// MEDIA CONFIGURE BGR
// --------------------------------------------------

static void media_configure_bgr(GstRTSPMediaFactory *factory ,
                                GstRTSPMedia *media ,
                                gpointer user_data)
{

    GstElement *element;

    element = gst_rtsp_media_get_element(media);

    appsrc_bgr = gst_bin_get_by_name_recurse_up(GST_BIN(element) , "mysrc");

    g_object_set(G_OBJECT(appsrc_bgr),
                 "format", GST_FORMAT_TIME,
                 "is-live", TRUE,
                 "block", TRUE,
                 NULL);

    GstCaps *caps;

    caps = gst_caps_new_simple(
            "video/x-raw",
            "format", G_TYPE_STRING, "BGR",
            "width", G_TYPE_INT, 640,
            "height", G_TYPE_INT, 480,
            "framerate", GST_TYPE_FRACTION, 30, 1,
            NULL);

    gst_app_src_set_caps(GST_APP_SRC(appsrc_bgr) , caps);

    gst_caps_unref(caps);

    gst_object_unref(element);
}


// --------------------------------------------------
// MEDIA CONFIGURE GRAY
// --------------------------------------------------

static void media_configure_gray(GstRTSPMediaFactory *factory ,
                                 GstRTSPMedia *media ,
                                 gpointer user_data)
{

    GstElement *element;

    element = gst_rtsp_media_get_element(media);

    appsrc_gray = gst_bin_get_by_name_recurse_up(GST_BIN(element) , "mysrc");

    g_object_set(G_OBJECT(appsrc_gray),
                 "format", GST_FORMAT_TIME,
                 "is-live", TRUE,
                 "block", TRUE,
                 NULL);

    GstCaps *caps;

    caps = gst_caps_new_simple(
            "video/x-raw",
            "format", G_TYPE_STRING, "GRAY8",
            "width", G_TYPE_INT, 640,
            "height", G_TYPE_INT, 480,
            "framerate", GST_TYPE_FRACTION, 30, 1,
            NULL);

    gst_app_src_set_caps(GST_APP_SRC(appsrc_gray) , caps);

    gst_caps_unref(caps);

    gst_object_unref(element);
}



// --------------------------------------------------
// MAIN
// --------------------------------------------------

int main(int argc , char *argv[])
{

    gst_init(&argc , &argv);

    cv::VideoCapture cap(0);

    cap.set(cv::CAP_PROP_FRAME_WIDTH , 640);
    cap.set(cv::CAP_PROP_FRAME_HEIGHT , 480);

    if(!cap.isOpened())
    {
        cout<<"Camera open failed"<<endl;
        return -1;
    }

    // RTSP SERVER

    GstRTSPServer *server;
    GstRTSPMountPoints *mounts;

    server = gst_rtsp_server_new();

    gst_rtsp_server_set_service(server , "8555");

    mounts = gst_rtsp_server_get_mount_points(server);


    GstRTSPMediaFactory *factory_bgr;
    GstRTSPMediaFactory *factory_gray;

    factory_bgr = gst_rtsp_media_factory_new();
    factory_gray = gst_rtsp_media_factory_new();


    gst_rtsp_media_factory_set_launch(factory_bgr,
    "( appsrc name=mysrc is-live=true block=true format=time "
    "! videoconvert "
    "! video/x-raw,format=I420 "
    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 "
    "! rtph264pay name=pay0 pt=96 )");


    gst_rtsp_media_factory_set_launch(factory_gray,
    "( appsrc name=mysrc is-live=true block=true format=time "
    "! videoconvert "
    "! video/x-raw,format=I420 "
    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 "
    "! rtph264pay name=pay0 pt=96 )");


    g_signal_connect(factory_bgr , "media-configure" ,
                     (GCallback)media_configure_bgr , NULL);

    g_signal_connect(factory_gray , "media-configure" ,
                     (GCallback)media_configure_gray , NULL);


    gst_rtsp_mount_points_add_factory(mounts , "/bgr" , factory_bgr);
    gst_rtsp_mount_points_add_factory(mounts , "/gray" , factory_gray);

    gst_rtsp_server_attach(server , NULL);

    cout<<"RTSP Ready"<<endl;
    cout<<"rtsp://localhost:8555/bgr"<<endl;
    cout<<"rtsp://localhost:8555/gray"<<endl;


    // START THREADS

    pthread_t tid_bgr;
    pthread_t tid_gray;

    pthread_create(&tid_bgr , NULL , RtspThreadBGR , NULL);
    pthread_create(&tid_gray , NULL , RtspThreadGRAY , NULL);


    // CAMERA LOOP

    while(true)
    {

        cv::Mat frame;

        cap >> frame;

        if(frame.empty())
            continue;

        cv::resize(frame , frame , cv::Size(640 , 480));


        // save BGR

        pthread_mutex_lock(&frameMutexBGR);

        if(frameReadyBGR == false)
        {
            StreamFrameBGR = frame.clone();
            frameReadyBGR = true;
        }

        pthread_mutex_unlock(&frameMutexBGR);


        // convert to gray

        cv::Mat gray;

        cv::cvtColor(frame , gray , cv::COLOR_BGR2GRAY);


        pthread_mutex_lock(&frameMutexGRAY);

        if(frameReadyGRAY == false)
        {
            StreamFrameGRAY = gray.clone();
            frameReadyGRAY = true;
        }

        pthread_mutex_unlock(&frameMutexGRAY);


        cv::imshow("Camera" , frame);

        char key = cv::waitKey(1);

        if(key == 'q')
            break;
    }

    cap.release();
    cv::destroyAllWindows();

    return 0;
}




#endif

