#include <gst/gst.h>
#include <gst/rtsp-server/rtsp-server.h>
#include <gst/app/gstappsrc.h>

#include <opencv2/opencv.hpp>

#include <pthread.h>
#include <atomic>
#include <ctime>
#include <iostream>
#include <unistd.h>

using namespace std;


// --------------------------------------------------
// GLOBAL OBJECTS
// --------------------------------------------------

cv::VideoCapture cap;

cv::Mat StreamFrameBGR;
cv::Mat StreamFrameGRAY;

std::atomic<bool> frameReadyBGR(false);
std::atomic<bool> frameReadyGRAY(false);

pthread_mutex_t frameMutexBGR = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t frameMutexGRAY = PTHREAD_MUTEX_INITIALIZER;


// --------------------------------------------------
// GSTREAMER GLOBALS
// --------------------------------------------------

GstRTSPServer *server = NULL;
GstRTSPMountPoints *mounts = NULL;

GstElement *appsrc_bgr = NULL;
GstElement *appsrc_gray = NULL;

GstClockTime timestamp_bgr = 0;
GstClockTime timestamp_gray = 0;

bool grayStreamAdded = false;


// --------------------------------------------------
// ERROR HANDLING
// --------------------------------------------------

void CheckError(bool cond , const char* msg)
{
    if(cond == false)
    {
        cout<<"ERROR : "<<msg<<endl;
        exit(-1);
    }
}


// --------------------------------------------------
// CREATE GST BUFFER FROM FRAME
// --------------------------------------------------

GstBuffer* CreateBuffer(cv::Mat &frame , GstClockTime &timestamp)
{
    int size = frame.total() * frame.elemSize();

    GstBuffer *buffer = gst_buffer_new_allocate(NULL , size , NULL);

    GstMapInfo map;

    gst_buffer_map(buffer , &map , GST_MAP_WRITE);

    memcpy(map.data , frame.data , size);

    gst_buffer_unmap(buffer , &map);

    GST_BUFFER_PTS(buffer) = timestamp;
    GST_BUFFER_DTS(buffer) = timestamp;
    GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale_int(1 , GST_SECOND , 30);

    timestamp += GST_BUFFER_DURATION(buffer);

    return buffer;
}


// --------------------------------------------------
// BGR STREAM PUSH
// --------------------------------------------------

gboolean push_frame_bgr()
{

    if(appsrc_bgr == NULL)
        return TRUE;

    cv::Mat localFrame;

    pthread_mutex_lock(&frameMutexBGR);

    if(frameReadyBGR == false)
    {
        pthread_mutex_unlock(&frameMutexBGR);
        return TRUE;
    }

    localFrame = StreamFrameBGR.clone();

    frameReadyBGR = false;

    pthread_mutex_unlock(&frameMutexBGR);


    GstBuffer *buffer = CreateBuffer(localFrame , timestamp_bgr);

    gst_app_src_push_buffer(GST_APP_SRC(appsrc_bgr) , buffer);

    return TRUE;
}


// --------------------------------------------------
// GRAY STREAM PUSH
// --------------------------------------------------

gboolean push_frame_gray()
{

    if(appsrc_gray == NULL)
        return TRUE;

    cv::Mat localFrame;

    pthread_mutex_lock(&frameMutexGRAY);

    if(frameReadyGRAY == false)
    {
        pthread_mutex_unlock(&frameMutexGRAY);
        return TRUE;
    }

    localFrame = StreamFrameGRAY.clone();

    frameReadyGRAY = false;

    pthread_mutex_unlock(&frameMutexGRAY);

    GstBuffer *buffer = CreateBuffer(localFrame , timestamp_gray);

    gst_app_src_push_buffer(GST_APP_SRC(appsrc_gray) , buffer);

    return TRUE;
}


// --------------------------------------------------
// THREAD BGR STREAM
// --------------------------------------------------

void* RtspThreadBGR(void *arg)
{

    while(true)
    {

        if(frameReadyBGR == true)
        {
            push_frame_bgr();
        }

        usleep(1000);
    }

    return NULL;
}


// --------------------------------------------------
// THREAD GRAY STREAM
// --------------------------------------------------

void* RtspThreadGRAY(void *arg)
{

    while(true)
    {

        if(frameReadyGRAY == true)
        {
            push_frame_gray();
        }

        usleep(1000);
    }

    return NULL;
}


// --------------------------------------------------
// MEDIA CONFIGURE BGR
// --------------------------------------------------

static void media_configure_bgr(GstRTSPMediaFactory *factory , GstRTSPMedia *media , gpointer user_data)
{

    GstElement *element;

    element = gst_rtsp_media_get_element(media);

    appsrc_bgr = gst_bin_get_by_name_recurse_up(GST_BIN(element) , "mysrc");

    CheckError(appsrc_bgr != NULL , "BGR appsrc not found");


    g_object_set(G_OBJECT(appsrc_bgr),
                 "format", GST_FORMAT_TIME,
                 "is-live", TRUE,
                 "block", TRUE,
                 "do-timestamp", TRUE,
                 NULL);


    GstCaps *caps;

    caps = gst_caps_new_simple(
            "video/x-raw",
            "format", G_TYPE_STRING, "BGR",
            "width", G_TYPE_INT, 640,
            "height", G_TYPE_INT, 480,
            "framerate", GST_TYPE_FRACTION, 30, 1,
            NULL);

    gst_app_src_set_caps(GST_APP_SRC(appsrc_bgr) , caps);

    gst_caps_unref(caps);

    gst_object_unref(element);
}


// --------------------------------------------------
// MEDIA CONFIGURE GRAY
// --------------------------------------------------

static void media_configure_gray(GstRTSPMediaFactory *factory , GstRTSPMedia *media , gpointer user_data)
{

    GstElement *element;

    element = gst_rtsp_media_get_element(media);

    appsrc_gray = gst_bin_get_by_name_recurse_up(GST_BIN(element) , "mysrc");

    CheckError(appsrc_gray != NULL , "GRAY appsrc not found");


    g_object_set(G_OBJECT(appsrc_gray),
                 "format", GST_FORMAT_TIME,
                 "is-live", TRUE,
                 "block", TRUE,
                 "do-timestamp", TRUE,
                 NULL);


    GstCaps *caps;

    caps = gst_caps_new_simple(
            "video/x-raw",
            "format", G_TYPE_STRING, "GRAY8",
            "width", G_TYPE_INT, 640,
            "height", G_TYPE_INT, 480,
            "framerate", GST_TYPE_FRACTION, 30, 1,
            NULL);

    gst_app_src_set_caps(GST_APP_SRC(appsrc_gray) , caps);

    gst_caps_unref(caps);

    gst_object_unref(element);
}


// --------------------------------------------------
// CREATE STREAM FACTORY
// --------------------------------------------------

GstRTSPMediaFactory* CreateFactory(const char* pipeline , GCallback callback)
{

    GstRTSPMediaFactory *factory;

    factory = gst_rtsp_media_factory_new();

    CheckError(factory != NULL , "Factory creation failed");

    gst_rtsp_media_factory_set_launch(factory , pipeline);

    gst_rtsp_media_factory_set_shared(factory , TRUE);

    g_signal_connect(factory , "media-configure" , callback , NULL);

    return factory;
}


// --------------------------------------------------
// ADD BGR STREAM
// --------------------------------------------------

void AddBGRStream()
{

    const char *pipeline =
    "( appsrc name=mysrc is-live=true block=true format=time "
    "! videoconvert "
    "! video/x-raw,format=I420 "
    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 intra-refresh=true "
    "! rtph264pay name=pay0 pt=96 config-interval=1 )";

    GstRTSPMediaFactory *factory;

    factory = CreateFactory(pipeline , (GCallback)media_configure_bgr);

    gst_rtsp_mount_points_add_factory(mounts , "/bgr" , factory);

    cout<<"BGR stream ready"<<endl;
}


// --------------------------------------------------
// ADD GRAY STREAM (DYNAMIC)
// --------------------------------------------------

void AddGrayStream()
{

    if(grayStreamAdded)
    {
        cout<<"GRAY stream already running"<<endl;
        return;
    }

    const char *pipeline =
    "( appsrc name=mysrc is-live=true block=true format=time "
    "! videoconvert "
    "! video/x-raw,format=I420 "
    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 intra-refresh=true "
    "! rtph264pay name=pay0 pt=96 config-interval=1 )";

    GstRTSPMediaFactory *factory;

    factory = CreateFactory(pipeline , (GCallback)media_configure_gray);

    gst_rtsp_mount_points_add_factory(mounts , "/gray" , factory);

    grayStreamAdded = true;

    cout<<"GRAY stream dynamically added"<<endl;
}


// --------------------------------------------------
// MAIN
// --------------------------------------------------

int main(int argc , char *argv[])
{

    gst_init(&argc , &argv);


    cap.open(0);

    CheckError(cap.isOpened() , "Camera open failed");


    server = gst_rtsp_server_new();

    mounts = gst_rtsp_server_get_mount_points(server);


    gst_rtsp_server_set_service(server , "8555");


    AddBGRStream();


    gst_rtsp_server_attach(server , NULL);


    cout<<"RTSP SERVER STARTED"<<endl;
    cout<<"rtsp://127.0.0.1:8555/bgr"<<endl;


    pthread_t tid_bgr;
    pthread_t tid_gray;

    pthread_create(&tid_bgr , NULL , RtspThreadBGR , NULL);
    pthread_create(&tid_gray , NULL , RtspThreadGRAY , NULL);


    while(true)
    {

        cv::Mat frame;

        cap.read(frame);

        if(frame.empty())
            continue;


        cv::resize(frame , frame , cv::Size(640 , 480));


        time_t now = time(0);

        char *dt = ctime(&now);

        cv::putText(frame ,
                    dt ,
                    cv::Point(20 , 40) ,
                    cv::FONT_HERSHEY_SIMPLEX ,
                    1 ,
                    cv::Scalar(0 , 255 , 0) ,
                    2);


        cv::imshow("Camera" , frame);

        char key = cv::waitKey(1);


        if(key == 'g')
        {
            AddGrayStream();
            cout<<"rtsp://127.0.0.1:8555/gray"<<endl;
        }


        if(key == 'q')
        {

            cout<<"Stopping application"<<endl;

            cap.release();

            cv::destroyAllWindows();

            break;
        }


        pthread_mutex_lock(&frameMutexBGR);

        if(frameReadyBGR == false)
        {
            StreamFrameBGR = frame.clone();
            frameReadyBGR = true;
        }

        pthread_mutex_unlock(&frameMutexBGR);


        cv::Mat gray;

        cv::cvtColor(frame , gray , cv::COLOR_BGR2GRAY);


        pthread_mutex_lock(&frameMutexGRAY);

        if(frameReadyGRAY == false)
        {
            StreamFrameGRAY = gray.clone();
            frameReadyGRAY = true;
        }

        pthread_mutex_unlock(&frameMutexGRAY);

    }

    return 0;
}







































#if 0


#include <gst/gst.h>
#include <gst/rtsp-server/rtsp-server.h>
#include <gst/app/gstappsrc.h>

#include <opencv2/opencv.hpp>

#include <pthread.h>
#include <atomic>
#include <ctime>
#include <iostream>
#include <unistd.h>

using namespace std;


// --------------------------------------------------
// GLOBAL OBJECTS
// --------------------------------------------------

cv::VideoCapture cap;

cv::Mat StreamFrameBGR;
cv::Mat StreamFrameGRAY;

std::atomic<bool> frameReadyBGR(false);
std::atomic<bool> frameReadyGRAY(false);

pthread_mutex_t frameMutexBGR = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t frameMutexGRAY = PTHREAD_MUTEX_INITIALIZER;


// --------------------------------------------------
// GSTREAMER GLOBALS
// --------------------------------------------------

GstRTSPServer *server = NULL;
GstRTSPMountPoints *mounts = NULL;

GstElement *appsrc_bgr = NULL;
GstElement *appsrc_gray = NULL;

GstClockTime timestamp = 0;


// --------------------------------------------------
// ERROR HANDLING
// --------------------------------------------------

void CheckError(bool cond , const char* msg)
{
    if(cond == false)
    {
        cout<<"ERROR : "<<msg<<endl;
        exit(-1);
    }
}


// --------------------------------------------------
// CREATE GST BUFFER FROM FRAME
// --------------------------------------------------

GstBuffer* CreateBuffer(cv::Mat &frame)
{
    int size = frame.total() * frame.elemSize();

    GstBuffer *buffer = gst_buffer_new_allocate(NULL , size , NULL);

    GstMapInfo map;

    gst_buffer_map(buffer , &map , GST_MAP_WRITE);

    memcpy(map.data , frame.data , size);

    gst_buffer_unmap(buffer , &map);

    GST_BUFFER_PTS(buffer) = timestamp;
    GST_BUFFER_DTS(buffer) = timestamp;
    GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale_int(1 , GST_SECOND , 30);

    timestamp += GST_BUFFER_DURATION(buffer);

    return buffer;
}


// --------------------------------------------------
// BGR STREAM PUSH
// --------------------------------------------------

gboolean push_frame_bgr()
{

    if(appsrc_bgr == NULL)
        return TRUE;

    cv::Mat localFrame;

    pthread_mutex_lock(&frameMutexBGR);

    if(frameReadyBGR == false)
    {
        pthread_mutex_unlock(&frameMutexBGR);
        return TRUE;
    }

    localFrame = StreamFrameBGR.clone();

    frameReadyBGR = false;

    pthread_mutex_unlock(&frameMutexBGR);


    GstBuffer *buffer = CreateBuffer(localFrame);

    gst_app_src_push_buffer(GST_APP_SRC(appsrc_bgr) , buffer);

    return TRUE;
}


// --------------------------------------------------
// GRAY STREAM PUSH
// --------------------------------------------------

gboolean push_frame_gray()
{

    if(appsrc_gray == NULL)
        return TRUE;

    cv::Mat localFrame;

    pthread_mutex_lock(&frameMutexGRAY);

    if(frameReadyGRAY == false)
    {
        pthread_mutex_unlock(&frameMutexGRAY);
        return TRUE;
    }

    localFrame = StreamFrameGRAY.clone();

    frameReadyGRAY = false;

    pthread_mutex_unlock(&frameMutexGRAY);

    GstBuffer *buffer = CreateBuffer(localFrame);

    gst_app_src_push_buffer(GST_APP_SRC(appsrc_gray) , buffer);

    return TRUE;
}


// --------------------------------------------------
// THREAD BGR STREAM
// --------------------------------------------------

void* RtspThreadBGR(void *arg)
{

    while(true)
    {

        if(frameReadyBGR == true)
        {
            push_frame_bgr();
        }

        usleep(1000);
    }

    return NULL;
}


// --------------------------------------------------
// THREAD GRAY STREAM
// --------------------------------------------------

void* RtspThreadGRAY(void *arg)
{

    while(true)
    {

        if(frameReadyGRAY == true)
        {
            push_frame_gray();
        }

        usleep(1000);
    }

    return NULL;
}


// --------------------------------------------------
// MEDIA CONFIGURE BGR
// --------------------------------------------------

static void media_configure_bgr(GstRTSPMediaFactory *factory , GstRTSPMedia *media , gpointer user_data)
{

    GstElement *element;

    element = gst_rtsp_media_get_element(media);

    appsrc_bgr = gst_bin_get_by_name_recurse_up(GST_BIN(element) , "mysrc");


    g_object_set(G_OBJECT(appsrc_bgr),
                 "format", GST_FORMAT_TIME,
                 "is-live", TRUE,
                 "block", TRUE,
                 NULL);


    GstCaps *caps;

    caps = gst_caps_new_simple(
            "video/x-raw",
            "format", G_TYPE_STRING, "BGR",
            "width", G_TYPE_INT, 640,
            "height", G_TYPE_INT, 480,
            "framerate", GST_TYPE_FRACTION, 30, 1,
            NULL);

    gst_app_src_set_caps(GST_APP_SRC(appsrc_bgr) , caps);

    gst_caps_unref(caps);

    gst_object_unref(element);
}


// --------------------------------------------------
// MEDIA CONFIGURE GRAY
// --------------------------------------------------

static void media_configure_gray(GstRTSPMediaFactory *factory , GstRTSPMedia *media , gpointer user_data)
{

    GstElement *element;

    element = gst_rtsp_media_get_element(media);

    appsrc_gray = gst_bin_get_by_name_recurse_up(GST_BIN(element) , "mysrc");


    g_object_set(G_OBJECT(appsrc_gray),
                 "format", GST_FORMAT_TIME,
                 "is-live", TRUE,
                 "block", TRUE,
                 NULL);


    GstCaps *caps;

    caps = gst_caps_new_simple(
            "video/x-raw",
            "format", G_TYPE_STRING, "GRAY8",
            "width", G_TYPE_INT, 640,
            "height", G_TYPE_INT, 480,
            "framerate", GST_TYPE_FRACTION, 30, 1,
            NULL);

    gst_app_src_set_caps(GST_APP_SRC(appsrc_gray) , caps);

    gst_caps_unref(caps);

    gst_object_unref(element);
}


// --------------------------------------------------
// CREATE STREAM FACTORY
// --------------------------------------------------

//GstRTSPMediaFactory* CreateFactory(const char* pipeline , GCallback callback)
//{
//
//    GstRTSPMediaFactory *factory;
//
//    factory = gst_rtsp_media_factory_new();
//
//    gst_rtsp_media_factory_set_launch(factory , pipeline);
//
//    g_signal_connect(factory , "media-configure" , callback , NULL);
//
//    return factory;
//}


GstRTSPMediaFactory* CreateFactory(const char* pipeline , GCallback callback)
{

    GstRTSPMediaFactory *factory;

    factory = gst_rtsp_media_factory_new();

    gst_rtsp_media_factory_set_launch(factory , pipeline);

    gst_rtsp_media_factory_set_shared(factory , TRUE);   // IMPORTANT

    g_signal_connect(factory , "media-configure" , callback , NULL);

    return factory;
}


// --------------------------------------------------
// ADD BGR STREAM
// --------------------------------------------------

void AddBGRStream()
{

    const char *pipeline =
    "( appsrc name=mysrc is-live=true block=true format=time "
    "! videoconvert "
    "! video/x-raw,format=I420 "
    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 "
    "! rtph264pay name=pay0 pt=96 config-interval=1 )";

    GstRTSPMediaFactory *factory;

    factory = CreateFactory(pipeline , (GCallback)media_configure_bgr);

    gst_rtsp_mount_points_add_factory(mounts , "/bgr" , factory);

    cout<<"BGR stream ready"<<endl;
}


// --------------------------------------------------
// ADD GRAY STREAM (DYNAMIC)
// --------------------------------------------------

//void AddGrayStream()
//{
//
//    const char *pipeline =
//    "( appsrc name=mysrc is-live=true block=true format=time "
//    "! videoconvert "
//    "! video/x-raw,format=I420 "
//    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 "
//    "! rtph264pay name=pay0 pt=96 )";
//
//    GstRTSPMediaFactory *factory;
//
//    factory = CreateFactory(pipeline , (GCallback)media_configure_gray);
//
//    gst_rtsp_mount_points_add_factory(mounts , "/gray" , factory);
//
//    cout<<"GRAY stream dynamically added"<<endl;
//}


void AddGrayStream()
{

    const char *pipeline =
    "( appsrc name=mysrc is-live=true block=true format=time "
    "! videoconvert "
    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 "
    "! rtph264pay name=pay0 pt=96 config-interval=1 )";



    GstRTSPMediaFactory *factory;

    factory = CreateFactory(pipeline , (GCallback)media_configure_gray);

    gst_rtsp_mount_points_add_factory(mounts , "/gray" , factory);

    gst_rtsp_server_attach(server , NULL);   // IMPORTANT

    cout<<"GRAY stream dynamically added"<<endl;
}


// --------------------------------------------------
// MAIN
// --------------------------------------------------

int main(int argc , char *argv[])
{

    gst_init(&argc , &argv);


    cap.open(0);

    CheckError(cap.isOpened() , "Camera open failed");


    server = gst_rtsp_server_new();

    mounts = gst_rtsp_server_get_mount_points(server);


    // CUSTOM PORT
    gst_rtsp_server_set_service(server , "8555");


    // CREATE FIRST STREAM
    AddBGRStream();


    gst_rtsp_server_attach(server , NULL);


    cout<<"RTSP SERVER STARTED"<<endl;
    cout<<"rtsp://127.0.0.1:8555/bgr"<<endl;


    pthread_t tid_bgr;
    pthread_t tid_gray;

    pthread_create(&tid_bgr , NULL , RtspThreadBGR , NULL);
    pthread_create(&tid_gray , NULL , RtspThreadGRAY , NULL);


    while(true)
    {

        cv::Mat frame;

        cap.read(frame);

        if(frame.empty())
            continue;


        cv::resize(frame , frame , cv::Size(640 , 480));


        time_t now = time(0);

        char *dt = ctime(&now);

        cv::putText(frame ,
                    dt ,
                    cv::Point(20 , 40) ,
                    cv::FONT_HERSHEY_SIMPLEX ,
                    1 ,
                    cv::Scalar(0 , 255 , 0) ,
                    2);


        cv::imshow("Camera" , frame);

        char key = cv::waitKey(1);


        // ADD SECOND STREAM WITHOUT STOPPING SERVER
        if(key == 'g')
        {
            AddGrayStream();

            cout<<"rtsp://127.0.0.1:8555/gray"<<endl;
        }


        if(key == 'q')
        {

            cout<<"Stopping application"<<endl;

            cap.release();

            cv::destroyAllWindows();

            break;
        }


        // SAVE BGR FRAME
        pthread_mutex_lock(&frameMutexBGR);

        if(frameReadyBGR == false)
        {
            StreamFrameBGR = frame.clone();
            frameReadyBGR = true;
        }

        pthread_mutex_unlock(&frameMutexBGR);


        // CREATE GRAY
        cv::Mat gray;

        cv::cvtColor(frame , gray , cv::COLOR_BGR2GRAY);


        pthread_mutex_lock(&frameMutexGRAY);

        if(frameReadyGRAY == false)
        {
            StreamFrameGRAY = gray.clone();
            frameReadyGRAY = true;
        }

        pthread_mutex_unlock(&frameMutexGRAY);

    }

    return 0;
}



#endif
