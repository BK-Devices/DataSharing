// ============================================================================
// Name		: Working_V1.0.cpp
// Date		: May 2, 2026
// ============================================================================



#if 0

#include <gst/gst.h>
#include <gst/rtsp-server/rtsp-server.h>
#include <opencv2/opencv.hpp>
#include <ctime>
#include <glib.h>
#include <glibconfig.h>
#include <gst/app/gstappsrc.h>

cv::VideoCapture cap;
GstElement *appsrc;

// method 1.4
GstClockTime timestamp = 0;




static gboolean push_data(GstElement *appsrc)
{
    cv::Mat frame;
//    cap >> frame;
    cap.read(frame);

    if(frame.empty())
        return FALSE;

    // resize
    cv::resize(frame, frame, cv::Size(640,480));

    // timestamp
    time_t now = time(0);
    char *dt = ctime(&now);

    cv::putText(frame, dt, cv::Point(20,40), cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(0,255,0), 2);

    int size = frame.total() * frame.elemSize();

    GstBuffer *buffer = gst_buffer_new_allocate(NULL, size, NULL);

    GstMapInfo map;
    gst_buffer_map(buffer, &map, GST_MAP_WRITE);
    memcpy(map.data, frame.data, size);
    gst_buffer_unmap(buffer, &map);

    // Method 1.3
//    GST_BUFFER_PTS(buffer) = gst_util_uint64_scale(g_get_real_time(), GST_USECOND, 1);
//    GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale_int(1, GST_SECOND, 30);


    // method 1.4
    GST_BUFFER_PTS(buffer) = timestamp;
    GST_BUFFER_DTS(buffer) = timestamp;
    GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale_int(1, GST_SECOND, 30);

    timestamp += GST_BUFFER_DURATION(buffer);





    gst_app_src_push_buffer(GST_APP_SRC(appsrc), buffer);

    return TRUE;
}


// Method 1.0
//static void media_configure(GstRTSPMediaFactory *factory, GstRTSPMedia *media, gpointer user_data)
//{
//    GstElement *element = gst_rtsp_media_get_element(media);
//
//    appsrc = gst_bin_get_by_name_recurse_up(GST_BIN(element), "mysrc");
//
//    g_object_set(G_OBJECT(appsrc),
//                 "format", GST_FORMAT_TIME,
//                 "is-live", TRUE,
//                 NULL);
//
//    g_timeout_add(33, (GSourceFunc)push_data, appsrc);
//
//    gst_object_unref(element);
//}


// Method 1.1
static void media_configure(GstRTSPMediaFactory *factory, GstRTSPMedia *media, gpointer user_data)
{
    GstElement *element = gst_rtsp_media_get_element(media);

    appsrc = gst_bin_get_by_name_recurse_up(GST_BIN(element), "mysrc");



    // method 1.3
//    g_object_set(G_OBJECT(appsrc),
//                 "format", GST_FORMAT_TIME,
//                 "is-live", TRUE,
//                 NULL);


    // method 1.4
    g_object_set(G_OBJECT(appsrc),
                 "format", GST_FORMAT_TIME,
                 "is-live", TRUE,
                 "block", TRUE,
                 "stream-type", 0,
                 NULL);



    GstCaps *caps = gst_caps_new_simple(
        "video/x-raw",
        "format", G_TYPE_STRING, "BGR",
        "width", G_TYPE_INT, 640,
        "height", G_TYPE_INT, 480,
        "framerate", GST_TYPE_FRACTION, 30, 1,
        NULL);

    gst_app_src_set_caps(GST_APP_SRC(appsrc), caps);
    gst_caps_unref(caps);

    g_timeout_add(33, (GSourceFunc)push_data, appsrc);

    gst_object_unref(element);
}




int main(int argc, char *argv[])
{
    gst_init(&argc, &argv);

    cap.open(0);

    if(!cap.isOpened())
    {
        std::cout<<"Camera open failed\n";
        return -1;
    }

    GstRTSPServer *server = gst_rtsp_server_new();
    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);

    GstRTSPMediaFactory *factory = gst_rtsp_media_factory_new();




    // Method 1.1
//    gst_rtsp_media_factory_set_launch(factory,
//        "( appsrc name=mysrc ! videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast ! rtph264pay name=pay0 pt=96 )"
//    );





    // method 1.2
//    gst_rtsp_media_factory_set_launch(factory,
//        "( appsrc name=mysrc ! videoconvert ! video/x-raw,format=I420 ! "
//        "x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast ! "
//        "rtph264pay name=pay0 pt=96 )"
//    );




    // method 1.3
//    gst_rtsp_media_factory_set_launch(factory,
//    "( appsrc name=mysrc ! videoconvert ! video/x-raw,format=I420 ! "
//    "x264enc tune=zerolatency speed-preset=ultrafast bitrate=500 key-int-max=30 ! "
//    "rtph264pay name=pay0 pt=96 )");



    // method 1.4
    gst_rtsp_media_factory_set_launch(factory,
    "( appsrc name=mysrc is-live=true block=true format=time "
    "! videoconvert "
    "! video/x-raw,format=I420 "
    "! x264enc tune=zerolatency bitrate=500 speed-preset=ultrafast key-int-max=30 "
    "! rtph264pay name=pay0 pt=96 )");




    g_signal_connect(factory, "media-configure", (GCallback)media_configure, NULL);

    gst_rtsp_mount_points_add_factory(mounts, "/stream", factory);

    g_object_unref(mounts);

    gst_rtsp_server_attach(server, NULL);

    std::cout<<"RTSP Stream Ready\n";
    std::cout<<"rtsp://127.0.0.1:8554/stream\n";

    GMainLoop *loop = g_main_loop_new(NULL, FALSE);
    g_main_loop_run(loop);

    return 0;
}



#endif
