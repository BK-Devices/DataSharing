#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>

#define IRQ_NO 1   // Keyboard interrupt

static irqreturn_t keyboard_isr(int irq, void *dev_id)
{
    pr_info("Keyboard Interrupt Occurred: IRQ %d\n", irq);
    return IRQ_HANDLED;
}

static int __init interrupt_init(void)
{
    int ret;

    pr_info("Registering Keyboard Interrupt\n");

    ret = request_irq(IRQ_NO,
                      keyboard_isr,
                      IRQF_SHARED,
                      "keyboard_interrupt",
                      (void *)(keyboard_isr));

    if (ret) {
        pr_err("Cannot register IRQ\n");
        return ret;
    }

    return 0;
}

static void __exit interrupt_exit(void)
{
    free_irq(IRQ_NO, (void *)(keyboard_isr));
    pr_info("Interrupt removed\n");
}

module_init(interrupt_init);
module_exit(interrupt_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Study");
MODULE_DESCRIPTION("Simple Interrupt Handler Example");


