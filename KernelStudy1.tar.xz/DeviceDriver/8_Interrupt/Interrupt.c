// irq_example.c
#include <linux/module.h>
#include <linux/interrupt.h>

#define IRQ_NO 11

static irqreturn_t irq_handler(int irq, void *dev)
{
    pr_info("Interrupt occurred\n");
    return IRQ_HANDLED;
}

static int __init start(void)
{
    pr_info("Module loaded\n");
    request_irq(IRQ_NO, irq_handler, IRQF_SHARED, "my_irq", &irq_handler);
    return 0;
}

static void __exit stop(void)
{
    free_irq(IRQ_NO, &irq_handler);
    pr_info("Module unloaded\n");
}

module_init(start);
module_exit(stop);
MODULE_LICENSE("GPL");