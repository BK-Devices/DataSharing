#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>

#define IRQ_NO 1

static struct tasklet_struct my_tasklet;

void tasklet_fn(unsigned long data);




void tasklet_fn(unsigned long data)
{
    pr_info("Bottom Half: Tasklet executed\n");
}

static irqreturn_t keyboard_isr(int irq, void *dev_id)
{
    pr_info("Top Half: Interrupt received\n");

    tasklet_schedule(&my_tasklet);

    return IRQ_HANDLED;
}

static int __init interrupt_init(void)
{
    int ret;

    tasklet_init(&my_tasklet, tasklet_fn, 0);

    ret = request_irq(IRQ_NO,
                      keyboard_isr,
                      IRQF_SHARED,
                      "keyboard_tasklet",
                      (void *)(keyboard_isr));

    if (ret) {
        pr_err("Cannot register IRQ\n");
        return ret;
    }

    pr_info("Tasklet Interrupt Module Loaded\n");

    return 0;
}

static void __exit interrupt_exit(void)
{
    tasklet_kill(&my_tasklet);
    free_irq(IRQ_NO, (void *)(keyboard_isr));

    pr_info("Module unloaded\n");
}

module_init(interrupt_init);
module_exit(interrupt_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Study");
MODULE_DESCRIPTION("Top Half + Bottom Half Tasklet Example");