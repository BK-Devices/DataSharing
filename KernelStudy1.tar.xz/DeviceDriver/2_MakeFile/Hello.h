#ifndef HELLO_H
#define HELLO_H

#define Name "Bhavesh"

#endif