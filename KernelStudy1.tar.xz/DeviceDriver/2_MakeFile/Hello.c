#include <linux/module.h>
#include <linux/kernel.h>

#include "Hello.h"

static int __init hello_init(void)
{
    printk(KERN_INFO "Hello %s\n", Name);
    printk(KERN_INFO "Module Loaded\n");
    return 0;
}

static void __exit hello_exit(void)
{
    printk(KERN_INFO "Module Removed\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");

