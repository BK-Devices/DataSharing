#ifndef HELLO_H
#define HELLO_H

#define Name "Bhavesh"

void device_init_func(void);

#endif