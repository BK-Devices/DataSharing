#include <linux/kernel.h>

#include "Hello.h"


void device_init_func(void)
{
    pr_info("Device initialized\n");
}