#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/workqueue.h>

#define IRQ_NO 1

static struct workqueue_struct *my_wq;
static struct work_struct my_work;

void workqueue_fn(struct work_struct *work);

void workqueue_fn(struct work_struct *work)
{
    pr_info("Bottom Half: Workqueue running\n");
}

static irqreturn_t keyboard_isr(int irq, void *dev_id)
{
    pr_info("Top Half: Interrupt occurred\n");

    queue_work(my_wq, &my_work);

    return IRQ_HANDLED;
}

static int __init interrupt_init(void)
{
    int ret;

    my_wq = create_workqueue("my_workqueue");

    INIT_WORK(&my_work, workqueue_fn);

    ret = request_irq(IRQ_NO,
                      keyboard_isr,
                      IRQF_SHARED,
                      "keyboard_workqueue",
                      (void *)(keyboard_isr));

    if (ret) {
        pr_err("Cannot register IRQ\n");
        return ret;
    }

    pr_info("Workqueue Interrupt Module Loaded\n");

    return 0;
}

static void __exit interrupt_exit(void)
{
    destroy_workqueue(my_wq);
    free_irq(IRQ_NO, (void *)(keyboard_isr));

    pr_info("Module unloaded\n");
}

module_init(interrupt_init);
module_exit(interrupt_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Study");
MODULE_DESCRIPTION("Top Half + Bottom Half Workqueue Example");