#include <linux/kernel.h>
#include "Helper.h"

void helper_function(void)
{
    printk(KERN_INFO "Helper function called\n");
}