#include <linux/module.h>
#include <linux/kernel.h>
#include "Helper.h"

static int __init my_init(void)
{
    printk(KERN_INFO "Driver Init\n");
    helper_function();
    return 0;
}

static void __exit my_exit(void)
{
    printk(KERN_INFO "Driver Exit\n");
}

module_init(my_init);
module_exit(my_exit);

MODULE_VERSION("1.0");
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Bhavesh");
MODULE_DESCRIPTION("Multi-file Kernel Module");