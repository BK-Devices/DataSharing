#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#include <linux/cdev.h>
#include <linux/fs.h>


dev_t dev;
struct cdev myCdev;

static int myOpen(struct inode *inode, struct file *file)
{
    printk(KERN_INFO "Device Opened\n");
    return 0;
}

static int myRelease(struct inode *indoe, struct file *file)
{
    printk(KERN_INFO "Device Released\n");
    return 0;
}

static ssize_t myRead(struct file *file, const char __user *buf, size_t len, loff_t *off)
{
    printk(KERN_INFO "Device Reading\n");
    return 0;
}

static ssize_t myWrite(struct file *file, char __user *buf, size_t len, loff_t *off)
{
    printk(KERN_INFO "Device Writing\n");
    return 0;
}

struct file_operations fops = 
{
    .owner = THIS_MODULE,
    .open = myOpen,
    .read = myRead,
    .write = myWrite,
    .release = myRelease,
};

static int __init myInit(void)
{
    if(alloc_chrdev_region(&dev, 0, 1, "myDevice") < 0)
    {
        printk(KERN_ERR "Cannot allocate major number\n");
        return -1;
    }

    cdev_init(&myCdev, &fops);

    cdev_add(&myCdev, dev, 1);

    printk(KERN_INFO "Major - %d  Minor - %d\n", MAJOR(dev), MINOR(dev));

    return 0;
}

static void __exit myExit(void)
{
    cdev_del(&myCdev);
    unregister_chrdev_region(dev, 1);
    printk(KERN_INFO "Drver removed\n");
    return;
}

module_init(myInit);
module_exit(myExit);

MODULE_VERSION("1.0");
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Bhavesh");
MODULE_DESCRIPTION("Char driver");




