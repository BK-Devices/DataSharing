savedcmd_6_CharDriver1.mod := printf '%s\n'   CharDriver1.o | awk '!x[$$0]++ { print("./"$$0) }' > 6_CharDriver1.mod
