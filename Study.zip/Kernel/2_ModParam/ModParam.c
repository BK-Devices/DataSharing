#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#include <linux/moduleparam.h>

// Declare parameters
int number = 0;
char *name = "default";
bool flag = false;

// Register Parameters
module_param(number, int, 0644);
module_param(name, charp, 0644);
module_param(flag, bool, 0644);

static int __init myInit(void)
{
    printk(KERN_INFO "Module Parameters Code\n");
    printk(KERN_INFO "Number = %d\n", number);
    printk(KERN_INFO "Name = %s\n", name);
    printk(KERN_INFO "Flag = %d\n", flag);
    return 0;
}

// ---------------------------------------------------------------
// | Macro         | Equivalent printk | Purpose                 |
// | ------------- | ----------------- | ------------------------|
// | `pr_emerg()`  | `KERN_EMERG`      | System unusable         |
// | `pr_alert()`  | `KERN_ALERT`      | Immediate action needed |
// | `pr_crit()`   | `KERN_CRIT`       | Critical errors         |
// | `pr_err()`    | `KERN_ERR`        | Error                   |
// | `pr_warn()`   | `KERN_WARNING`    | Warning                 |
// | `pr_notice()` | `KERN_NOTICE`     | Normal but important    |
// | `pr_info()`   | `KERN_INFO`       | Informational           |
// | `pr_debug()`  | `KERN_DEBUG`      | Debug messages          |
// ---------------------------------------------------------------

static void __exit myExit(void)
{
    printk(KERN_INFO "Good Bye Mudule Parameters Kernel\n");
    return;
}

module_init(myInit);
module_exit(myExit);

MODULE_VERSION("1.0");
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Bhavesh");
MODULE_DESCRIPTION("Mudule Parameters");

