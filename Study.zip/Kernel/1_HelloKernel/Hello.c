#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

static int __init myInit(void)
{
    printk(KERN_INFO "Hello Kernel I am Bhavesh\n");
    return 0;
}

static void __exit myExit(void)
{
    printk(KERN_INFO "Good Bye Kernel\n");
    return;
}

module_init(myInit);
module_exit(myExit);

MODULE_VERSION("1.0");
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Bhavesh");
MODULE_DESCRIPTION("Hello Kernel Module");

