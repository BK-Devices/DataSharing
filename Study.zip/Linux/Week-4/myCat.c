#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    char ch = 0;
    int fd = -1;

    if(argc < 2)
    {
        printf("./exe <file>\n");
    }

    fd = open(argv[1], O_RDONLY, 0664);
    if(fd < 0)
    {
        perror("open");
        return 1;
    }

    while(read(fd, &ch, 1) > 0)
    {
        printf("%c", ch);
    }

    close(fd);

    return 0;
}




