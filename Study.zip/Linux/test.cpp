#include <iostream>

#include <unistd.h>
#include <stdlib.h>

using namespace std;

int main(void)
{
    return 0;
}



