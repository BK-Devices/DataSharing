// ============================================================================
// Name		: Seeker.cpp
// Date		: 03 May 2026
// Version  : V01.00.00
// ============================================================================


// ---------- Header Inclusion ----------
#include <iostream>

#include <unistd.h>
#include <sys/time.h>

#include <opencv2/opencv.hpp>

extern "C"
{
	#include "libavutil/avutil.h"
	#include "libavutil/pixfmt.h"
	#include "libavutil/imgutils.h"
	#include "libswscale/swscale.h"
	#include "libavcodec/avcodec.h"
	#include "libavformat/avformat.h"
	#include "libavdevice/avdevice.h"
}

#include "Seeker.h"


// ---------- Namespace ----------
using namespace std;
using namespace cv;


// ---------- Global Variables ----------
string SwVersion = "03/05/26 V01.00.00";


// ---------- Seeker :: SeekerIMPL Class Declaration ----------
class Seeker :: SeekerIMPL
{
private:
	// Video Parameters
	string VideoSrc;
	VideoAPI Api;
	bool SeekerStatus;
	bool rtspTCPFlag;

	// OpenCV variables
	VideoCapture VideoCam;

	// FFmpeg variables
	uint8_t *outBuffer;
	int32_t streamIndex;
	AVPacket *packet;
	AVFrame *pFrame;
	AVFrame *pFrameBgr;
	AVDictionary *avdic;
	AVCodecContext *pCodecCtx;
	AVFormatContext *pFormatCtx;
	struct SwsContext *imgConvertCtx;


public:

	// Constructor
	SeekerIMPL(void);

	// Destructor
	~SeekerIMPL(void);

	// Open Video Source
	uint8_t open(const String &VideoSrc, VideoAPI Api);

	// Close Video Source
	void close(void);

	// Read Video Frames
	uint8_t getVideoFrame(Mat &VideoFrame);
};



// ---------- Constructor ----------
Seeker :: SeekerIMPL :: SeekerIMPL(void)
{
	VideoSrc = "";
	Api = OPENCV;
	SeekerStatus = false;
	rtspTCPFlag = true;

	outBuffer = nullptr;
	streamIndex = -1;

	packet = nullptr;
	pFrame = nullptr;
	pFrameBgr = nullptr;
	avdic = nullptr;
	pCodecCtx = nullptr;
	pFormatCtx = nullptr;
	imgConvertCtx = nullptr;

	return;
}


// ---------- Destructor ----------
Seeker :: SeekerIMPL :: ~SeekerIMPL(void)
{
	close();
	return;
}


// ---------- Open Video Source ----------
uint8_t Seeker :: SeekerIMPL :: open(const String &VideoSrc, VideoAPI Api)
{
	uint32_t i = 0U;
	int32_t numBytes;

	AVCodec *pCodec = nullptr;
	AVInputFormat *inpFormat = nullptr;

	if(SeekerStatus == true)
	{
		cerr << "Error : Video Source is already Opened..." << endl;
		return 1U;
	}

	if(VideoSrc == "" || (Api != OPENCV && Api != FFMPEG))
	{
		cerr << "Error : Wrong Parameters..." << endl;
		return 2U;
	}

	this->VideoSrc = VideoSrc;
	this->Api = Api;

	if(Api == OPENCV)
	{
		VideoCam.open(VideoSrc);

		if(!VideoCam.isOpened())
		{
			cerr << "Error : Unable to Open Video Source " << VideoSrc << endl;
			return 2U;
		}

		SeekerStatus = true;
	}
	else if(Api == FFMPEG)
	{
		// Allocate format context
		pFormatCtx = avformat_alloc_context();
		streamIndex = -1;


// ---------- Working Logic ----------
//		// Open Video Source
//		if(VideoSrc.find("rtsp://") == 0)
//		{
//		    avformat_network_init();
//
//		    av_dict_set(&avdic, "rtsp_transport", "tcp", 0);
//		    av_dict_set(&avdic, "max_delay", "0", 0);
//
//		    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), NULL, &avdic) != 0)
//		    {
//		        cerr << "Error : Unable to Open Video Source " << VideoSrc << endl;
//		        return 2U;
//		    }
//		}
//		else if(VideoSrc.find("/dev/video") == 0)
//		{
//		    avdevice_register_all();
//
//		    inpFormat = av_find_input_format("v4l2");
//
//		    av_dict_set(&avdic, "video_size", "640x480", 0);
//		    av_dict_set(&avdic, "framerate", "25", 0);
//
//		    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), inpFormat, &avdic) != 0)
//		    {
//		        cerr << "Error : Unable to Open Video Source " << VideoSrc << endl;
//		        return 2U;
//		    }
//		}
//		else
//		{
//		    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), NULL, &avdic) != 0)
//		    {
//		        cerr << "Error : Unable to Open Video Source " << VideoSrc << endl;
//		        return 2U;
//		    }
//		}
// ---------- Working Logic ----------


		if(VideoSrc.find("rtsp://") == 0)
		{
			avformat_network_init();

			// Use UDP for RTSP
		    if(rtspTCPFlag == false)
		    {
		    	av_dict_set(&avdic, "rtsp_transport", "udp", 0);
				av_dict_set(&avdic, "stimeout", "5000000", 0);
				av_dict_set(&avdic, "max_delay", "500000", 0);
				av_dict_set(&avdic, "buffer_size", "102400", 0);
				av_dict_set(&avdic, "fflags", "nobuffer", 0);
				av_dict_set(&avdic, "flags", "low_delay", 0);
				av_dict_set(&avdic, "framedrop", "1", 0);
				av_dict_set(&avdic, "reorder_queue_size", "0", 0);
		    }
		    // Use TCP for RTSP
		    else
		    {
		        av_dict_set(&avdic, "rtsp_transport", "tcp", 0);
		        av_dict_set(&avdic, "stimeout", "5000000", 0);
		        av_dict_set(&avdic, "rw_timeout", "5000000", 0);
		        av_dict_set(&avdic, "max_delay", "500000", 0);
		        av_dict_set(&avdic, "fflags", "nobuffer", 0);
		        av_dict_set(&avdic, "flags", "low_delay", 0);
		        av_dict_set(&avdic, "buffer_size", "102400", 0);
		        av_dict_set(&avdic, "framedrop", "1", 0);
		        av_dict_set(&avdic, "reorder_queue_size", "0", 0);
		    }

		    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
		    {
		        cerr << "Error: Failed to open RTSP stream source : " << VideoSrc << endl;
		        return 2U;
		    }
		}
		else if(VideoSrc.find("udp://") == 0 || VideoSrc.find("tcp://") == 0 || VideoSrc.find("rtp://") == 0)
		{
			avformat_network_init();

		    av_dict_set(&avdic, "protocol_whitelist", "file,udp,rtp,tcp", 0);
		    av_dict_set(&avdic, "timeout", "5000000", 0);
		    av_dict_set(&avdic, "max_delay", "500000", 0);
		    av_dict_set(&avdic, "buffer_size", "102400", 0);
		    av_dict_set(&avdic, "fflags", "nobuffer", 0);
		    av_dict_set(&avdic, "flags", "low_delay", 0);
		    av_dict_set(&avdic, "framedrop", "1", 0);

		    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
		    {
		        cerr << "Error: Failed to open UDP/TCP/RTP stream source : " << VideoSrc << endl;
		        return 2U;
		    }
		}
		else if(VideoSrc.find("http://") == 0 || VideoSrc.find("https://") == 0)
		{
			avformat_network_init();

		    av_dict_set(&avdic, "reconnect", "1", 0);
		    av_dict_set(&avdic, "reconnect_streamed", "1", 0);
		    av_dict_set(&avdic, "reconnect_delay_max", "2", 0);
		    av_dict_set(&avdic, "timeout", "5000000", 0);
		    av_dict_set(&avdic, "buffer_size", "102400", 0);
		    av_dict_set(&avdic, "fflags", "nobuffer", 0);
		    av_dict_set(&avdic, "flags", "low_delay", 0);
		    av_dict_set(&avdic, "framedrop", "1", 0);

		    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
		    {
		        cerr << "Error: Failed to open HTTP/HTTPS video stream : " << VideoSrc << endl;
		        return 2U;
		    }
		}
		else if(VideoSrc.find("/dev/video") == 0)
		{
			avdevice_register_all();
		    inpFormat = av_find_input_format("video4linux2");

			av_dict_set(&avdic, "video_size", "640x480", 0);
			av_dict_set(&avdic, "framerate", "25", 0);
		    av_dict_set(&avdic, "fflags", "nobuffer", 0);
		    av_dict_set(&avdic, "flags", "low_delay", 0);
		    av_dict_set(&avdic, "framedrop", "1", 0);

		    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), inpFormat, &avdic) < 0)
		    {
		        cerr << "Error: Failed to open V4L2 video device : " << VideoSrc << endl;
		        return 2U;
		    }
		}
		else
		{
		    av_dict_set(&avdic, "fflags", "nobuffer", 0);
		    av_dict_set(&avdic, "flags", "low_delay", 0);
		    av_dict_set(&avdic, "framedrop", "1", 0);

		    if(avformat_open_input(&pFormatCtx, VideoSrc.c_str(), nullptr, &avdic) < 0)
		    {
		        cerr << "Error: Failed to open video file source : " << VideoSrc << endl;
		        return 2U;
		    }
		}

		// Get Stream Info
		if(avformat_find_stream_info(pFormatCtx, NULL) < 0)
		{
		    cerr << "Error : Unable to read stream information" << endl;
		    return 2U;
		}

		// Find Video Stream
		for(i = 0U; i < pFormatCtx->nb_streams; i++)
		{
		    if(pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		    {
		        streamIndex = i;
		        break;
		    }
		}

		if(streamIndex == -1)
		{
		    cerr << "Error : No video stream found in source" << endl;
		    return 2U;
		}

		// Get Codec Contex
		pCodecCtx = avcodec_alloc_context3(NULL);
		if(!pCodecCtx)
		{
		    cerr << "Error : Unable to allocate codec context" << endl;
		    return 2U;
		}

		if(avcodec_parameters_to_context(pCodecCtx, pFormatCtx->streams[streamIndex]->codecpar) < 0)
		{
		    cerr << "Error : Unable to copy codec parameters" << endl;
		    return 2U;
		}

		// Find Decoded
		pCodec = avcodec_find_decoder(pCodecCtx->codec_id);
		if(pCodec == NULL)
		{
		    cerr << "Error : Unable to Find Decoder" << endl;
		    return 2U;
		}

		// Open Decoder
		if(avcodec_open2(pCodecCtx, pCodec, NULL) < 0)
		{
		    cerr << "Error : Unable to Open Decoder" << endl;
		    return 2U;
		}

		// Allocate Frames
		pFrame = av_frame_alloc();
		pFrameBgr = av_frame_alloc();

		if(!pFrame || !pFrameBgr)
		{
		    cerr << "Error : Frame allocation failed" << endl;
		    return 2U;
		}

		// Create scale Contex
		imgConvertCtx = sws_getContext(pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt, pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BICUBIC, NULL,  NULL, NULL);

		if(!imgConvertCtx)
		{
		    cerr << "Error : sws_getContext failed" << endl;
		    return 2U;
		}

		// Allocate BGR Buffer
		numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1);

		outBuffer = (uint8_t *)av_malloc(numBytes * sizeof(uint8_t));
		if(!outBuffer)
		{
		    cerr << "Error : Memory allocation failed" << endl;
		    return 2U;
		}

		// Fill Frame Buffer
		if(av_image_fill_arrays(pFrameBgr->data, pFrameBgr->linesize, outBuffer, AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1) < 0)
		{
		    cerr << "Error : Unable to fill frame arrays" << endl;
		    return 2U;
		}

		// Packet Buffer
		packet = av_packet_alloc();
		if(!packet)
		{
		    cerr << "Error : Packet allocation failed" << endl;
		    return 2U;
		}

		SeekerStatus = true;

	}
	else
	{

	}

	return 0U;
}


// ---------- Close Video Source ----------
void Seeker :: SeekerIMPL :: close(void)
{
	if(SeekerStatus == false)
	{
		return;
	}

	SeekerStatus = false;

	if(Api == OPENCV)
	{
		VideoCam.release();
	}
	else if(Api == FFMPEG)
	{
// ---------- Working Logic ----------
//		avcodec_send_packet(pCodecCtx, nullptr);
//		avcodec_receive_frame(pCodecCtx, pFrame);
//
//		av_free((void *)outBuffer);
//
//		av_packet_unref(packet);
//
//		av_packet_free(&packet);
//
//		av_frame_unref(pFrame);
//		av_frame_unref(pFrameBgr);
//
//		av_frame_free(&pFrame);
//		av_frame_free(&pFrameBgr);
//
//		avcodec_close(pCodecCtx);
//		avformat_close_input(&pFormatCtx);
//
//		avformat_free_context(pFormatCtx);
//
//		sws_freeContext(imgConvertCtx);
// ---------- Working Logic ----------



		// Free packet
		if(packet)
		{
			av_packet_unref(packet);
			av_packet_free(&packet);
			packet = nullptr;
		}

		// Free frames
		if(pFrame)
		{
			av_frame_free(&pFrame);
			pFrame = nullptr;
		}

		if(pFrameBgr)
		{
			av_frame_free(&pFrameBgr);
			pFrameBgr = nullptr;
		}

		// Free buffer
		if(outBuffer)
		{
			av_free(outBuffer);
			outBuffer = nullptr;
		}

		// Free swscale
		if(imgConvertCtx)
		{
			sws_freeContext(imgConvertCtx);
			imgConvertCtx = nullptr;
		}

		// Free codec
		if(pCodecCtx)
		{
			avcodec_free_context(&pCodecCtx);
			pCodecCtx = nullptr;
		}

		// Close input
		if(pFormatCtx)
		{
			avformat_close_input(&pFormatCtx);
			pFormatCtx = nullptr;
		}

		// Free dictionary
		if(avdic)
		{
			av_dict_free(&avdic);
			avdic = nullptr;
		}

		streamIndex = -1;
	}
	else
	{

	}

	return;
}


// ---------- Read Video Frames ----------
uint8_t Seeker :: SeekerIMPL :: getVideoFrame(Mat &VideoFrame)
{
	if(SeekerStatus == false)
	{
		cerr << "Error : Video Source is Closed.." << endl;
		return 1U;
	}

	if(Api == OPENCV)
	{
		if(VideoCam.read(VideoFrame) == false)
		{
			cerr << "Error : Failed to read video" << endl;
			return 2U;
		}
	}
	else if(Api == FFMPEG)
	{
// ---------- Working Logic ----------
//		if(av_read_frame(pFormatCtx, packet) < 0)
//		{
//			cerr << "Error : Failed to read video" << endl;
//			return 2U;
//		}
//
//		if(packet->stream_index != streamIndex)
//		{
//			av_packet_unref(packet);
//			// cerr << "Error : Improper video index" << endl;
//			cerr << "Error : Failed to read video" << endl;
//			return 2U;
//		}
//
//		if(avcodec_send_packet(pCodecCtx, packet) != 0)
//		{
//			av_packet_unref(packet);
//			// cerr << "Error : Failed to send video frame" << endl;
//			cerr << "Error : Failed to read video" << endl;
//			return 2U;
//		}
//
//		if(avcodec_receive_frame(pCodecCtx, pFrame) != 0)
//		{
//			av_packet_unref(packet);
//			// cerr << "Error : Failed to receive video frame" << endl;
//			cerr << "Error : Failed to read video" << endl;
//			return 2U;
//		}
//
//		// Convert to opencv frame
//		sws_scale(imgConvertCtx, (uint8_t const * const *) pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameBgr->data, pFrameBgr->linesize);
//		VideoFrame.create(pCodecCtx->height, pCodecCtx->width, CV_8UC3);
//		memcpy(VideoFrame.data, pFrameBgr->data[0], pCodecCtx->height * pFrameBgr->linesize[0]);
//
//		av_packet_unref(packet);
		// ---------- Working Logic ----------


	READ:
		if(av_read_frame(pFormatCtx, packet) < 0)
		{
		    cerr << "Error : Failed to read video packet" << endl;
		    return 2U;
		}

		if(packet->stream_index != streamIndex)
		{
		    av_packet_unref(packet);
		    goto READ;
		}

		if(avcodec_send_packet(pCodecCtx, packet) != 0)
		{
		    av_packet_unref(packet);
		    cerr << "Error : Failed to send packet to decoder" << endl;
		    return 2U;
		}

		while(avcodec_receive_frame(pCodecCtx, pFrame) == 0)
		{
		    sws_scale(imgConvertCtx, (uint8_t const * const *)pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameBgr->data, pFrameBgr->linesize);

		    VideoFrame.create(pCodecCtx->height, pCodecCtx->width, CV_8UC3);
		    memcpy(VideoFrame.data, pFrameBgr->data[0], pCodecCtx->height * pFrameBgr->linesize[0]);

		    break;
		}

		av_packet_unref(packet);
	}
	else
	{

	}

	return 0U;
}


// ---------- Constructor ----------
Seeker :: Seeker(void)
{
	seekerIMPL = new SeekerIMPL;
	return;
}


// ---------- Destructor ----------
Seeker :: ~Seeker(void)
{
	delete seekerIMPL;
	return;
}

// ---------- Get Software Details ----------
string Seeker :: getSwDetails(void)
{
	return SwVersion;
}


// ---------- Open Video Source ----------
uint8_t Seeker :: open(const String &VideoSrc, VideoAPI Api)
{
	return seekerIMPL->open(VideoSrc, Api);
}


// ---------- Close Video Source ----------
void Seeker :: close(void)
{
	return seekerIMPL->close();
}


// ---------- Read Video Frames ----------
uint8_t Seeker :: getVideoFrame(Mat &VideoFrame)
{
	return seekerIMPL->getVideoFrame(VideoFrame);
}




