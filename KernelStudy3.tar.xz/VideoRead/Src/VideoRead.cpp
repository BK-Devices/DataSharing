//============================================================================
// Name        : VideoRead.cpp
// Author      : Bhavesh Kale
// Version     : 01.00.00
// Date        : 01 Apr 2026
//============================================================================

// g++ ./FFmpegReadVideo.cpp -o ./ReadVideo -pthread -I/usr/local/opencv4/include/opencv4 -L/usr/local/opencv4/lib  -lopencv_highgui -lopencv_ml -lopencv_objdetect -lopencv_photo -lopencv_stitching -lopencv_video -lopencv_calib3d -lopencv_features2d -lopencv_dnn -lopencv_flann -lopencv_videoio -lopencv_imgcodecs -lopencv_imgproc -lopencv_core -lavformat -lavcodec -lswscale -lavutil -lswresample -lavdevice

//// ---------- Header Inclusion ----------
//#include <iostream>
//#include <unistd.h>
//#include <opencv2/opencv.hpp>
//
//extern "C"
//{
//	#include "libavutil/avutil.h"
//	#include "libavutil/pixfmt.h"
//	#include "libavutil/imgutils.h"
//	#include "libswscale/swscale.h"
//	#include "libavcodec/avcodec.h"
//	#include "libavformat/avformat.h"
//	#include "libavdevice/avdevice.h"
//}
//
//
//// ---------- Namespace ----------
//using namespace std;
//using namespace cv;
//
//
//// ---------- Other Variables ----------
//bool opencvReadFlag = true;
//
//
//// ---------- OpenCv Variables ----------
//VideoCapture VideoCam;
//
//
//// ---------- FFmpeg Variables ----------
//uint8_t *outBuffer;
//int32_t streamIndex = -1;
//AVPacket *packet = nullptr;
//AVFrame *pFrame = nullptr;
//AVFrame *pFrameBgr = nullptr;
//AVCodecContext *pCodecCtx = nullptr;
//AVFormatContext *pFormatCtx = nullptr;
//struct SwsContext *imgConvertCtx = nullptr;
//
//
//// ---------- Open Video Source ----------
//bool openVideoSrc(string SrcPath)
//{
//	uint32_t i = 0U;
//	int32_t numBytes, ySize;
//
//	AVCodec *pCodec = nullptr;
//	AVDictionary *avdic = nullptr;
//	AVInputFormat *inpFormat = nullptr;
//
//	if(opencvReadFlag == true)
//	{
//		VideoCam.open(SrcPath);
//
//		if(!VideoCam.isOpened())
//		{
//			cerr << "Error : Unable to open video source " << SrcPath << endl;
//			return false;
//		}
//	}
//	else
//	{
//
//		pFormatCtx = avformat_alloc_context();
//
//		if(SrcPath.find("rtsp://") == 0)
//		{
//			avformat_network_init();
//
//			av_dict_set(&avdic, "rtsp_transport", "tcp", 0);
//			av_dict_set(&avdic, "max_delay", "0", 0);
//
//			if(avformat_open_input(&pFormatCtx, SrcPath.c_str(), NULL,  &avdic) != 0)
//			{
//				cerr << "Error : Unable to open video source " << SrcPath << endl;
//				return false;
//			}
//		}
//		else if(SrcPath.find("/dev/video") == 0)
//		{
//			avdevice_register_all();
//			inpFormat = av_find_input_format("v4l2");
//
//			av_dict_set(&avdic, "video_size", "640x480", 0);
//			av_dict_set(&avdic, "framerate", "25", 0);
//
//			if(avformat_open_input(&pFormatCtx, SrcPath.c_str(), inpFormat,  &avdic) != 0)
//			{
//				cerr << "Error : Unable to open video source " << SrcPath << endl;
//				return false;
//			}
//
//		}
//		else
//		{
//			if(avformat_open_input(&pFormatCtx, SrcPath.c_str(), NULL,  &avdic) != 0)
//			{
//				cerr << "Error : Unable to open video source " << SrcPath << endl;
//				return false;
//			}
//
//		}
//
//		// Get video source information
//		if(avformat_find_stream_info(pFormatCtx, NULL) < 0)
//		{
//			cerr << "Error : Unable to find video source information" << endl;
//			return false;
//		}
//
//		// Find the video stream
//		for(i = 0U; i < pFormatCtx->nb_streams; i++)
//		{
//			if(pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
//			{
//				streamIndex = i;
//			}
//		}
//
//		if(streamIndex == -1)
//		{
//			cout << "Error : Unable to find stream index" << endl;
//			return false;
//		}
//
//		// Get codec context
//		pCodecCtx = avcodec_alloc_context3(NULL);
//		avcodec_parameters_to_context(pCodecCtx, pFormatCtx->streams[streamIndex]->codecpar);
//		pCodec = avcodec_find_decoder(pCodecCtx->codec_id);
//
//		pCodecCtx->bit_rate =0;
//		pCodecCtx->time_base.num=1;
//		pCodecCtx->time_base.den=10;
//		pCodecCtx->frame_number=1;
//
//		if(pCodec == NULL)
//		{
//			cout << "Error : Unable to find codec" << endl;
//			return false;
//		}
//
//		// Open codec
//		if(avcodec_open2(pCodecCtx, pCodec, NULL) < 0)
//		{
//			cout << "Error : Unable to open codec" << endl;
//			return false;
//		}
//
//		// Allocate memory for frames
//		pFrame = av_frame_alloc();
//		pFrameBgr = av_frame_alloc();
//
//		// Get the required buffer size for Bgr conversion
//		imgConvertCtx = sws_getContext(pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt, pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BICUBIC, NULL, NULL, NULL);
//
//		numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, pCodecCtx->width,pCodecCtx->height, 1);
//		outBuffer = (uint8_t *)av_malloc(numBytes * sizeof(uint8_t));
//
//		av_image_fill_arrays(pFrameBgr->data, pFrameBgr->linesize, outBuffer, AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1);
//
//		ySize = pCodecCtx->width * pCodecCtx->height;
//		packet = (AVPacket *)malloc(sizeof(AVPacket));
//
//		av_new_packet(packet, ySize);
//	}
//
//	return true;
//}
//
//
//// ---------- Read Video Frames ----------
//bool readVideoFrames(Mat &VideoFrame)
//{
//	if(opencvReadFlag == true)
//	{
//		if(VideoCam.read(VideoFrame) == false)
//		{
//			cerr << "Error : Failed to read video" << endl;
//			return false;
//		}
//	}
//	else
//	{
//		if(av_read_frame(pFormatCtx, packet) < 0)
//		{
//			cerr << "Error : Failed to read video" << endl;
//			return false;
//		}
//
//		if(packet->stream_index != streamIndex)
//		{
//			av_packet_unref(packet);
//			cerr << "Error : Improper video index" << endl;
//			return false;
//		}
//
//		if(avcodec_send_packet(pCodecCtx, packet) != 0)
//		{
//			av_packet_unref(packet);
//			cerr << "Error : Failed to send video frame" << endl;
//			return false;
//		}
//
//		if(avcodec_receive_frame(pCodecCtx, pFrame) != 0)
//		{
//			av_packet_unref(packet);
//			cerr << "Error : Failed to receive video frame" << endl;
//			return false;
//		}
//
//		// Convert to opencv frame
//		sws_scale(imgConvertCtx, (uint8_t const * const *) pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameBgr->data, pFrameBgr->linesize);
//		VideoFrame.create(pCodecCtx->height, pCodecCtx->width, CV_8UC3);
//		memcpy(VideoFrame.data, pFrameBgr->data[0], pCodecCtx->height * pFrameBgr->linesize[0]);
//
//		av_packet_unref(packet);
//	}
//
//	return true;
//}
//
//
//// ---------- Close Video Source ----------
//void closeVideoSrc(void)
//{
//	if(opencvReadFlag == true)
//	{
//		VideoCam.release();
//	}
//	else
//	{
//		avcodec_send_packet(pCodecCtx, nullptr);
//		avcodec_receive_frame(pCodecCtx, pFrame);
//
//		av_free((void *)outBuffer);
//
//		av_packet_unref(packet);
//
//		av_packet_free(&packet);
//
//		av_frame_unref(pFrame);
//		av_frame_unref(pFrameBgr);
//
//		av_frame_free(&pFrame);
//		av_frame_free(&pFrameBgr);
//
//		avcodec_close(pCodecCtx);
//		avformat_close_input(&pFormatCtx);
//
//		avformat_free_context(pFormatCtx);
//
//		sws_freeContext(imgConvertCtx);
//	}
//}
//
//
//int main(void)
//{
//	Mat VideoFrame;
//
//	opencvReadFlag = false;
//
//	openVideoSrc("/dev/video0");
//
//	while(true)
//	{
//		VideoFrame.release();
//
//		if(readVideoFrames(VideoFrame) == false)
//		{
//			break;
//		}
//
//		imshow("Video", VideoFrame);
//		if(waitKey(1) == 'q')
//		{
//			break;
//		}
//
//		usleep(10 * 1000);
//	}
//
//	closeVideoSrc();
//	destroyAllWindows();
//
//	return 0;
//}


// ---------- Header Inclusion ----------
#include <iostream>
#include <unistd.h>
#include <opencv2/opencv.hpp>

#include "Seeker.h"


// ---------- Namespace ----------
using namespace std;
using namespace cv;

//string VideoSrc = "/dev/video0";
string VideoSrc = "rtsp://localhost:8555/bgr";


int main(void)
{
	Mat VideoFrame;

	Seeker seeker;
	seeker.open(VideoSrc, FFMPEG);

	while(true)
	{
		VideoFrame.release();

		if(seeker.getVideoFrame(VideoFrame) != 0U)
		{
			break;
		}

		imshow("Video", VideoFrame);
		if(waitKey(1) == 'q')
		{
			break;
		}

		usleep(10 * 1000);
	}

	seeker.close();
	destroyAllWindows();

	return 0;
}



