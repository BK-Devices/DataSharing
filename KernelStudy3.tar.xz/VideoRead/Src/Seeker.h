// ============================================================================
// Name		: Seeker.h
// Date		: 03 May 2026
// Version  : V01.00.00
// ============================================================================


#ifndef SEEKER_H_
#define SEEKER_H_


// ---------- Header Inclusion ----------
#include <iostream>
#include <opencv2/opencv.hpp>


// ---------- Namespace ----------
using namespace std;
using namespace cv;


// ---------- Video Read Types ----------
enum VideoAPI
{
	FFMPEG = 0,		// Video Reading using FFmpeg
	OPENCV = 1		// Video Reading using OpenCV
};


// ---------- Class Declaration ----------
class Seeker
{
public:

	// Constructor
	Seeker(void);

	// Destructor
	~Seeker(void);

	// Open Video Source
	uint8_t open(const String &VideoSrc, VideoAPI Api);

	// Close Video Source
	void close(void);

	// Read Video Frames
	uint8_t getVideoFrame(Mat &VideoFrame);

	// Get Software Details
	string getSwDetails(void);


private:
	// Other Class Implementation
	class SeekerIMPL;
	SeekerIMPL *seekerIMPL;
};


#endif /* SEEKER_H_ */




