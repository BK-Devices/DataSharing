// ============================================================================
// Name		: Test3.cpp
// Date		: Feb 8, 2025
// ============================================================================


//#include <opencv2/opencv.hpp>
//#include <gst/gst.h>
//#include <gst/app/gstappsrc.h>
//#include <gst/rtsp-server/rtsp-server.h>
//#include <iostream>
//#include <chrono>
//#include <ctime>
//
//using namespace cv;
//using namespace std;
//
//#define WIDTH 640
//#define HEIGHT 480
//#define FPS 30
//
//GstElement *appsrc;
//
//// Callback when the RTSP server needs more data
//void need_data(GstElement *src, guint length, gpointer user_data) {
//    Mat frame, gray;
//    VideoCapture *cap = (VideoCapture *)user_data;
//
//    if (!cap->read(frame)) {
//        cerr << "Failed to read frame from camera!" << endl;
//        return;
//    }
//
//    // Convert to grayscale
//    cvtColor(frame, gray, COLOR_BGR2GRAY);
//
//    // Add timestamp
//    auto now = chrono::system_clock::now();
//    time_t t = chrono::system_clock::to_time_t(now);
//    string timestamp = ctime(&t);
//    putText(gray, timestamp, Point(10, 30), FONT_HERSHEY_SIMPLEX, 0.8, Scalar(255), 2);
//
////    imshow("VideoFrame", gray);
////
////	// Wait for a key press (optional)
////	if (waitKey(30) == 1) // Press 'Esc' to exit
////	{
//////		break;
////	}
//
//    // Draw a circle in the center
////    circle(gray, Point(WIDTH / 2, HEIGHT / 2), 25, Scalar(255), -1);
//
//    // Convert OpenCV Mat to GStreamer buffer
//    GstBuffer *buffer;
//    GstMapInfo map;
//    buffer = gst_buffer_new_allocate(NULL, WIDTH * HEIGHT, NULL);
//    gst_buffer_map(buffer, &map, GST_MAP_WRITE);
//    memcpy(map.data, gray.data, WIDTH * HEIGHT);
//    gst_buffer_unmap(buffer, &map);
//
//    // Push the buffer to GStreamer
//    GstFlowReturn ret;
//    g_signal_emit_by_name(appsrc, "push-buffer", buffer, &ret);
//    gst_buffer_unref(buffer);
//}
//
//// Create RTSP pipeline
//GstRTSPMediaFactory *create_pipeline(VideoCapture &cap) {
//    GstRTSPMediaFactory *factory = gst_rtsp_media_factory_new();
//    gst_rtsp_media_factory_set_launch(factory,
//        "( appsrc name=app_source is-live=true do-timestamp=true format=GST_FORMAT_TIME caps=\"video/x-raw,format=GRAY8,width=640,height=480,framerate=30/1\" ! videoconvert ! video/x-raw,format=I420 ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! rtph264pay name=pay0 pt=96 )");
//
//    // Attach to need-data signal
//    g_signal_connect(factory, "media-configure", G_CALLBACK(+[](GstRTSPMediaFactory *factory, GstRTSPMedia *media, gpointer user_data) {
//        GstElement *pipeline = gst_rtsp_media_get_element(media);
//        appsrc = gst_bin_get_by_name(GST_BIN(pipeline), "app_source");
//        g_signal_connect(appsrc, "need-data", G_CALLBACK(need_data), user_data);
//    }), &cap);
//
//    return factory;
//}
//
//int main(int argc, char *argv[]) {
//    gst_init(&argc, &argv);
//
//    // OpenCV camera
//    VideoCapture cap(0);
//    if (!cap.isOpened()) {
//        cerr << "Failed to open camera!" << endl;
//        return -1;
//    }
//    cap.set(CAP_PROP_FRAME_WIDTH, WIDTH);
//    cap.set(CAP_PROP_FRAME_HEIGHT, HEIGHT);
//    cap.set(CAP_PROP_FPS, FPS);
//
//    // Setup RTSP server
//    GstRTSPServer *server = gst_rtsp_server_new();
//    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);
//    GstRTSPMediaFactory *factory = create_pipeline(cap);
//    gst_rtsp_mount_points_add_factory(mounts, "/live", factory);
//
//    // Start the server
//    gst_rtsp_server_attach(server, NULL);
//    cout << "RTSP Server is running at rtsp://127.0.0.1:8554/live" << endl;
//
//    // Run main loop
//    GMainLoop *loop = g_main_loop_new(NULL, FALSE);
//    g_main_loop_run(loop);
//
//    return 0;
//}








//#include <opencv2/opencv.hpp>
//#include <gst/gst.h>
//#include <gst/app/gstappsrc.h>
//#include <gst/rtsp-server/rtsp-server.h>
//#include <iostream>
//#include <chrono>
//#include <ctime>
//
//using namespace cv;
//using namespace std;
//
//#define WIDTH 640
//#define HEIGHT 480
//#define FPS 30
//
//GstElement *appsrc;
//
//// 📌 Callback: Push frames from OpenCV to GStreamer
//void need_data(GstElement *src, guint length, gpointer user_data) {
//    Mat frame, gray;
//    VideoCapture *cap = (VideoCapture *)user_data;
//
//    if (!cap->read(frame)) {
//        cerr << "Failed to read frame from camera!" << endl;
//        return;
//    }
//
//    // Convert to grayscale
//    cvtColor(frame, gray, COLOR_BGR2GRAY);
//
//    // Add timestamp
//    auto now = chrono::system_clock::now();
//    time_t t = chrono::system_clock::to_time_t(now);
//    string timestamp = ctime(&t);
//    putText(gray, timestamp, Point(10, 30), FONT_HERSHEY_SIMPLEX, 0.8, Scalar(255), 2);
//
//    // Draw a circle in the center
////    circle(gray, Point(WIDTH / 2, HEIGHT / 2), 25, Scalar(255), -1);
//
//    // Convert OpenCV Mat to GStreamer buffer
//    GstBuffer *buffer;
//    GstMapInfo map;
//    buffer = gst_buffer_new_allocate(NULL, WIDTH * HEIGHT, NULL);
//    gst_buffer_map(buffer, &map, GST_MAP_WRITE);
//    memcpy(map.data, gray.data, WIDTH * HEIGHT);
//    gst_buffer_unmap(buffer, &map);
//
//    // Push buffer to GStreamer
//    GstFlowReturn ret;
//    g_signal_emit_by_name(appsrc, "push-buffer", buffer, &ret);
//    gst_buffer_unref(buffer);
//}
//
//// 📌 Create RTSP pipeline with ultra-low latency settings
//GstRTSPMediaFactory *create_pipeline(VideoCapture &cap) {
//    GstRTSPMediaFactory *factory = gst_rtsp_media_factory_new();
//    gst_rtsp_media_factory_set_launch(factory,
//        "( appsrc name=app_source is-live=true do-timestamp=true format=GST_FORMAT_TIME "
//        "caps=\"video/x-raw,format=GRAY8,width=640,height=480,framerate=30/1\" ! "
//        "videoconvert ! queue max-size-buffers=1 max-size-time=0 max-size-bytes=0 ! "
//        "video/x-raw,format=I420 ! x264enc tune=zerolatency speed-preset=ultrafast bitrate=500 key-int-max=15 ! "
//        "rtph264pay config-interval=1 name=pay0 pt=96 )");
//
//    // Attach to need-data signal
//    g_signal_connect(factory, "media-configure", G_CALLBACK(+[](GstRTSPMediaFactory *factory, GstRTSPMedia *media, gpointer user_data) {
//        GstElement *pipeline = gst_rtsp_media_get_element(media);
//        appsrc = gst_bin_get_by_name(GST_BIN(pipeline), "app_source");
//        g_object_set(G_OBJECT(appsrc), "format", GST_FORMAT_TIME, "is-live", TRUE, "blocksize", WIDTH * HEIGHT, NULL);
//        g_signal_connect(appsrc, "need-data", G_CALLBACK(need_data), user_data);
//    }), &cap);
//
//    return factory;
//}
//
//int main(int argc, char *argv[]) {
//    gst_init(&argc, &argv);
//
//    // OpenCV camera setup
//    VideoCapture cap(0);
//    if (!cap.isOpened()) {
//        cerr << "Failed to open camera!" << endl;
//        return -1;
//    }
//    cap.set(CAP_PROP_FRAME_WIDTH, WIDTH);
//    cap.set(CAP_PROP_FRAME_HEIGHT, HEIGHT);
//    cap.set(CAP_PROP_FPS, FPS);
//    cap.set(CAP_PROP_BUFFERSIZE, 1); // Drop old frames to reduce latency
//
//    // Setup RTSP server
//    GstRTSPServer *server = gst_rtsp_server_new();
//    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);
//    GstRTSPMediaFactory *factory = create_pipeline(cap);
//    gst_rtsp_mount_points_add_factory(mounts, "/live", factory);
//
//    // Start RTSP server
//    gst_rtsp_server_attach(server, NULL);
//    cout << "RTSP Server is running at rtsp://127.0.0.1:8554/live" << endl;
//
//    // Run main loop
//    GMainLoop *loop = g_main_loop_new(NULL, FALSE);
//    g_main_loop_run(loop);
//
//    return 0;
//}










