//// ============================================================================
//// Name		: RTSP.cpp
//// Date		: Jan 11, 2025
//// ============================================================================
//
//
//#include <gst/gst.h>
//#include <gst/rtsp-server/rtsp-server.h>
//
//// Callback to attach the timestamp overlay to the video stream
//static void configure_pipeline(GstRTSPMediaFactory *factory, GstRTSPMedia *media, gpointer user_data) {
//    GstElement *pipeline = gst_rtsp_media_get_element(media);
//    GstElement *overlay = gst_bin_get_by_name(GST_BIN(pipeline), "timestamp_overlay");
//    if (overlay) {
//        g_object_set(overlay, "text", "Live Stream", NULL);
//    }
//    gst_object_unref(pipeline);
//}
//
//int main(int argc, char *argv[]) {
//    // Initialize GStreamer
//    gst_init(&argc, &argv);
//
//    // Create the RTSP server
//    GstRTSPServer *server = gst_rtsp_server_new();
//    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);
//
//    // Create a factory for the media stream
//    GstRTSPMediaFactory *factory = gst_rtsp_media_factory_new();
//
//    // Pipeline to capture video from camera, add timestamp, and stream via RTSP
//    const gchar *pipeline_description =
//        "v4l2src device=/dev/video0 ! "
//        "videoconvert ! "
//        "clockoverlay halignment=center valignment=top font-desc=\"Sans, 18\" name=timestamp_overlay ! "
//        "x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
//        "rtph264pay config-interval=1 name=pay0 pt=96";
//
//    gst_rtsp_media_factory_set_launch(factory, pipeline_description);
//
//    // Configure the pipeline
//    g_signal_connect(factory, "media-configure", G_CALLBACK(configure_pipeline), NULL);
//
//    // Mount the factory on the RTSP server
//    gst_rtsp_mount_points_add_factory(mounts, "/live", factory);
//    g_object_unref(mounts);
//
//    // Start the RTSP server
//    if (gst_rtsp_server_attach(server, NULL) == 0) {
//        g_printerr("Failed to start RTSP server\n");
//        return -1;
//    }
//
//    g_print("RTSP server is running at rtsp://127.0.0.1:8554/live\n");
//
//    // Run the main loop
//    GMainLoop *loop = g_main_loop_new(NULL, FALSE);
//    g_main_loop_run(loop);
//
//    return 0;
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////extern "C" {
////#include <libavformat/avformat.h>
////#include <libavcodec/avcodec.h>
////#include <libswscale/swscale.h>
////#include <libavutil/time.h>
////#include <libavutil/imgutils.h>
////#include <libavutil/opt.h>
////#include <libavutil/timestamp.h>
////#include <libavutil/avstring.h>
////}
////
////#include <iostream>
////#include <sstream>
////#include <ctime>
////#include <iomanip>
////
////// Helper function to generate timestamp text
////std::string getTimestamp() {
////    std::ostringstream oss;
////    std::time_t now = std::time(nullptr);
////    oss << std::put_time(std::localtime(&now), "%Y-%m-%d %H:%M:%S");
////    return oss.str();
////}
////
////int main() {
////    // Initialize FFmpeg
////    avformat_network_init();
////
////    // Open the camera (device 0)
////    AVFormatContext* input_ctx = nullptr;
////    if (avformat_open_input(&input_ctx, "/home/bhavesh/Videos/Camera/CamVideo.mp4", nullptr, nullptr) < 0) {  // Change "/dev/video0" for Windows to "video=Your Camera Name"
////        std::cerr << "Error: Could not open camera!" << std::endl;
////        return -1;
////    }
////
////    if (avformat_find_stream_info(input_ctx, nullptr) < 0) {
////        std::cerr << "Error: Could not find stream information!" << std::endl;
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////
////    // Find the video stream index
////    int video_stream_index = -1;
////    for (unsigned int i = 0; i < input_ctx->nb_streams; i++) {
////        if (input_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
////            video_stream_index = i;
////            break;
////        }
////    }
////
////    if (video_stream_index == -1) {
////        std::cerr << "Error: No video stream found!" << std::endl;
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////
////    // Get the codec parameters and decoder
////    AVCodecParameters* codec_params = input_ctx->streams[video_stream_index]->codecpar;
////    const AVCodec* decoder = avcodec_find_decoder(codec_params->codec_id);
////    if (!decoder) {
////        std::cerr << "Error: Unsupported codec!" << std::endl;
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////
////    // Create decoder context
////    AVCodecContext* decoder_ctx = avcodec_alloc_context3(decoder);
////    if (!decoder_ctx) {
////        std::cerr << "Error: Could not allocate decoder context!" << std::endl;
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////    if (avcodec_parameters_to_context(decoder_ctx, codec_params) < 0) {
////        std::cerr << "Error: Could not copy codec parameters!" << std::endl;
////        avcodec_free_context(&decoder_ctx);
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////    if (avcodec_open2(decoder_ctx, decoder, nullptr) < 0) {
////        std::cerr << "Error: Could not open codec!" << std::endl;
////        avcodec_free_context(&decoder_ctx);
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////
////    // Prepare output (RTSP server)
////    const char* output_url = "rtsp://localhost:8554/live";
////    AVFormatContext* output_ctx = nullptr;
////    avformat_alloc_output_context2(&output_ctx, nullptr, "rtsp", output_url);
////    if (!output_ctx) {
////        std::cerr << "Error: Could not create output context!" << std::endl;
////        avcodec_free_context(&decoder_ctx);
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////
////    // Add video stream to output context
////    AVStream* out_stream = avformat_new_stream(output_ctx, nullptr);
////    if (!out_stream) {
////        std::cerr << "Error: Could not create output stream!" << std::endl;
////        avformat_free_context(output_ctx);
////        avcodec_free_context(&decoder_ctx);
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////
////    // Copy codec parameters from input to output
////    if (avcodec_parameters_copy(out_stream->codecpar, codec_params) < 0) {
////        std::cerr << "Error: Could not copy codec parameters!" << std::endl;
////        avformat_free_context(output_ctx);
////        avcodec_free_context(&decoder_ctx);
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////    out_stream->codecpar->codec_tag = 0;
////
////    // Open the RTSP output
////    if (avio_open(&output_ctx->pb, output_url, AVIO_FLAG_WRITE) < 0) {
////        std::cerr << "Error: Could not open output URL!" << std::endl;
////        avformat_free_context(output_ctx);
////        avcodec_free_context(&decoder_ctx);
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////
////    // Write the stream header
////    if (avformat_write_header(output_ctx, nullptr) < 0) {
////        std::cerr << "Error: Could not write header to RTSP stream!" << std::endl;
////        avio_closep(&output_ctx->pb);
////        avformat_free_context(output_ctx);
////        avcodec_free_context(&decoder_ctx);
////        avformat_close_input(&input_ctx);
////        return -1;
////    }
////
////    // Read frames from the input and send to the output
////    AVPacket packet;
////    av_init_packet(&packet);
////    while (av_read_frame(input_ctx, &packet) >= 0) {
////        if (packet.stream_index == video_stream_index) {
////            // Add timestamp overlay (optional, handled during rendering if using a GUI library)
////            std::string timestamp = getTimestamp();
////            std::cout << "Timestamp: " << timestamp << std::endl;
////
////            // Send the packet to the output
////            packet.pts = av_rescale_q(packet.pts, input_ctx->streams[video_stream_index]->time_base, out_stream->time_base);
////            packet.dts = av_rescale_q(packet.dts, input_ctx->streams[video_stream_index]->time_base, out_stream->time_base);
////            packet.duration = av_rescale_q(packet.duration, input_ctx->streams[video_stream_index]->time_base, out_stream->time_base);
////            packet.stream_index = out_stream->index;
////
////            if (av_interleaved_write_frame(output_ctx, &packet) < 0) {
////                std::cerr << "Error: Could not write frame!" << std::endl;
////                break;
////            }
////        }
////        av_packet_unref(&packet);
////    }
////
////    // Write the trailer and clean up
////    av_write_trailer(output_ctx);
////    avio_closep(&output_ctx->pb);
////    avformat_free_context(output_ctx);
////    avcodec_free_context(&decoder_ctx);
////    avformat_close_input(&input_ctx);
////    avformat_network_deinit();
////
////    return 0;
////}
//
//
//
//
//
//
//
