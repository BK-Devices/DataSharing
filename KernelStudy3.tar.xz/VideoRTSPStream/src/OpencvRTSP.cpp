// ============================================================================
// Name		: OpencvRTSP.cpp
// Date		: Feb 8, 2025
// ============================================================================


// Compilation - g++ -o gstreamer_rtsp_server gstreamer_rtsp_server.cpp `pkg-config --cflags --libs gstreamer-1.0 gstreamer-rtsp-server-1.0 opencv4`


//#include <gst/gst.h>
//#include <gst/rtsp-server/rtsp-server.h>
//#include <opencv2/opencv.hpp>
//#include <iostream>
//#include <ctime>
//
//using namespace cv;
//using namespace std;
//
//
//
//class CustomRTSPMediaFactory : public GstRTSPMediaFactory {
//protected:
//    void on_media_configure(GstRTSPMedia *media) {
//        GstElement *pipeline = gst_rtsp_media_get_element(media);
//        GstElement *source = gst_bin_get_by_name(GST_BIN(pipeline), "app_source");
//
//        if (source) {
//            g_object_set(source, "is-live", TRUE, "format", GST_FORMAT_TIME, NULL);
//        }
//
//        gst_object_unref(pipeline);
//    }
//
//public:
//    CustomRTSPMediaFactory() {
////        gst_rtsp_media_factory_set_launch(this,
////            "( appsrc name=app_source ! videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
////            "rtph264pay config-interval=1 name=pay0 pt=96 )");
//
////    	gst_rtsp_media_factory_set_launch(this,
////    	    "( appsrc name=app_source is-live=true format=GST_FORMAT_TIME caps=\"video/x-raw,format=GRAY8,width=640,height=480,framerate=30/1\" ! "
////    	    "videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
////    	    "rtph264pay config-interval=1 name=pay0 pt=96 )");
//
////    	gst_rtsp_media_factory_set_launch(this,
////    	    "( appsrc name=app_source is-live=true format=GST_FORMAT_TIME caps=\"video/x-raw,format=GRAY8,width=640,height=480,framerate=30/1\" ! "
////    	    "videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
////    	    "rtph264pay config-interval=1 name=pay0 pt=96 )");
//
////    	cout << "Pipeline - " << pipeline_string << endl;
////    	gst_rtsp_media_factory_set_launch(this, pipeline_string.c_str());
//
////    	string pipeline_string = "( appsrc name=app_source is-live=true do-timestamp=true format=GST_FORMAT_TIME caps=\"video/x-raw,format=I420,width=640,height=480,framerate=30/1\" ! "
////    		    "videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
////    		    "rtph264pay config-interval=1 name=pay0 pt=96 )";
////    	if (!this) {
////    	    std::cerr << "Error: CustomRTSPMediaFactory instance is null!" << std::endl;
////    	    return;
////    	}
////    	if (pipeline_string.empty()) {
////    	    std::cerr << "Error: Pipeline string is empty!" << std::endl;
////    	    return;
////    	}
////    	std::cout << "Pipeline: " << pipeline_string << std::endl;
////    	gst_rtsp_media_factory_set_launch(this, pipeline_string.c_str());
////
//
//    	GstRTSPMediaFactory *factory = gst_rtsp_media_factory_new();
//    	if (!factory) {
//    	    std::cerr << "Error: Failed to create media factory!" << std::endl;
//    	    return;
//    	}
//
//    	// Set the pipeline string
//    	std::string pipeline_string = "( appsrc name=app_source is-live=true do-timestamp=true format=GST_FORMAT_TIME "
//    	                              "caps=\"video/x-raw,format=I420,width=640,height=480,framerate=30/1\" ! "
//    	                              "videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
//    	                              "rtph264pay config-interval=1 name=pay0 pt=96 )";
//
//    	std::cout << "Pipeline: " << pipeline_string << std::endl;
//
//    	// Pass the pipeline string to the factory
////    	gst_rtsp_media_factory_set_launch(factory, pipeline_string.c_str());
//
//    	gst_rtsp_media_factory_set_launch(factory, "( fakesrc ! fakesink )");
//
//
//
//        g_signal_connect(this, "media-configure", G_CALLBACK(+[](GstRTSPMediaFactory *factory, GstRTSPMedia *media, gpointer user_data) {
//            static_cast<CustomRTSPMediaFactory *>(factory)->on_media_configure(media);
//        }), NULL);
//    }
//};
//
//// Function to get timestamp string
//string getTimestamp() {
//    time_t now = time(0);
//    struct tm tstruct;
//    char buf[80];
//    tstruct = *localtime(&now);
//    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tstruct);
//    return string(buf);
//}
//
//int main(int argc, char *argv[]) {
////    gst_init(&argc, &argv);
//    gst_init(nullptr, nullptr);
//
//
//    // Open camera
////    VideoCapture cap(0);  // /dev/video0
////    if (!cap.isOpened()) {
////        cerr << "Error: Could not open camera!" << endl;
////        return -1;
////    }
//
//    VideoCapture cap(0, CAP_V4L2);  // Force Video4Linux2 API
//    if (!cap.isOpened()) {
//        cerr << "Error: Could not open camera!" << endl;
//        return -1;
//    }
//    cap.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M', 'J', 'P', 'G'));  // Try MJPG format
//    cap.set(CAP_PROP_FRAME_WIDTH, 640);
//    cap.set(CAP_PROP_FRAME_HEIGHT, 480);
//    cap.set(CAP_PROP_FPS, 30);
//
//
//    int frame_width = 640;
//    int frame_height = 480;
////    cap.set(CAP_PROP_FRAME_WIDTH, frame_width);
////    cap.set(CAP_PROP_FRAME_HEIGHT, frame_height);
//
//    GstRTSPServer *server = gst_rtsp_server_new();
//    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);
////    CustomRTSPMediaFactory *factory = new CustomRTSPMediaFactory();
//
//    CustomRTSPMediaFactory *factory = new CustomRTSPMediaFactory();
//    if (!factory) {
//        std::cerr << "Error: Failed to create media factory!" << std::endl;
//        return -1;
//    }
//
//
//    gst_rtsp_mount_points_add_factory(mounts, "/live", factory);
//    g_object_unref(mounts);
//
//    if (gst_rtsp_server_attach(server, NULL) == 0) {
//        cerr << "Failed to start RTSP server" << endl;
//        return -1;
//    }
//
//    cout << "RTSP Server is running at rtsp://127.0.0.1:8554/live" << endl;
//
//    // GStreamer AppSrc Pipeline
//    GstElement *pipeline = gst_pipeline_new("video_pipeline");
//    GstElement *appsrc = gst_element_factory_make("appsrc", "app_source");
//    GstElement *convert = gst_element_factory_make("videoconvert", "convert");
//    GstElement *encoder = gst_element_factory_make("x264enc", "encoder");
//    GstElement *payloader = gst_element_factory_make("rtph264pay", "payloader");
//    GstElement *sink = gst_element_factory_make("udpsink", "sink");
//
//    gst_bin_add_many(GST_BIN(pipeline), appsrc, convert, encoder, payloader, sink, NULL);
//    gst_element_link_many(appsrc, convert, encoder, payloader, sink, NULL);
//
//    g_object_set(G_OBJECT(appsrc), "is-live", TRUE, "format", GST_FORMAT_TIME, NULL);
//    g_object_set(G_OBJECT(sink), "host", "127.0.0.1", "port", 5000, NULL);
//
//    GstBuffer *buffer;
//    GstFlowReturn ret;
//    int fps = 30;
//    int frame_size = frame_width * frame_height * 3;
//
//    while (true) {
//        Mat frame, gray_frame, resized_frame;
//        cap >> frame;
//        if (frame.empty()) {
//            cerr << "Error: Empty frame!" << endl;
//            break;
//        }
//
//        // Convert to grayscale
//        cvtColor(frame, gray_frame, COLOR_BGR2GRAY);
//
//        // Resize
//        resize(gray_frame, resized_frame, Size(frame_width, frame_height));
//
//        // Add timestamp
//        putText(resized_frame, getTimestamp(), Point(10, 30), FONT_HERSHEY_SIMPLEX, 1, Scalar(255), 2);
//
//        // Display the processed frame
//        imshow("Processed Frame", resized_frame);
//        if (waitKey(1) == 5) break; // Press 'ESC' to exit
//
//        // Convert frame to GStreamer buffer
//
//        buffer = gst_buffer_new_allocate(NULL, resized_frame.total() * resized_frame.elemSize(), NULL);
//        GstMapInfo map;
//        if (gst_buffer_map(buffer, &map, GST_MAP_WRITE)) {
//            memcpy(map.data, resized_frame.data, resized_frame.total() * resized_frame.elemSize());
//            gst_buffer_unmap(buffer, &map);
//        }
//
//
//
//
////        buffer = gst_buffer_new_allocate(NULL, frame_size, NULL);
////        GstMapInfo map;
////        gst_buffer_map(buffer, &map, GST_MAP_WRITE);
////        memcpy(map.data, resized_frame.data, frame_size);
////        gst_buffer_unmap(buffer, &map);
//
//        GST_BUFFER_PTS(buffer) = gst_util_uint64_scale(gst_clock_get_time(gst_system_clock_obtain()), fps, GST_SECOND);
//        GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale(1, GST_SECOND, fps);
//
//        g_signal_emit_by_name(appsrc, "push-buffer", buffer, &ret);
//        gst_buffer_unref(buffer);
//
//        if (ret != GST_FLOW_OK) {
//            cerr << "Error: Pushing buffer to GStreamer failed!" << endl;
//            break;
//        }
//    }
//
//    cap.release();
//    gst_element_set_state(pipeline, GST_STATE_NULL);
//    gst_object_unref(pipeline);
//    return 0;
//}






