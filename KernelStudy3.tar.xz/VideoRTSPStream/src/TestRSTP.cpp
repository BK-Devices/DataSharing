// ============================================================================
// Name		: TestRSTP.cpp
// Date		: Feb 8, 2025
// ============================================================================

//#include <iostream>
//#include <gst/gst.h>
//#include <gst/rtsp-server/rtsp-server.h>
//
//static GstRTSPMediaFactory *factory = NULL;
//static GstRTSPServer *server = NULL;
//
//int main(int argc, char *argv[]) {
//    gst_init(&argc, &argv);
//
//    server = gst_rtsp_server_new();
//    g_object_set(server, "service", "8554", NULL);
//
//    factory = gst_rtsp_media_factory_new();
//    gst_rtsp_media_factory_set_launch(factory, "( videotestsrc ! videoconvert ! x264enc ! rtph264pay name=pay0 pt=96 )");
//
//    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);
//    gst_rtsp_mount_points_add_factory(mounts, "/test", factory);
//
//    gst_rtsp_server_attach(server, NULL);
//
//    g_print("RTSP server running at rtsp://127.0.0.1:8554/test\n");
//    g_main_loop_run(g_main_loop_new(NULL, FALSE));
//
//    return 0;
//}
//
//

