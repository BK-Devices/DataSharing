//// ============================================================================
//// Name		: test4.cpp
//// Date		: Feb 8, 2025
//// ============================================================================
//
//#include <opencv2/opencv.hpp>
//#include <opencv2/imgproc.hpp>
//#include <opencv2/highgui.hpp>
//#include <gst/gst.h>
//#include <gst/app/gstappsrc.h>
//#include <iostream>
//#include <queue>
//#include <thread>
//#include <mutex>
//#include <condition_variable>
//
//using namespace cv;
//using namespace std;
//
//queue<Mat> frameQueue;
//mutex queueMutex;
//condition_variable frameAvailable;
//bool keepRunning = true;
//
//void processFrames() {
//    VideoCapture cap(0);
//    if (!cap.isOpened()) {
//        cerr << "Error: Cannot open camera." << endl;
//        return;
//    }
//
//    while (keepRunning) {
//        Mat frame, gray;
//        cap >> frame;
//        if (frame.empty()) break;
//
//        cvtColor(frame, gray, COLOR_BGR2GRAY);
//
//        // Add timestamp
//        string timestamp = to_string(time(0));
//        putText(gray, timestamp, Point(10, 30), FONT_HERSHEY_SIMPLEX, 1, Scalar(255), 2);
//
//        // Detect circles
//        vector<Vec3f> circles;
//        HoughCircles(gray, circles, HOUGH_GRADIENT, 1, gray.rows / 8, 100, 30, 25, 30);
//        for (size_t i = 0; i < circles.size(); i++) {
//            circle(gray, Point(circles[i][0], circles[i][1]), circles[i][2], Scalar(255), 2);
//        }
//
//        {
//            lock_guard<mutex> lock(queueMutex);
//            frameQueue.push(gray);
//        }
//        frameAvailable.notify_one();
//
//        imshow("Processed Video", gray);
//        if (waitKey(1) == 27) break;
//    }
//    cap.release();
//    keepRunning = false;
//}
//
//void streamRTSP() {
//    gst_init(nullptr, nullptr);
//    GstElement *pipeline, *appsrc;
//    GstCaps *caps;
//
//    string pipelineStr = "appsrc name=appsrc ! videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! rtph264pay config-interval=1 name=pay0 pt=96 ! udpsink host=127.0.0.1 port=8554";
//    pipeline = gst_parse_launch(pipelineStr.c_str(), nullptr);
//    appsrc = gst_bin_get_by_name(GST_BIN(pipeline), "appsrc");
//
//    caps = gst_caps_new_simple("video/x-raw",
//                               "format", G_TYPE_STRING, "GRAY8",
//                               "width", G_TYPE_INT, 640,
//                               "height", G_TYPE_INT, 480,
//                               "framerate", GST_TYPE_FRACTION, 30, 1,
//                               NULL);
//    gst_app_src_set_caps(GST_APP_SRC(appsrc), caps);
//    gst_caps_unref(caps);
//
//    gst_element_set_state(pipeline, GST_STATE_PLAYING);
//
//    while (keepRunning) {
//        unique_lock<mutex> lock(queueMutex);
//        frameAvailable.wait(lock, [] { return !frameQueue.empty() || !keepRunning; });
//        if (!keepRunning) break;
//
//        Mat frame = frameQueue.front();
//        frameQueue.pop();
//        lock.unlock();
//
//        GstBuffer *buffer = gst_buffer_new_allocate(NULL, frame.total(), NULL);
//        GstMapInfo map;
//        gst_buffer_map(buffer, &map, GST_MAP_WRITE);
//        memcpy(map.data, frame.data, frame.total());
//        gst_buffer_unmap(buffer, &map);
//
//        gst_app_src_push_buffer(GST_APP_SRC(appsrc), buffer);
//    }
//
//    gst_element_set_state(pipeline, GST_STATE_NULL);
//    gst_object_unref(pipeline);
//}
//
//int main() {
//    thread processingThread(processFrames);
//    thread streamingThread(streamRTSP);
//
//    processingThread.join();
//    keepRunning = false;
//    frameAvailable.notify_all();
//    streamingThread.join();
//
//    return 0;
//}





























#include <opencv2/opencv.hpp>
#include <gst/gst.h>
#include <gst/app/gstappsrc.h>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <chrono>

#define FRAME_WIDTH 640
#define FRAME_HEIGHT 480
#define FPS 30

std::queue<cv::Mat> frameQueue;
std::mutex queueMutex;
std::condition_variable queueCondVar;
bool running = true;

void videoCaptureThread() {
    cv::VideoCapture cap(0);
    if (!cap.isOpened()) {
        std::cerr << "Error: Unable to open camera" << std::endl;
        return;
    }
    cap.set(cv::CAP_PROP_FRAME_WIDTH, FRAME_WIDTH);
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT);
    cap.set(cv::CAP_PROP_FPS, FPS);

    while (running) {
        cv::Mat frame;
        cap >> frame;
        if (frame.empty()) continue;

        // Convert to grayscale
        cv::cvtColor(frame, frame, cv::COLOR_BGR2GRAY);

        // Add timestamp
        auto now = std::chrono::system_clock::now();
        auto now_c = std::chrono::system_clock::to_time_t(now);
        cv::putText(frame, std::ctime(&now_c), cv::Point(10, 30),
                    cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(255), 2);

        // Draw a circle at the center
        cv::circle(frame, cv::Point(FRAME_WIDTH / 2, FRAME_HEIGHT / 2),
                   25, cv::Scalar(255), 2);

        {
            std::lock_guard<std::mutex> lock(queueMutex);
            frameQueue.push(frame);
        }
        queueCondVar.notify_one();

        cv::imshow("Processed Video", frame);
        if (cv::waitKey(1) == 27) break;  // Exit on ESC
    }
    running = false;
}

void rtspStreamingThread() {
    GstElement *pipeline, *appsrc;
    GstBus *bus;
    GMainLoop *loop;

    gst_init(nullptr, nullptr);
    loop = g_main_loop_new(nullptr, FALSE);

    std::string pipelineStr = "appsrc name=app_source is-live=true do-timestamp=true "
                               "caps=\"video/x-raw,format=GRAY8,width=640,height=480,framerate=30/1\" ! "
                               "videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
                               "rtph264pay name=pay0 pt=96";

    pipeline = gst_parse_launch(pipelineStr.c_str(), nullptr);
    appsrc = gst_bin_get_by_name(GST_BIN(pipeline), "app_source");

    if (!pipeline || !appsrc) {
        std::cerr << "Error: Failed to create GStreamer pipeline" << std::endl;
        return;
    }

    gst_element_set_state(pipeline, GST_STATE_PLAYING);

    while (running) {
        std::unique_lock<std::mutex> lock(queueMutex);
        queueCondVar.wait(lock, [] { return !frameQueue.empty() || !running; });
        if (!running) break;

        cv::Mat frame = frameQueue.front();
        frameQueue.pop();
        lock.unlock();

        GstBuffer *buffer = gst_buffer_new_allocate(nullptr, frame.total(), nullptr);
        GstMapInfo map;
        gst_buffer_map(buffer, &map, GST_MAP_WRITE);
        memcpy(map.data, frame.data, frame.total());
        gst_buffer_unmap(buffer, &map);

        GST_BUFFER_PTS(buffer) = gst_util_uint64_scale(gst_clock_get_time(gst_system_clock_obtain()), 1, 1000000);
        GST_BUFFER_DURATION(buffer) = gst_util_uint64_scale(1, GST_SECOND, FPS);

        GstFlowReturn ret;
        g_signal_emit_by_name(appsrc, "push-buffer", buffer, &ret);
        if (ret != GST_FLOW_OK) {
            std::cerr << "Error pushing buffer" << std::endl;
        }
        gst_buffer_unref(buffer);
    }

    gst_element_set_state(pipeline, GST_STATE_NULL);
    gst_object_unref(pipeline);
    g_main_loop_unref(loop);
}

int main() {
    std::thread videoThread(videoCaptureThread);
    std::thread rtspThread(rtspStreamingThread);

    videoThread.join();
    running = false;
    queueCondVar.notify_all();
    rtspThread.join();

    return 0;
}
