////============================================================================
//// Name        : VideoRTSPStream.cpp
//// Author      : Bhavesh Kale
//// Version     :
//// Copyright   : Your copyright notice
//// Description : Hello World in C++, Ansi-style
////============================================================================
//
//#include <iostream>
//#include <gst/gst.h>
//#include <gst/rtsp-server/rtsp-server.h>
//
//using namespace std;
//
//// RTSP Media Factory Class
//class CustomRTSPMediaFactory : public GstRTSPMediaFactory
//{
//protected:
//    void on_media_configure(GstRTSPMedia *media)
//    {
//        GstElement *pipeline = gst_rtsp_media_get_element(media);
//        GstElement *source = gst_bin_get_by_name(GST_BIN(pipeline), "v4l2_source");
//        if (source)
//        {
//            g_object_set(source, "device", "/dev/video0", NULL);
//        }
//        gst_object_unref(pipeline);
//    }
//
//public:
//    CustomRTSPMediaFactory()
//    {
//        gst_rtsp_media_factory_set_launch(this,
//            "( v4l2src name=v4l2_source device=/dev/video0 ! "
//            "videoconvert ! clockoverlay halignment=center valignment=top font-desc=\"Sans, 18\" ! "
//            "x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
//            "rtph264pay config-interval=1 name=pay0 pt=96 )");
//        g_signal_connect(this, "media-configure", G_CALLBACK(+[](GstRTSPMediaFactory *factory, GstRTSPMedia *media, gpointer user_data) {
//            static_cast<CustomRTSPMediaFactory *>(factory)->on_media_configure(media);
//        }), NULL);
//    }
//};
//
//int main(int argc, char *argv[])
//{
//    gst_init(&argc, &argv);
//
//    // Create the RTSP server
//    GstRTSPServer *server = gst_rtsp_server_new();
//    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);
//
//    // Create and configure the media factory
//    CustomRTSPMediaFactory *factory = new CustomRTSPMediaFactory();
//    gst_rtsp_mount_points_add_factory(mounts, "/live", factory);
//    g_object_unref(mounts);
//
//    // Start the server
//    if (gst_rtsp_server_attach(server, NULL) == 0)
//    {
//        g_printerr("Failed to start RTSP server\n");
//        return -1;
//    }
//
//    g_print("RTSP server is running at rtsp://127.0.0.1:8554/live\n");
//
//    // Run the main loop
//    GMainLoop *loop = g_main_loop_new(NULL, FALSE);
//    g_main_loop_run(loop);
//
//    return 0;
//}
