// ============================================================================
// Name		: Test1.cpp
// Date		: Feb 8, 2025
// ============================================================================




//#include <iostream>
//#include <gst/gst.h>
//#include <gst/rtsp-server/rtsp-server.h>
//
//static GstRTSPMediaFactory *factory = NULL;
//static GstRTSPServer *server = NULL;
//
//int main(int argc, char *argv[]) {
//    gst_init(&argc, &argv);
//
//    // Initialize RTSP server
//    server = gst_rtsp_server_new();
//    g_object_set(server, "service", "8554", NULL);
//
//    // Initialize media factory
//    factory = gst_rtsp_media_factory_new();
//    if (!factory) {
//        std::cerr << "Error: Failed to create media factory!" << std::endl;
//        return -1;
//    }
//
//    // Define the pipeline for the media factory
//    std::string pipeline_string = "( appsrc name=app_source is-live=true do-timestamp=true format=GST_FORMAT_TIME "
//                                  "caps=\"video/x-raw,format=I420,width=640,height=480,framerate=30/1\" ! "
//                                  "videoconvert ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast ! "
//                                  "rtph264pay config-interval=1 name=pay0 pt=96 )";
//
//    std::cout << "Pipeline: " << pipeline_string << std::endl;
//
//    // Set the pipeline string to the media factory
//    gst_rtsp_media_factory_set_launch(factory, pipeline_string.c_str());
//
//    // Get the mount points and add the factory to the RTSP server
//    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);
//    gst_rtsp_mount_points_add_factory(mounts, "/live", factory);
//
//    // Attach the RTSP server to the default main context
//    gst_rtsp_server_attach(server, NULL);
//
//    // Print RTSP URL and run the main loop
//    std::cout << "RTSP Server is running at rtsp://127.0.0.1:8554/live" << std::endl;
//    g_main_loop_run(g_main_loop_new(NULL, FALSE));
//
//    return 0;
//}





