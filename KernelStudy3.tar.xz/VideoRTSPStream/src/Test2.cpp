
// Working Code














//#include <gst/gst.h>
//#include <gst/rtsp-server/rtsp-server.h>
//#include <iostream>
//
//static void media_configure_callback(GstRTSPMediaFactory *factory, GstRTSPMedia *media, gpointer user_data) {
//    // Get the pipeline from media
//    GstElement *pipeline = gst_rtsp_media_get_element(media);
//
//    // Get the appsrc element from the pipeline
//    GstElement *appsrc = gst_bin_get_by_name(GST_BIN(pipeline), "camera_source");
//    if (!appsrc) {
//        std::cerr << "Error: Could not find camera source in pipeline!" << std::endl;
//        return;
//    }
//
//    // Store the appsrc pointer
//    *(GstElement **)user_data = appsrc;
//
//    // Release reference to pipeline
//    gst_object_unref(pipeline);
//}
//
//int main(int argc, char *argv[]) {
//    gst_init(&argc, &argv);
//
//    // Create RTSP server
//    GstRTSPServer *server = gst_rtsp_server_new();
//    g_object_set(server, "service", "8554", NULL);
//
//    // Create RTSP media factory
//    GstRTSPMediaFactory *factory = gst_rtsp_media_factory_new();
//    gst_rtsp_media_factory_set_launch(factory,
//        "( v4l2src name=camera_source ! videoconvert ! videoscale ! clockoverlay "
//        "! videoconvert ! video/x-raw,format=GRAY8 ! x264enc tune=zerolatency bitrate=500 speed-preset=superfast "
//        "! rtph264pay config-interval=1 name=pay0 pt=96 )");
//
//    // Store appsrc pointer
//    GstElement *appsrc = NULL;
//
//    // Connect callback to configure media
//    g_signal_connect(factory, "media-configure", G_CALLBACK(media_configure_callback), &appsrc);
//
//    // Attach RTSP mount points
//    GstRTSPMountPoints *mounts = gst_rtsp_server_get_mount_points(server);
//    gst_rtsp_mount_points_add_factory(mounts, "/live", factory);
//    g_object_unref(mounts);
//
//    // Attach RTSP server
//    gst_rtsp_server_attach(server, NULL);
//
//    std::cout << "RTSP Server is running at rtsp://127.0.0.1:8554/live" << std::endl;
//
//    // Run main loop
//    GMainLoop *loop = g_main_loop_new(NULL, FALSE);
//    g_main_loop_run(loop);
//
//    return 0;
//}
