// ============================================================================
// Name		: DataTypes.h
// Date		: Feb 13, 2025
// ============================================================================


#ifndef DATATYPES_H_
#define DATATYPES_H_


typedef char					Int8_t;
typedef unsigned char			UInt8_t;

typedef short int				Int16_t;
typedef unsigned short int		UInt16_t;

typedef int						Int32_t;
typedef unsigned int			UInt32_t;

typedef long long int			Int64_t;
typedef unsigned long long int	UInt64_t;


#endif /* DATATYPES_H_ */




