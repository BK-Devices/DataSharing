// ============================================================================
// Name		: Variables.h
// Date		: Aug 3, 2025
// ============================================================================


#ifndef VARIABLES_H_
#define VARIABLES_H_

#include "DataTypes.h"
#include <iostream>
using namespace std;

UInt32_t var1 = 45;
UInt32_t var2 = 69;


void func(void);


#endif /* VARIABLES_H_ */
