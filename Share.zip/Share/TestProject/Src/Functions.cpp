// ============================================================================
// Name		: Functions.cpp
// Date		: Aug 3, 2025
// ============================================================================



#include "Variables.h"

void func(void)
{
	cout << "func var1 : " << var1 << endl;
	cout << "func var2 : " << var2 << endl;
	return;
}



