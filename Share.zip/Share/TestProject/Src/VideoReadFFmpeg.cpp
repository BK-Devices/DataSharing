
#if 0

#include <iostream>

#include <string>
#include <fstream>
#include <unistd.h>
#include <sys/time.h>
#include <opencv2/opencv.hpp>

#include "DataTypes.h"

extern "C"
{
	#include <libavutil/avutil.h>
	#include <libavcodec/avcodec.h>
	#include <libswscale/swscale.h>
	#include <libavutil/imgutils.h>
	#include <libavformat/avformat.h>
	#include <libavdevice/avdevice.h>
}

using namespace std;
using namespace cv;

string VideoSource = "/dev/video0";
//string VideoSource = "/home/bhavesh/Videos/Camera/CamVideo.mp4";

//UInt32_t VideoFps = 30;
//UInt32_t FrameDelay = 1000 * 1000 / VideoFps;


// ---------- Get TimeStamp ----------
string getTimeStamp(void)
{
	struct timeval tv;
	struct tm *tm_info;
	Int8_t timeStamp[30] = {0};

	gettimeofday(&tv, NULL);
	tm_info = localtime(&tv.tv_sec);

	strftime(timeStamp, sizeof(timeStamp), "%d-%m-%y %H:%M:%S.", tm_info);
	sprintf(timeStamp+strlen(timeStamp), "%03ld", tv.tv_usec/1000);

	return string(timeStamp);
}


class Seeker
{
private:
	AVPacket *packet;
	AVCodecContext *pCodecCtx;
	AVFormatContext *pFormatCtx;
	AVFrame *pFrame, *pFrameBGR;
	struct SwsContext *img_convert_ctx;

	UInt8_t *out_buffer;
//	Int32_t FrameDelay;
	Int32_t videoStream, ret;


public:
	Seeker(void);
	~Seeker(void);
	void readFrames(void);
};

Seeker::Seeker(void)
{
//	double VideoFps;
	Int8_t errbuf[128];
	Int32_t numBytes, y_size;

	const AVCodec *pCodec;
	AVInputFormat* inputFormat;
	AVDictionary *avdic = nullptr;


	avformat_network_init();
	pFormatCtx = avformat_alloc_context();

	// If reading video from RTSP or HTTP
	if(VideoSource.find("rtsp://") == 0 || VideoSource.find("http://") == 0 || VideoSource.find("https://") == 0)
	{
		// Specify rtsp details
		av_dict_set(&avdic, "rtsp_transport", "tcp", 0);
		av_dict_set(&avdic, "max_delay", "100", 0);
	}

	// If reading video from Camera
	else if(VideoSource.find("/dev/video") == 0)
	{
		// Specify input format
		avdevice_register_all();
		inputFormat = av_find_input_format("v4l2");
		if(!inputFormat)
		{
			cerr << "ERROR! v4l2 input format not found" << endl;
			exit(1);
		}
	}

	// If reading video from File
	else
	{

	}

	// Buffer to hold error messages
	ret = avformat_open_input(&pFormatCtx, VideoSource.c_str(), inputFormat, &avdic);
	if(ret != 0)
	{
		av_strerror(ret, errbuf, sizeof(errbuf));  // Get detailed error message
		cerr << "ERROR! Unable to open video source " << VideoSource << endl;
		cerr << "FFmpeg error: " << errbuf << endl;
		exit(1);
	}

	// Get stream information
	if(avformat_find_stream_info(pFormatCtx, NULL) < 0)
	{
		cerr << "ERROR! Unable to get video source information" << endl;
		exit(1);
	}

	// Find the video stream
	for(unsigned int i = 0; i < pFormatCtx->nb_streams; i++)
	{
		if(pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			videoStream = i;
			break;
		}
	}

	if(videoStream == -1)
	{
		cerr << "ERROR! Unable to get video stream" << endl;
		exit(1);
	}

//	VideoFps = av_q2d(pFormatCtx->streams[videoStream]->avg_frame_rate);
//	if(VideoFps <= 0.0 || VideoFps > 1000.0)
//	{
//		VideoFps = 30.0;
//	}
//	FrameDelay = static_cast<Int32_t>(1000.0 / VideoFps);

	// Get codec context
	pCodecCtx = avcodec_alloc_context3(NULL);
	avcodec_parameters_to_context(pCodecCtx, pFormatCtx->streams[videoStream]->codecpar);
	pCodec = avcodec_find_decoder(pCodecCtx->codec_id);

	if(pCodec == NULL)
	{
		cerr << "ERROR! Codec not found" << endl;
		exit(1);
	}

	if(avcodec_open2(pCodecCtx, pCodec, NULL) < 0)
	{
		cerr << "ERROR! Failed to open codec" << endl;
		exit(1);
	}

	pFrame = av_frame_alloc();
	pFrameBGR = av_frame_alloc();

	img_convert_ctx = sws_getContext(pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt, pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BICUBIC, NULL, NULL, NULL);

	numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1);
	out_buffer = (uint8_t*) av_malloc(numBytes * sizeof(uint8_t));

	av_image_fill_arrays(pFrameBGR->data, pFrameBGR->linesize, out_buffer, AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1);

	y_size = pCodecCtx->width * pCodecCtx->height;
	packet = (AVPacket*) malloc(sizeof(AVPacket));
	av_new_packet(packet, y_size);
}


Seeker::~Seeker(void)
{
	av_free(out_buffer);
	av_free(pFrameBGR);
	avcodec_close(pCodecCtx);
	avformat_close_input(&pFormatCtx);
}

void Seeker::readFrames(void)
{
	Mat VideoFrame;
	string TimeStamp;

	[[maybe_unused]]Int32_t SleepTime=0;
	struct timeval timCntStart, timCntEnd;
	double timCntElapse;

	VideoFrame.create(pCodecCtx->height, pCodecCtx->width, CV_8UC3);

	while (true)
	{
		// Start measuring execution time
		gettimeofday(&timCntStart, nullptr);

//		if(av_read_frame(pFormatCtx, packet) < 0)
//		{
//			cerr << "Error! Failed to read video" << endl;
//			exit(1);
//		}
//
//		if(packet->stream_index == videoStream)
//		{
//			ret = avcodec_send_packet(pCodecCtx, packet);
//			if(ret != 0)
//			{
//				cerr << "Error! Failed to decode" << endl;
//				exit(1);
//			}
//
//			ret = avcodec_receive_frame(pCodecCtx, pFrame);
//			if(ret == 0)
//			{
//				sws_scale(img_convert_ctx, (uint8_t const * const *) pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameBGR->data, pFrameBGR->linesize);
//				memcpy(VideoFrame.data, pFrameBGR->data[0], pCodecCtx->height * pFrameBGR->linesize[0]);
//			}
//			else
//			{
//				cerr << "Error! While reading video frames" << endl;
//				exit(1);
//			}
//		}
//
//		av_packet_unref(packet);


		// Flush old packets from the queue
		while (av_read_frame(pFormatCtx, packet) >= 0)
		{
			if (packet->stream_index != videoStream)
			{
				av_packet_unref(packet);
				continue;
			}

			// Drop all older packets until latest
			while (avcodec_send_packet(pCodecCtx, packet) == AVERROR(EAGAIN))
			{
				avcodec_receive_frame(pCodecCtx, pFrame); // drop old one
			}

			int ret = avcodec_send_packet(pCodecCtx, packet);
			av_packet_unref(packet);

			if (ret < 0) continue;

			// Try to get latest decoded frame
			while (true)
			{
				ret = avcodec_receive_frame(pCodecCtx, pFrame);
				if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
					break;
				else if (ret < 0)
				{
					std::cerr << "Error decoding frame" << std::endl;
					break;
				}

				sws_scale(img_convert_ctx,
						  (uint8_t const* const*)pFrame->data,
						  pFrame->linesize,
						  0,
						  pCodecCtx->height,
						  pFrameBGR->data,
						  pFrameBGR->linesize);

				memcpy(VideoFrame.data, pFrameBGR->data[0],
					   pCodecCtx->height * pFrameBGR->linesize[0]);

//				imshow("Video", VideoFrame);
//				if (waitKey(1) == 'q') return;
			}

			break;  // After showing latest frame
		}































//		resize(VideoFrame, VideoFrame, VideoDim);				// Resize it if needed

		// Set and add timestamp in VideoFrame
		TimeStamp = getTimeStamp();
		putText(VideoFrame, TimeStamp, Point(10, 20), FONT_HERSHEY_SIMPLEX, 0.4, Scalar(255, 255, 255), 1);

		imshow("Video", VideoFrame);
		if(waitKey(1) == 'q')
		{
			break;
		}

		// Stop Measuring execution time
		gettimeofday(&timCntEnd, nullptr);

		// Calculate the reading & sleep time in milliseconds
		timCntElapse = (timCntEnd.tv_sec - timCntStart.tv_sec) + ((timCntEnd.tv_usec - timCntStart.tv_usec) / 1e3);
//		SleepTime = FrameDelay - (timCntElapse * 1000) - 1;

		cout << " Reading Time - " << timCntElapse << " ms" << endl << flush;
//		cout << SleepTime << endl;

//		if(SleepTime > 0)
//		{
//			usleep(SleepTime);
//		}

//		if(!(VideoSource.find("rtsp://") == 0 || VideoSource.find("http://") == 0 || VideoSource.find("https://") == 0 || VideoSource.find("/dev/video") == 0) && SleepTime > 0)
//		{
//			usleep(SleepTime * 1000);
//		}
	}
}

int main(void)
{
	Seeker seekerObj;
	seekerObj.readFrames();
	return 0;
}


#endif


