// ============================================================================
// Name		: VideoRead.cpp
// Date		: Jan 4, 2025
// ============================================================================

#if 0


#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main()
{
    VideoCapture cap("/dev/video0");
//    VideoCapture cap("rtsp://127.0.0.1:8554/live");


    if (!cap.isOpened())
    {
        cerr << "Error opening video file!" << endl;
        return -1;
    }

    while(true)
    {
        Mat frame;
        cap >> frame; // Read a frame from the video

        if(frame.empty())
        {
            break; // End of video
        }

        // Process the frame (e.g., display it)
        imshow("Video Frame", frame);

        // Wait for a key press (optional)
        if (waitKey(30) == 27) // Press 'Esc' to exit
        {
        	break;
        }
    }

    cap.release(); // Release the video file
    destroyAllWindows(); // Close all windows

    return 0;
}

#endif



