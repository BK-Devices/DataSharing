
#include <iostream>

#include <cstring>

#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <ifaddrs.h>
#include <termios.h>

#include <time.h>


#include "DataTypes.h"


#define  ObcRS422Port 	"/dev/ttyTHS1"			// OBC RS422 Port
#define  ObcRS422BAUD 	B921600					// OBC RS422 Baud Rate

#define  OBCCard_ID		0x09
#define  IPCard_ID		0x37


using namespace std;



#pragma pack(1)

struct _IPStat_
{
	UInt32_t CameraStatus 	: 1;
	UInt32_t NUCStatus 		: 1;
	UInt32_t IPAddrStatus 	: 1;
	UInt32_t AIStatusFlag 	: 1;
	UInt32_t Reserved1 		: 1;
	UInt32_t Reserved2 		: 1;
	UInt32_t Reserved3 		: 1;
	UInt32_t Reserved4 		: 1;
};


// RS422 OBC Command Union-Structure
union _ObcCmd_
{
	// Obc command buffer
	UInt8_t ObcCmdBuff[20];

	// Time Sync command
	struct _ConfigCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t MissileID;
		UInt32_t Time;
		UInt8_t Day;
		UInt8_t Month;
		UInt16_t Year;
		UInt8_t CheckSum;
	} ConfigCmd;


	// Health command
	struct _HealthCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t Dummy;
		UInt8_t CheckSum;
	} HealthCmd;


	// Nuc command
	struct _NucCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t Dummy;
		UInt8_t CheckSum;
	} NucCmd;


	// Shut Down command
	struct _ShutDownCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t Dummy;
		UInt8_t CheckSum;
	} ShutDownCmd;


	// Target data command
	struct _TargetDataCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		Int16_t Ny;
		Int16_t Nz;
		UInt16_t Height;
		UInt16_t Width;
		UInt8_t CheckSum;
	} TargetDataCmd;
};


// RS422 OBC Response Union-Structure
union _ObcResp_
{
	// Obc response buffer
	UInt8_t ObcRespBuff[40];

	// Health response structure
	struct _HealthResp_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t SwVersion[18];
		UInt16_t SWCheckSum;
		struct _IPStat_ IpStatus;
		UInt8_t CheckSum;
	} HealthResp;


	// Target data response structure
	struct _TargetDataResp_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		Int16_t Ny;
		Int16_t Nz;
		UInt16_t Height;
		UInt16_t Width;
		UInt8_t Confidance;
		UInt8_t DetectStatus;
		UInt32_t FrameTime;
		UInt32_t AIStartTime;
		UInt32_t AIEndTime;
		UInt32_t CurrTime;
		struct _IPStat_ IpStatus;
		UInt8_t CheckSum;
	} TargetDataResp;

	// Target data response structure
	struct _AckNackResp_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t Ack;
		UInt8_t CheckSum;
	} AckNackResp;
};


#pragma pack()



string SavePath = "/home/bhavesh/Eclipse/";


bool ObcPortStatus = true;
bool SaveDataFlag = false;

bool ObcRecvThreadFlag = true;




















//
//// ---------- Flags Variables ----------
//extern bool NUCStatus;
//extern bool IPAddrStatus;
//extern bool SeekerStatus;
//extern bool AIStatusFlag;
//
//extern bool IPHealthFlag;
//extern bool TargetDataFlag;
//extern bool DetectObjectFlag;
//
//extern bool SaveDataFlag;
//extern bool ReadVideoFlag;
//extern bool VideoSaveThreadFlag;
//extern bool ReadVideoThreadFlag;
//extern bool ProcessVideoThreadFlag;
//extern bool ObcRS422RecvThreadFlag;
//
//extern bool OBCSerialPortStatus;
//
//
//// ---------- Object Detection variables ----------
//extern steady_clock :: time_point DataTime;
//extern struct _TargetData_ TargetData;
//extern Int16_t bBox_Loc[2];
//extern UInt16_t bBox_Dim[2];
//extern Size VideoDim;
//
//
//// ---------- IP Address from OBC ----------
//extern Int8_t IP_IPAddr[16];
//extern Int8_t NetMask_Addr[16];
//extern Int8_t GateWay_Addr[16];
//
//
//// ---------- Other Variables ----------
//extern string SavePath;
//extern UInt8_t MissileID;
//extern string SW_Health;
//extern UInt16_t SW_CheckSum;
//extern SeekerRS422 *SeekerRS422Obj;
//


// ---------- Other Declaration ----------
class ObcRS422
{
private:
	// Variables
    Int32_t SerialPort, logFile, dataFile;
    struct termios tty;

	union _ObcCmd_ ObcCmd;
	union _ObcResp_ ObcResp;
	union _ObcResp_ ObcStat;

//	struct itimerspec its;
//	struct sigevent sev;
//	timer_t timerid;
//
//	bool TimThreadFlag;


public:
    // Constructor
    ObcRS422(void);

    // Destructor
    ~ObcRS422(void);

    // Checksum Calculation
    UInt8_t calcCheckSum(UInt8_t *data, UInt16_t len);

    // Send Ack Nack
    void sendAckNack(UInt8_t CmdID, UInt8_t Type);

    // Print Data
    void printData(union Message *);

    // Receive Message
    void recvMsg(void);

    // Send Message
    void sendMsg(union _ObcResp_ ObcResp);

    // ObcRS422 Receive
    void ObcRS422Recv(void);

    // Target Data Send
    void SendTargetData(void);

    // Timer
    void Timer(void);

    // Timer Thread
    static void *TimerThread(void *args);

    // ObcRS422 Receive Thread
    static void *ObcRS422RecvThread(void *);
};




ObcRS422 :: ObcRS422(void)
{
	SerialPort = open(ObcRS422Port, O_RDWR | O_NOCTTY | O_SYNC);

	if(SerialPort < 0)
	{
		perror("open");
		cout << "Error: OBC Serial Port is not available" << endl;
		ObcPortStatus = false;
		return;
	}


    if(tcgetattr(SerialPort, &tty) != 0)
    {
    	perror("tcgetattr");
    	cout << "Error: OBC Serial Port is not available" << endl;
        ObcPortStatus = false;
        return;
    }

    // 8N1, no flow control
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;
    tty.c_cflag |= (CLOCAL | CREAD);

    // Software flow control off
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);

    // Set timeout
    tty.c_cc[VMIN]  = 0;   // non-blocking
    tty.c_cc[VTIME] = 5;   // 500 ms read timeout

    // Set Speed
    cfmakeraw(&tty);					// raw mode
    cfsetspeed(&tty, ObcRS422BAUD);		// BaudRate

    // Flush Port, then applies attributes
    tcflush(SerialPort, TCIFLUSH);
    if(tcsetattr(SerialPort, TCSANOW, &tty) != 0)
    {
    	perror("tcsetattr");
    	cout << "Error: OBC Serial Port is not available" << endl;
        ObcPortStatus = false;
        return;
    }

    cout << "OBC_RS422 Port opened successfully..." << endl << flush;

	memset((void *)ObcCmd.ObcCmdBuff, 0, sizeof(ObcCmd.ObcCmdBuff));
	memset((void *)ObcResp.ObcRespBuff, 0, sizeof(ObcResp.ObcRespBuff));
	memset((void *)ObcStat.ObcRespBuff, 0, sizeof(ObcStat.ObcRespBuff));

	if(SaveDataFlag == false)
	{
		return;
	}

	logFile = open((SavePath + "ObcLog.txt").c_str(), O_WRONLY|O_CREAT|O_TRUNC, 0664);
	if(logFile < 0)
	{
		cerr << "Failed to open ObcRS422 Log file..." << endl;
		perror("open");
	}

	dataFile = open((SavePath + "ObcData.txt").c_str(), O_WRONLY|O_CREAT|O_TRUNC, 0664);
	if(logFile < 0)
	{
		cerr << "Failed to open ObcRS422 Log file..." << endl;
		perror("open");
	}
	else
	{
		write(dataFile, "%%IPHealth\tNy\tNz\tWidth\tHeight\tConfidance\tStatus\tFrameTime\tAIStartTime\tAIEndTime\tCurrTime\n", 88);
	}

	return;
}


ObcRS422 :: ~ObcRS422(void)
{
	if(ObcPortStatus == false)
	{
		return;
	}

	close(SerialPort);

	if(SaveDataFlag == false)
	{
		return;
	}

	close(logFile);
	close(dataFile);

	return;
}


UInt8_t ObcRS422 :: calcCheckSum(UInt8_t *data, UInt16_t len)
{
	UInt8_t CheckSum = 0;
	UInt16_t charCnt = 0;

	for(charCnt = 0; charCnt < len; charCnt++)
	{
		CheckSum ^= data[charCnt];
	}

	return CheckSum;
}

































void ObcRS422 :: ObcRS422Recv(void)
{
	UInt16_t Bytes = 0;
	struct timespec ts;
	UInt8_t Ind = 0, Len = 1;

	ts.tv_sec = 0;         // seconds
	ts.tv_nsec = 50;       // 50 nanoseconds

	while(ObcRecvThreadFlag == true)
	{
		Bytes = read(SerialPort, ObcCmd.ObcCmdBuff+1, 1);

		if(Bytes > 0)
		{
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
			continue;
		}

		if(ObcCmd.ObcCmdBuff[1] == OBCCard_ID)
		{
			ObcCmd.ObcCmdBuff[0] = OBCCard_ID;
		}
		else if(ObcCmd.ObcCmdBuff[0] == OBCCard_ID && ObcCmd.ObcCmdBuff[1] == IPCard_ID)
		{

		}
		else
		{

		}


		read(SerialPort, ObcCmd.ObcCmdBuff+2, 2);
		read(SerialPort, ObcCmd.ObcCmdBuff+4, ObcCmd.ObcCmdBuff[3]+1);











		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
		// sched_yield();
		continue;














		if(Bytes < 0)
		{
			if(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
			{
				clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
		        sched_yield();
		        continue;
			}
			else
			{

			}
		}
		else if(Bytes == 0)
		{
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
			sched_yield();
			continue;
		}
		else
		{
			if(ObcCmd.ObcCmdBuff[0] != OBCCard_ID)
			{
				clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
				sched_yield();
				continue;
			}



				if(ObcCmd.ObcCmdBuff[1] == OBCCard_ID)
						{
							ObcCmd.ObcCmdBuff[0] = ObcCmd.ObcCmdBuff[1];

							read(SerialPort, ObcCmd.ObcCmdBuff+1, 1);
							if(ObcCmd.ObcCmdBuff[1] == IPCard_ID)
							{
								break;
							}
						}
		}
	}

	return;
}



// ---------- ObcRS422 Receive Thread ----------
void * ObcRS422 :: ObcRS422RecvThread(void *args)
{
	ObcRS422 *Instance = static_cast<ObcRS422 *>(args);
	Instance->ObcRS422Recv();
	pthread_exit(NULL);
	return nullptr;
}











int main()
{

}









