// ============================================================================
// Name		: SysConfig.cpp
// Date		: Oct 27, 2025
// ============================================================================


// ---------- Header Inclusion ----------
#include "SysConfig.h"


// ---------- Global Static Inclusion ----------
static UInt8_t Day = 0, Month = 0;
static UInt16_t Year = 0;


// ---------- Force stop function for CNTL+C ----------
void forceStop([[maybe_unused]]Int32_t Signal)
{
	// Clear all the flags
	ObcRecvThreadFlag = false;
	ObcDataThreadFlag = false;
	ProcessThreadFlag = false;
	AppTimerThreadFlag = false;
	VideoStreamThreadFlag = false;
	CamHandShakeThreadFlag = false;

	cout << "Terminating Forcefully by CNTL+C..." << endl << flush;

	return;
}


// ---------- Validate Integer ----------
bool validateInt(Int8_t *str)
{
	UInt8_t charCnt = 0U;

	do
	{
		if(isdigit(*str) == false)
		{
			if(! (charCnt == 0U && (*str == '-' || *str == '+')))
			{
				return false;
			}
		}

		charCnt++;

	} while(*(++str));

	return true;
}


// ---------- Validate IP Address ----------
bool validateIP(const Int8_t *Addr)
{
	// Local Variable
	Int8_t Result;
	struct sockaddr_in sa;

    Result = inet_pton(AF_INET, Addr, &(sa.sin_addr));
    return Result != 0;
}


// ---------- Validate Port Number ----------
Int32_t validatePORT(Int8_t *Port)
{
	Int32_t Result = -1;

	if(validateInt(Port) == false)
	{
		return -1;
	}

	// Convert & update the port number
	Result = atoi(Port);

	// Check port number is in valid range or not
	if(Result < 1024 || 49151 < Result)
	{
		return -2;
	}

	return Result;
}


// ---------- Check User Flags ----------
void checkFlags(Int32_t argc, Int8_t *argv[])
{
	Int32_t argcCnt = 0;

	// Check if flags are given or not
	if(argc == 1)
	{
		return;
	}

	// If flags are given
	while(argc > (++argcCnt))
	{
		// Start Detection without RS422 Command
		if(strcmp("-D", argv[argcCnt]) == 0)
		{
			DetectObjectFlag = true;
		}

		// Save All Data
		else if(strcmp("-S", argv[argcCnt]) == 0)
		{
			SaveDataFlag = true;
		}

		// Save Data in SD Card
		else if(strcmp("-SD", argv[argcCnt]) == 0)
		{
			SDCardSaveFlag = true;
		}

		// Display frame when got this flag
		else if(strcmp("-DF", argv[argcCnt]) == 0)
		{
			DisplayFrameFlag = true;
		}

		// Camera Not Available
		else if(strcmp("-H", argv[argcCnt]) == 0)
		{
			SeekerStatus = true;
			NUCStatus = true;
		}

		else if(strcmp("-BP", argv[argcCnt]) == 0)
		{
			BirdPlaneDataFlag = true;
		}

		else if(strcmp("-PT", argv[argcCnt]) == 0)
		{
			argcCnt++;
			if(argcCnt < argc)
			{
				ParentPath = argv[argcCnt];
				ParentPath = ParentPath + (ParentPath[ParentPath.size()-1] == '/' ? "" : "/");
			}
			else
			{
				cout << "Please provide path after like '-PT Path'" << endl << flush;
				exit(1);
			}
		}

		else if(strcmp("-M", argv[argcCnt]) == 0)
		{
			argcCnt++;
			if(argcCnt < argc)
			{
				// Check the given IP Address is valid or not
				if(validateInt(argv[argcCnt]) == false)
				{
					cout << "Please provide valid Missile ID" << endl << flush;
					exit(1);
				}

				MissileID = atoi(argv[argcCnt]);

				if(MissileID < 1 || 64 < MissileID)
				{
					cout << "Please provide valid Missile ID between 1 - 64" << endl << flush;
					exit(1);
				}

				DL_UDPPort = DL_UDPPort + (MissileID - 1);
				IPAddrStatus = true;
				ObcCmdFlag = true;
			}
			else
			{
				cout << "Please provide Missile ID after like '-M MisileID'" << endl << flush;
				exit(1);
			}
		}

		// Wrong Flags are provided
		else
		{
			cout << "You have provided wrong flags" << endl << flush;

			cout << "Start Detection				: -D" << endl << flush;
			cout << "Save All Data					: -S" << endl << flush;
			cout << "Seeker Handshake				: -H" << endl << flush;
			cout << "Save Data in SD Card			: -SD" << endl << flush;
			cout << "Track Birds & Plane			: -BP" << endl << flush;
			cout << "Display Frames					: -DF" << endl << flush;
			cout << "Missile ID						: -M MissileID" << endl << flush;
			// cout << "Script File Path			: -PT Path" << endl << flush;
			exit(1);
		}
	}

	return;
}


// ---------- CRC16 function ----------
UInt16_t crc16(UInt8_t *Data, UInt64_t Len)
{
	UInt16_t crc = 0xFFFF;
	UInt64_t i = 0;
	UInt8_t j = 0;

	for(i = 0; i < Len; i++)
	{
		crc ^= Data[i];
		for(j = 0; j < 8; j++)
		{
			if(crc & 0x01)
			{
				crc = (crc >> 1) ^ 0xA001;
			}
			else
			{
				crc >>= 1;
			}
		}
	}

	return crc;
}


// ---------- Calculate software checksum ----------
UInt16_t getSwCheckSum(string Path)
{
	ifstream file;
	string secName;
	Elf64_Ehdr ehdr;
	UInt16_t crc = 0, i = 0;

	// Open EXE file
	file.open(Path.c_str(), ios::binary);
	if(!file)
	{
		cout << "Failed to open EXE file..." << endl;
		return crc;
	}

	// Read EXE header
	file.read(reinterpret_cast<Int8_t *>(&ehdr), sizeof(ehdr));
	if(strncmp((Int8_t *)ehdr.e_ident, ELFMAG, SELFMAG) != 0)
	{
		cout << "Invalid EXE file..." << endl;
		return crc;
	}

	// Read section header
	file.seekg(ehdr.e_shoff, ios::beg);
	vector<Elf64_Shdr> shdrs(ehdr.e_shnum);
	file.read(reinterpret_cast<Int8_t *>(shdrs.data()), ehdr.e_shentsize * ehdr.e_shnum);

	// Read section header string table
	Elf64_Shdr shstr = shdrs[ehdr.e_shstrndx];
	vector<Int8_t> shstrtab(shstr.sh_size);
	file.seekg(shstr.sh_offset, ios::beg);
	file.read(shstrtab.data(), shstr.sh_size);

	// Find .text section
	for(i = 0; i < ehdr.e_shnum; i++)
	{
		secName = &shstrtab[shdrs[i].sh_name];
		if(secName == ".text")
		{
			vector<UInt8_t> buffer(shdrs[i].sh_size);
			file.seekg(shdrs[i].sh_offset, ios::beg);
			file.read(reinterpret_cast<Int8_t *>(buffer.data()), shdrs[i].sh_size);

			return crc16(buffer.data(), buffer.size());
		}
	}

	cout << "Failed to calculate Checksum..." << endl;

	return crc;
}


// ---------- Create Path ----------
string createPath(string Path, UInt8_t Mode)
{
	FILE *pipe;
	Int8_t date[10];
	Int32_t testCnt = -1;
	struct _TimeDate_ CurrTime;

	time_t t = time(nullptr);
	tm *now = localtime(&t);

	CurrTime = AppTimerObj->GetCurrTime();

	if(Mode == 1U)
	{
		now->tm_mday = CurrTime.day;
		now->tm_mon = CurrTime.month - 1;
		now->tm_year = CurrTime.year - 1900;
	}

	Day = now->tm_mday;
	Month = now->tm_mon+1;
	Year = now->tm_year+1900;

	strftime(date, sizeof(date), "%d%b%y/", now);
	Path = Path + (Path[Path.size()-1] == '/' ? "" : "/") + "Res/" + date;
	system(("mkdir -p -m 775 " + Path).c_str());

	pipe = popen(("ls -d " + Path + "Test* 2>/dev/null | grep -oP 'Test\\K[0-9]+' | sort -nr | head -n1").c_str(), "r");
	if(pipe == nullptr)
	{
		cerr << "Error in opening pipe..." << endl;
		testCnt = 0;
	}
	else
	{
		fscanf(pipe, "%d", &testCnt);
		testCnt++;
	}

	Path = Path + "Test" + to_string(testCnt) + "/";
	system(("mkdir -p -m 775 " + Path).c_str());

	return Path;
}


// ---------- Get Path ----------
string getPath(UInt8_t typ)
{
	string Path = "";
	ssize_t len = 0;
	Int8_t path[PATH_MAX], *tmp;
	struct _TimeDate_ CurrTime;

	CurrTime = AppTimerObj->GetCurrTime();

	// Get Exe OR Load Path
	if(typ == 0U || typ == 1U)
	{
		len = readlink("/proc/self/exe", path, PATH_MAX - 1);
		if(len != -1)
		{
			path[len] = '\0';

			if(typ == 1)
			{
				tmp = strrchr(path, '/');
				*(tmp + 1) = '\0';
			}

			Path = path;
		}
		else
		{
			Path = "";
		}
	}

	// Get Save Path
	else if(typ == 2U)
	{
		if(ParentPath != "")
		{
			Path = ParentPath;
		}
		else
		{
			Path = SDCardSaveFlag == false ? createPath(LoadPath, 0) : createPath("/mnt/sdcard/IPData/Res/", 0);
		}
	}

	// Get New Save Path
	else if(typ == 3U)
	{
		if(SDCardSaveFlag == true)
		{
			return SavePath;
		}

		if(CurrTime.day == Day && CurrTime.month == Month && CurrTime.year == Year)
		{
			return SavePath;
		}

		ParentPath = SavePath;

		Path = createPath(LoadPath, 1);
		system(("sudo mv " + ParentPath + "* " + Path).c_str());
		system(("sudo rm -rf " + ParentPath).c_str());
	}

	else
	{

	}

	return Path;
}


// ---------- readFile ----------
string readFile(string path)
{
	Int32_t file = -1, dataCnt = 0;
	Int8_t *buff;
	string data;

	file = open(path.c_str(), O_RDONLY);
	if(file < 0)
	{
		cerr << "Error in opening file" << endl;
		perror("open");
		return "";
	}

	dataCnt = lseek(file, 0, SEEK_END);
	lseek(file, 0, SEEK_SET);

	buff = (Int8_t *)malloc(dataCnt+1);
	if(read(file, buff, dataCnt) < 0)
	{
		cerr << "Error in reading data" << endl;
		perror("read");
		free(buff);
		return "";
	}
	buff[dataCnt] = 0;

	data = (const Int8_t *)buff;
	free(buff);
	close(file);

	return data;
}


// ---------- load Config file Data ----------
void loadConfigData(void)
{
	string data, ipAddr;
	json parsedData;

	// Open file & read data
	data = readFile(LoadPath + "Config.json");

	if(data == "")
	{
		cout << "Failed to load config data..." << endl << flush;
		return;
	}

	// load config data
	try
	{
		parsedData = json::parse(data);

		ModelPath = parsedData["MODEL_FILE"];
		VideoSource = parsedData["VIDEO_SRC"];
		EthInterface = parsedData["ETH_INTERFACE"];
		DL_UDPPort = parsedData["DL_UDPPORT"];

		// Copy DL IP Address
		ipAddr = parsedData["DL_IPADDR"];
		if(validateIP(ipAddr.c_str()) == false)
		{
			cout << "Please enter valid DL_IPADDR in config file" << endl << flush;
			exit(1);
		}
		strcpy(DL_IPAddr, ipAddr.c_str());

		ipAddr = parsedData["IP_IPADDR"];
		if(validateIP(ipAddr.c_str()) == false)
		{
			cout << "Please enter valid IP_IPADDR in config file" << endl << flush;
			exit(1);
		}
		strcpy(IP_IPAddr, ipAddr.c_str());

		ipAddr = parsedData["GATEWAY_ADDR"];
		if(validateIP(ipAddr.c_str()) == false)
		{
			cout << "Please enter valid GATEWAY_ADDR in config file" << endl << flush;
			exit(1);
		}
		strcpy(GateWay_Addr, ipAddr.c_str());

		cout << "Config data loaded successfully..." << endl << flush;
	}
	catch(exception &e)
	{
		cerr << "Error in loading config data" << endl;
		cout << e.what() << endl << flush;
	}

	return;
}



















