// ============================================================================
// Name		: ObcRS422.cpp
// Date		: Oct 27, 2025
// ============================================================================


// ---------- Header Inclusion ----------
#include "ObcRS422.h"


// ---------- Constructor ----------
ObcRS422 :: ObcRS422(void)
{
	timerid = NULL;
	TimThreadFlag = false;

	SerialPort = open(ObcRS422Port, O_RDWR | O_NOCTTY | O_SYNC);

	if(SerialPort< 0)
	{
		cout << "Error: OBC Serial Port is not available" << endl;
		SerialPort = open((Int8_t *)"/dev/tty11", O_RDWR | O_NOCTTY | O_SYNC);
		OBCSerialPortStatus = false;
		return;
	}
	else
	{
		OBCSerialPortStatus = true;
	}

	if (tcgetattr(SerialPort, &tty) != 0)
	{
		perror("tcgetattr");
		exit(1);
	}

    tty.c_cflag &= ~PARENB;
	tty.c_cflag &= ~CSTOPB;
	tty.c_cflag &= ~CSIZE;
	tty.c_cflag |= CS8;
	tty.c_cflag &= ~CRTSCTS;
	tty.c_cflag |= CREAD | CLOCAL;

	tty.c_lflag &= ~ICANON;
	tty.c_lflag &= ~ECHO;
	tty.c_lflag &= ~ECHOE;
	tty.c_lflag &= ~ECHONL;
	tty.c_lflag &= ~ISIG;
	tty.c_iflag &= ~(IXON | IXOFF | IXANY);

	tty.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP|INLCR|IGNCR|ICRNL);

	tty.c_oflag &= ~OPOST;
	tty.c_oflag &= ~ONLCR;

	tty.c_cc[VTIME] = 100;			// x * 100ms read timeout after receive first char
	tty.c_cc[VMIN] = 5;				// read block for 5 char


	// Set Baud Rate
	cfsetospeed(&tty, ObcRS422BAUD);
	cfsetispeed(&tty, ObcRS422BAUD);


	// Flush Port, then applies attributes
	tcflush(SerialPort, TCIFLUSH);
	if (tcsetattr(SerialPort, TCSANOW, &tty) != 0)
	{
		perror("tcsetattr");
		exit(1);
	}

	cout << "OBC_RS422 Port opened successfully..." << endl << flush;

	if(SaveDataFlag == true)
	{
		logFile = open((SavePath + "ObcLog.txt").c_str(), O_WRONLY|O_CREAT|O_TRUNC, 0664);
		if(logFile < 0)
		{
			cerr << "Failed to open ObcRS422 Log file..." << endl;
			perror("open");
		}

		dataFile = open((SavePath + "ObcData.txt").c_str(), O_WRONLY|O_CREAT|O_TRUNC, 0664);
		if(logFile < 0)
		{
			cerr << "Failed to open ObcRS422 Log file..." << endl;
			perror("open");
		}
		else
		{
			write(dataFile, "%%IPHealth\tNy\tNz\tWidth\tHeight\tConfidance\tStatus\tFrameTime\tAIStartTime\tAIEndTime\tCurrTime\n", 88);
		}

	}

	memset((void *)ObcCmd.ObcCmdBuff, 0, sizeof(ObcCmd.ObcCmdBuff));
	memset((void *)ObcResp.ObcRespBuff, 0, sizeof(ObcResp.ObcRespBuff));
	memset((void *)ObcStat.ObcRespBuff, 0, sizeof(ObcStat.ObcRespBuff));

	return;
}


// ---------- Destructor ----------
ObcRS422 :: ~ObcRS422(void)
{
	if(OBCSerialPortStatus == true)
	{
		close(SerialPort);

		if(SaveDataFlag == true)
		{
			close(logFile);
		}
	}

	return;
}


// ---------- Checksum Calculation ----------
UInt8_t ObcRS422 :: calcCheckSum(UInt8_t *data, UInt16_t len)
{
	UInt8_t CheckSum = 0;
	UInt16_t charCnt = 0;

	for(charCnt = 0; charCnt < len; charCnt++)
	{
		CheckSum ^= data[charCnt];
	}

	return CheckSum;
}


// ---------- Send Ack Nack ----------
void ObcRS422 :: sendAckNack(UInt8_t CmdID, UInt8_t Type)
{
	// Send NACK
	ObcResp.ObcRespBuff[0] = IPCard_ID;
	ObcResp.ObcRespBuff[1] = OBCCard_ID;
	ObcResp.ObcRespBuff[2] = CmdID;

	ObcResp.ObcRespBuff[3] = 0x01;

	if(Type == 0)
	{
		ObcResp.AckNackResp.Ack = 0xB2;
	}
	else if(Type == 1)
	{
		ObcResp.AckNackResp.Ack = 0xE5;
	}
	else
	{

	}

	ObcResp.AckNackResp.CheckSum = calcCheckSum(ObcResp.ObcRespBuff, sizeof(ObcResp.ObcRespBuff)-1);

	sendMsg(ObcResp); // Sending Message
	return;
}


// ---------- Receive Message ----------
void ObcRS422 :: recvMsg(void)
{
	UInt16_t charCnt = 0;
    Int8_t printBuff[200];

    memset((void *)printBuff, 0, sizeof(printBuff));
	memset((void *)ObcCmd.ObcCmdBuff, 0, sizeof(ObcCmd.ObcCmdBuff));

	// Sync data according to header
	while(true)
	{
		read(SerialPort, ObcCmd.ObcCmdBuff+1, 1);
		if(ObcCmd.ObcCmdBuff[1] == OBCCard_ID)
		{
			ObcCmd.ObcCmdBuff[0] = ObcCmd.ObcCmdBuff[1];

			read(SerialPort, ObcCmd.ObcCmdBuff+1, 1);
			if(ObcCmd.ObcCmdBuff[1] == IPCard_ID)
			{
				break;
			}
		}
	}

	read(SerialPort, ObcCmd.ObcCmdBuff+2, 2);
	read(SerialPort, ObcCmd.ObcCmdBuff+4, ObcCmd.ObcCmdBuff[3]+1);


	sprintf(printBuff, "Receive : 0x%02X 0x%02X 0x%02X 0x%02X ", ObcCmd.ObcCmdBuff[0], ObcCmd.ObcCmdBuff[1], ObcCmd.ObcCmdBuff[2], ObcCmd.ObcCmdBuff[3]);

	for(charCnt = 0; charCnt < ObcCmd.ObcCmdBuff[3]; charCnt++)
	{
		sprintf((printBuff + strlen(printBuff)), "0x%02X ", ObcCmd.ObcCmdBuff[charCnt+4]);
	}

	sprintf((printBuff + strlen(printBuff)), "0x%02X  %s\n%c", ObcCmd.ObcCmdBuff[charCnt+4], getTimeStamp().c_str(), 0);

	if(SaveDataFlag == true)
	{
		write(logFile, printBuff, strlen(printBuff));
	}
	cout << printBuff << flush;

	return;
}


// ---------- Send Message ----------
void ObcRS422 :: sendMsg(union _ObcResp_ ObcResp)
{
	UInt16_t charCnt = 0;
	Int8_t printBuff[200];

	// Read structure and send it
	write(SerialPort, ObcResp.ObcRespBuff, ObcResp.ObcRespBuff[3]+5);

	memset((void *)printBuff, 0, sizeof(printBuff));
	sprintf(printBuff, "Transmit : 0x%02X 0x%02X 0x%02X 0x%02X ", ObcResp.ObcRespBuff[0], ObcResp.ObcRespBuff[1], ObcResp.ObcRespBuff[2], ObcResp.ObcRespBuff[3]);

	for(charCnt = 0; charCnt < ObcResp.ObcRespBuff[3]; charCnt++)
	{
		sprintf((printBuff + strlen(printBuff)), "0x%02X ", ObcResp.ObcRespBuff[charCnt+4]);
	}

	sprintf((printBuff + strlen(printBuff)), "0x%02X  %s\n%c", ObcResp.ObcRespBuff[charCnt+4], getTimeStamp().c_str(), 0);

	if(SaveDataFlag == true)
	{
		write(logFile, printBuff, strlen(printBuff));
	}
	cout << printBuff << flush;
	memset((void *)ObcResp.ObcRespBuff, 0, sizeof(ObcResp.ObcRespBuff));

	return;
}


// ---------- ObcRS422 Receive ----------
void ObcRS422 :: ObcRS422Recv(void)
{
	UInt8_t CheckSum = 0;
	UInt8_t HH, MM, SS, Day, Month;
	UInt16_t mmm, Year;

	// Start loop from RS422
	while(ObcRS422RecvThreadFlag == true)
	{
		// Wait for Receiving command
		recvMsg();

		CheckSum = calcCheckSum(ObcCmd.ObcCmdBuff, ObcCmd.ObcCmdBuff[3]+4);
		if(CheckSum != ObcCmd.ObcCmdBuff[ObcCmd.ObcCmdBuff[3]+4])
		{
			sendAckNack(ObcCmd.ObcCmdBuff[2], 0);
			continue;
		}

		if(ObcCmd.ObcCmdBuff[0] != OBCCard_ID || ObcCmd.ObcCmdBuff[1] != IPCard_ID)
		{
			sendAckNack(ObcCmd.ObcCmdBuff[2], 0);
			continue;
		}

		ObcResp.ObcRespBuff[0] = IPCard_ID;
		ObcResp.ObcRespBuff[1] = OBCCard_ID;
		ObcResp.ObcRespBuff[2] = ObcCmd.ObcCmdBuff[2];

		switch(ObcCmd.ObcCmdBuff[2])
		{
			// ConfigData
			case ConfigCmdID:
				if(!(1 <= ObcCmd.ConfigCmd.MissileID && ObcCmd.ConfigCmd.MissileID <= 64))
				{
					sendAckNack(ObcCmd.ObcCmdBuff[2], 0);
					break;
				}

				if(IPAddrStatus == false)
				{
					HH = ObcCmd.ConfigCmd.Time / 3600000;
					MM = (ObcCmd.ConfigCmd.Time % 3600000) / 100000;
					SS = (ObcCmd.ConfigCmd.Time % 60000) / 1000;
					mmm = ObcCmd.ConfigCmd.Time % 1000;
					Day = ObcCmd.ConfigCmd.Day;
					Month = ObcCmd.ConfigCmd.Month;
					Year = ObcCmd.ConfigCmd.Year;

					setSystemTime(Day, Month, Year, HH, MM, SS, mmm);

					MissileID = ObcCmd.ConfigCmd.MissileID;
					DL_UDPPort = DL_UDPPort + (MissileID - 1);
					modifyIPAddr(IP_IPAddr, (MissileID - 1));
					setIPAddr(IP_IPAddr, NetMask_Addr, GateWay_Addr);

					// Set Saving path for results
					if(VideoSaveThreadFlag == true || SaveDataFlag == true)
					{
						SavePath = getPath(3);
					}
				}

				sendAckNack(ObcCmd.ObcCmdBuff[2], 1);

				break;


			// Seeker NUC Command
			case NucCmdID:
				if(CameraSerialPortStatus == true)
				{
					SeekerRS422Obj->NUC_1PT_External();
				}
				sendAckNack(ObcCmd.ObcCmdBuff[2], 1);
				break;


			case HealthCmdID:
				memcpy((void *)ObcResp.HealthResp.SwVersion, (const void *)(SW_Health.c_str()), 18);
				ObcResp.HealthResp.SWCheckSum = SW_CheckSum;

				ObcResp.HealthResp.IpStatus.CameraStatus = SeekerStatus;
				ObcResp.HealthResp.IpStatus.NUCStatus = NUCStatus;
				ObcResp.HealthResp.IpStatus.IPAddrStatus = IPAddrStatus;
				ObcResp.HealthResp.IpStatus.AIStatusFlag = AIStatusFlag;

				ObcResp.ObcRespBuff[3] = sizeof(ObcResp.HealthResp)-5;

				ObcResp.ObcRespBuff[ObcResp.ObcRespBuff[3]+4] = calcCheckSum(ObcResp.ObcRespBuff, ObcResp.ObcRespBuff[3]+4);
				sendMsg(ObcResp); // Sending Message

				// Start Sending Target Data to Obc
				usleep(1000*1500);
				IPHealthFlag = true;
				break;


			case TgtDataCmdID:
				bBox_Loc[0] = ObcCmd.TargetDataCmd.Ny + (VideoDim.width/2);
				bBox_Loc[1] = ObcCmd.TargetDataCmd.Nz + (VideoDim.height/2);
				bBox_Dim[0] = ObcCmd.TargetDataCmd.Width;
				bBox_Dim[1] = ObcCmd.TargetDataCmd.Height;

				DetectObjectFlag = true;
				sendAckNack(ObcCmd.ObcCmdBuff[2], 1);
				continue;

				break;

			case ShutDownCmdID:
				sendAckNack(ObcCmd.ObcCmdBuff[2], 1);
				powerOff();
				continue;

				break;

			default:
				// Send NACK
				break;
		}

		usleep(1);
	}

	return;
}


// ---------- Target Data Send ----------
void ObcRS422 :: SendTargetData(void)
{
	Int8_t Buffer[200];

	memset((void *)ObcStat.ObcRespBuff, 0, sizeof(ObcStat.ObcRespBuff));

	ObcStat.ObcRespBuff[0] = IPCard_ID;
	ObcStat.ObcRespBuff[1] = OBCCard_ID;
	ObcStat.ObcRespBuff[2] = TgtDataCmdID;

	if(TargetDataFlag == false)
	{
		ObcStat.TargetDataResp.DetectStatus = 0;
		goto SEND;
	}

	ObcStat.TargetDataResp.Ny = TargetData.CenterPoint.x - (VideoDim.width/2);
	ObcStat.TargetDataResp.Nz = TargetData.CenterPoint.y - (VideoDim.height/2);
	if(TargetData.DetectionStatus == 0)
	{
		ObcStat.TargetDataResp.Ny = 0;
		ObcStat.TargetDataResp.Nz = 0;
	}

	ObcStat.TargetDataResp.Width = TargetData.BoundingBox.width;
	ObcStat.TargetDataResp.Height = TargetData.BoundingBox.height;

	ObcStat.TargetDataResp.Confidance = TargetData.Confidance * 100;
	ObcStat.TargetDataResp.DetectStatus = TargetData.DetectionStatus;
	ObcStat.TargetDataResp.FrameTime = TargetData.FrameTime;
	ObcStat.TargetDataResp.AIStartTime = TargetData.AIStartTime;
	ObcStat.TargetDataResp.AIEndTime = TargetData.AIEndTime;

	SEND:

	ObcStat.TargetDataResp.IpStatus.CameraStatus = SeekerStatus;
	ObcStat.TargetDataResp.IpStatus.NUCStatus = NUCStatus;
	ObcStat.TargetDataResp.IpStatus.IPAddrStatus = IPAddrStatus;
	ObcStat.TargetDataResp.IpStatus.AIStatusFlag = AIStatusFlag;
	ObcStat.TargetDataResp.CurrTime = getCurrTime();

	ObcStat.TargetDataResp.Length = sizeof(ObcStat.TargetDataResp)-5;
	ObcStat.ObcRespBuff[ObcStat.ObcRespBuff[3]+4] = calcCheckSum(ObcStat.ObcRespBuff, ObcStat.ObcRespBuff[3]+4);

	TargetDataFlag = false;
	DataTime = steady_clock::now();
	sendMsg(ObcStat);
	cout << endl;

	if(SaveDataFlag == true)
	{
		memset((void *)Buffer, 0, 200);
		sprintf(Buffer, "%d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %u\t\t  %u\t\t  %u\t\t  %u\n", ObcStat.ObcRespBuff[30], ObcStat.TargetDataResp.Ny, ObcStat.TargetDataResp.Nz, ObcStat.TargetDataResp.Width, ObcStat.TargetDataResp.Height, ObcStat.TargetDataResp.Confidance, ObcStat.TargetDataResp.DetectStatus, ObcStat.TargetDataResp.FrameTime, ObcStat.TargetDataResp.AIStartTime, ObcStat.TargetDataResp.AIEndTime, ObcStat.TargetDataResp.CurrTime);
		write(dataFile, Buffer, strlen(Buffer));
	}

	return;
}


// ---------- Timer ----------
void ObcRS422 :: Timer(void)
{
	while(TimerThreadFlag == true)
	{
		if(IPHealthFlag == false)
		{
			continue;
		}

		if(SeekerStatus == true && ReadVideoFlag == true)
		{
			if(duration_cast<milliseconds>(steady_clock::now() - DataTime).count() >= 50)
			{
				SendTargetData();
			}
		}
		else
		{
			if(duration_cast<milliseconds>(steady_clock::now() - DataTime).count() >= 40)
			{
				SendTargetData();
			}
		}
	}

	return;
}


// ---------- Timer Thread ----------
void * ObcRS422 :: TimerThread(void *args)
{
	ObcRS422 *Instance = static_cast<ObcRS422 *>(args);
	Instance->Timer();
	pthread_exit(NULL);
}


// ---------- ObcRS422 Receive Thread ----------
void * ObcRS422 :: ObcRS422RecvThread(void *args)
{
	ObcRS422 *Instance = static_cast<ObcRS422 *>(args);
	Instance->ObcRS422Recv();
	pthread_exit(NULL);
}




