// ============================================================================
// Name		: CamRS422.cpp
// Date		: Oct 27, 2025
// ============================================================================


// ---------- Header Inclusion ----------
#include "CamRS422.h"


// ---------- Camera Commands ----------
Int8_t Cam_HandShake[1] = {(Int8_t)0xB6};
Int8_t Cam_ManNUC[7] = {(Int8_t)0xA5, (Int8_t)0x57, (Int8_t)0x37, (Int8_t)0x01, (Int8_t)0xC2, (Int8_t)0xA7, (Int8_t)0x2F};
Int8_t Cam_ExtNUC[7] = {(Int8_t)0xA5, (Int8_t)0x57, (Int8_t)0x37, (Int8_t)0x01, (Int8_t)0xE2, (Int8_t)0x83, (Int8_t)0x4D};

// ---------- Camera Response ----------
Int8_t Cam_HandShake_Resp_ANA[3] = {(Int8_t)0xB6, (Int8_t)0xA5, (Int8_t)0xC9};
Int8_t Cam_HandShake_Resp_IN[3] = {(Int8_t)0xB6, (Int8_t)0xA5, (Int8_t)0xCC};
Int8_t Cam_NUC_Resp[7] = {(Int8_t)0xA5, (Int8_t)0x00, (Int8_t)0x37, (Int8_t)0x00, (Int8_t)0xCA, (Int8_t)0x31, (Int8_t)0xAA};


// ---------- Constructor ----------
CamRS422 :: CamRS422(void)
{
	Bytes = 0;

	SerialPort = open(CamPort, O_RDWR | O_NOCTTY | O_SYNC);

	if(SerialPort < 0)
	{
		cout << "Error: Camera Serial Port is not available" << endl;
		SerialPort = open((Int8_t *)"/dev/tty10", O_RDWR | O_NOCTTY | O_SYNC);
		CameraSerialPortStatus = false;
		return;
	}
	else
	{
		CameraSerialPortStatus = true;
	}

	if(tcgetattr(SerialPort, &tty) != 0)
	{
		perror("tcgetattr");
		exit(1);
	}


	tty.c_cflag &= ~PARENB;
	tty.c_cflag &= ~CSTOPB;
	tty.c_cflag &= ~CSIZE;
	tty.c_cflag |= CS8;
	tty.c_cflag &= ~CRTSCTS;
	tty.c_cflag |= CREAD | CLOCAL;

	tty.c_lflag &= ~ICANON;
	tty.c_lflag &= ~ECHO;
	tty.c_lflag &= ~ECHOE;
	tty.c_lflag &= ~ECHONL;
	tty.c_lflag &= ~ISIG;
	tty.c_iflag &= ~(IXON | IXOFF | IXANY);

	tty.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP|INLCR|IGNCR|ICRNL);

	tty.c_oflag &= ~OPOST;
	tty.c_oflag &= ~ONLCR;

	tty.c_cc[VTIME] = 100;			// x * 100ms read timeout after receive first char
	tty.c_cc[VMIN] = 1;				// read block for 1 char


	// Set Baud Rate
	cfsetospeed(&tty, CamBAUD);
	cfsetispeed(&tty, CamBAUD);


	// Flush SerialPort, then applies attributes
	tcflush(SerialPort, TCIFLUSH);
	if (tcsetattr(SerialPort, TCSANOW, &tty) != 0)
	{
		perror("tcsetattr");
		exit(1);
	}

	cout << "CAM_RS422 opened successfully..." << endl << flush;
	memset((void *)rxBuff, 0, sizeof(rxBuff));

	return;
}


// ---------- Destructor ----------
CamRS422 :: ~CamRS422(void)
{
	close(SerialPort);
	return;
}


// ---------- Handshake ----------
bool SeekerRS422 :: HandShake(void)
{
	memset((void *)rxBuff, 0, sizeof(rxBuff));
	write(SerialPort, CAM_CMD1, sizeof(CAM_CMD1));

	while(true)
	{
		Bytes = read(SerialPort, rxBuff, 1);
		if(rxBuff[0] == 0xB6)
		{
			Bytes += read(SerialPort, rxBuff+1, 2);
			break;
		}
	}

	if(Bytes <= 0)
	{
		cout << "Camera Handshaking failed..." << endl << flush;
		return false;
	}

	else
	{
		printf("CAM HandShake Recv - %02X %02X %02X\n", rxBuff[0], rxBuff[1], rxBuff[2]);

		if(cmpStr(rxBuff, CAM_CMD1_RESP_ANA, 2) == true)
		{
			SeekerStatus = true;
			cout << "Camera handshaking successful..." << endl << flush;

			if(cmpStr(rxBuff, CAM_CMD1_RESP_ANA, 3) == true)
			{
				cout << "No need of NUC for Vendor Camera...." << endl;
				NUCStatus = true;
			}

			return true;
		}
		else
		{
			cout << "Camera Handshaking failed..." << endl << flush;
		}
	}

	return false;
}


// ---------- NUC_1PT Manual ----------
bool SeekerRS422 :: NUC_1PT_Manual(void)
{
	memset((void *)rxBuff, 0, sizeof(rxBuff));
	write(SerialPort, CAM_NUC1, sizeof(CAM_NUC1));

	while(true)
	{
		Bytes = read(SerialPort, rxBuff, 1);
		if(rxBuff[0] == 0xA5)
		{
			Bytes += read(SerialPort, rxBuff+1, 6);
			break;
		}
	}

	if(Bytes <= 0)
	{
		cout << "Error in NUC_1PT Manual..." << endl << flush;
		return false;
	}

	else
	{
		printf("CAM NUC Recv - %02X %02X %02X %02X %02X %02X %02X\n", rxBuff[0], rxBuff[1], rxBuff[2], rxBuff[3], rxBuff[4], rxBuff[5], rxBuff[6]);

		if(Bytes == 0x07 && rxBuff[0] == 0xA5 && rxBuff[6] == 0xAA)
		{
			cout << "NUC_1PT Manual is successful..." << endl << flush;
			return true;
		}
		else
		{
			cout << "Error in NUC_1PT Manual..." << endl << flush;
			return false;
		}
	}

	return false;
}


// ---------- NUC_1PT External----------
bool SeekerRS422 :: NUC_1PT_External(void)
{
	memset((void *)rxBuff, 0, sizeof(rxBuff));
	write(SerialPort, CAM_NUC2, sizeof(CAM_NUC2));

	while(true)
	{
		Bytes = read(SerialPort, rxBuff, 1);
		if(rxBuff[0] == 0xA5)
		{
			Bytes += read(SerialPort, rxBuff+1, 6);
			break;
		}
	}

	if(Bytes <= 0)
	{
		cout << "Error in NUC_1PT External..." << endl << flush;
		return false;
	}

	else
	{
		printf("CAM NUC Recv - %02X %02X %02X %02X %02X %02X %02X\n", rxBuff[0], rxBuff[1], rxBuff[2], rxBuff[3], rxBuff[4], rxBuff[5], rxBuff[6]);

		if(Bytes == 0x07 && rxBuff[0] == 0xA5 && rxBuff[6] == 0xAA)
		{
			cout << "NUC_1PT External is successful..." << endl << flush;
			return true;
		}
		else
		{
			cout << "Error in NUC_1PT External..." << endl << flush;
			return false;
		}
	}

	return false;
}


// ---------- HandShake Thread function ----------
void * SeekerRS422 :: HandShakeThread(void *args)
{
	SeekerRS422 *Instance = static_cast<SeekerRS422 *>(args);

	while(SeekerHandShakeThreadFlag == true)
	{
		if(SeekerStatus == false)
		{
			if(Instance->HandShake() == true)
			{
				SeekerStatus = true;
			}

			usleep(100 * 1000);
		}

		if(SeekerStatus == true && NUCStatus == false)
		{
			Instance->NUC_1PT_External();
			usleep(400 * 1000);
			Instance->NUC_1PT_External();

			NUCStatus = true;
			SeekerHandShakeThreadFlag = false;
		}
	}

	pthread_exit(NULL);
}




