// ============================================================================
// Name		: ObjDetection.cpp
// Date		: Oct 27, 2025
// ============================================================================


// ---------- Header Inclusion ----------
#include "ObjDetection.h"


// Logger for TensorRT messages
class Logger : public ILogger
{
    void log(Severity severity, const char* msg) noexcept override
    {
        if (severity <= Severity::kWARNING)
        {
            cout << "[TensorRT] : " << msg << endl;
        }
    }
};

Logger logger;


__global__ void ConvToFP16_NormCHW(const float *ch0, const float *ch1, const float *ch2, __half *output, int32_t width, int32_t height)
{
	int32_t x, y, idx, imgArea;

    x = blockIdx.x * blockDim.x + threadIdx.x;
    y = blockIdx.y * blockDim.y + threadIdx.y;

    if(x >= width || y >= height)
    {
        return;
    }

    idx = y * width + x;
    imgArea = width * height;
    output[0 * imgArea + idx] = __float2half(ch0[idx] / 255.0f);
    output[1 * imgArea + idx] = __float2half(ch1[idx] / 255.0f);
    output[2 * imgArea + idx] = __float2half(ch2[idx] / 255.0f);
}


__global__ void fp16_to_fp32(const __half *input, float *output, int32_t N)
{
	int32_t idx = blockIdx.x * blockDim.x + threadIdx.x;
    if(idx < N)
    {
    	output[idx] = __half2float(input[idx]);
    }
}


// Constructor
ObjDetection :: ObjDetection(void)
{
	Yolov5_Dim.height = 640;
	Yolov5_Dim.width = 640;

	Detections = 25200;
	DetectionSize = 9;
	ClassCnt = 4;

	ConfThreshold = 0.6;
	IOUThreshold = 0.6;


	if(LoadEngineFile() == true)
	{
		AIStatusFlag = true;
		cout << "Engine Loaded Successfully" << endl;
	}
	else
	{
		AIStatusFlag = false;
		cout << "Failed to load Engine file" << endl;
	}

	return;
}


// Destructor
ObjDetection :: ~ObjDetection(void)
{
	try
	{
		for(void *ptr : Bindings)
		{
			if(ptr)
			{
				cudaFree(ptr);
			}
		}

		cudaStreamDestroy(rawStream);
	}
	catch(Exception &e)
	{

	}

	return;
}


size_t ObjDetection :: getMemorySize(Dims dims, size_t ElementSize)
{
	size_t size = ElementSize;

	for(Int32_t i = 0; i < dims.nbDims; i++)
	{
		size *= dims.d[i];
	}

	return size;
}


bool ObjDetection :: LoadEngineFile(void)
{
	try
	{
		setenv("CUDA_MODULE_LOADING", "LAZY", 1);
		setenv("CUDA_MODULE_LOADING", "EAGER", 1);

		ifstream EngineFile(ModelPath, ios::binary);
		if (!EngineFile) {
			cerr << "Failed to read engine file." << endl;
			return false;
		}

		EngineFile.seekg(0, ios::end);

		auto fsize = EngineFile.tellg();
		EngineFile.seekg(0, ios::beg);

		vector<char> engine_data(fsize);
		EngineFile.read(engine_data.data(), fsize);

		runtime.reset(createInferRuntime(logger));
		engine.reset(runtime->deserializeCudaEngine(engine_data.data(), fsize));
		context.reset(engine->createExecutionContext());

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

		Int32_t nbBindings = engine->getNbBindings();
		Bindings.resize(nbBindings, nullptr);
		BindingSizes.resize(nbBindings, 0);

		for(Int32_t i = 0; i < nbBindings; i++)
		{
			Dims dims = engine->getBindingDimensions(i);
			nvinfer1::DataType dtype = engine->getBindingDataType(i);
			size_t elementSize = (dtype == nvinfer1::DataType::kFLOAT) ? sizeof(float) : (dtype == nvinfer1::DataType::kHALF) ? sizeof(__half) : sizeof(float);
			BindingSizes[i] = getMemorySize(dims, elementSize);
			cudaMalloc(&Bindings[i], BindingSizes[i]);
		}

#pragma GCC diagnostic pop

		rawStream = cv::cuda::StreamAccessor::getStream(cvStream);
		return true;
	}
	catch(Exception &e)
	{
		return false;
	}

	return false;
}


// PreProcess
void ObjDetection :: preProcess(Mat VideoFrame, __half *InputBuff)
{
	dim3 block(32, 32);
	cuda::GpuMat Frame, GpuCHW[3];
	dim3 grid((Yolov5_Dim.width + block.x - 1) / block.x, (Yolov5_Dim.height + block.y - 1) / block.y);

	Frame.upload(VideoFrame, cvStream);

	// Created padded output(resize by padding to 640x480 are within 640x640)
	cuda::GpuMat GpuFrame(Yolov5_Dim.width, Yolov5_Dim.height, Frame.type(), Scalar::all(0));
	Frame.copyTo(GpuFrame(Rect(0, 0, VideoDim.width, VideoDim.height)), cvStream);

	// Convert the float32 & normalize on GPU
	GpuFrame.convertTo(GpuFrame, CV_32FC3, cvStream);
	cv::cuda::split(GpuFrame, GpuCHW, cvStream);

	// Launch custom FP16 kernel conversion & normalization kernel
	ConvToFP16_NormCHW <<<grid, block, 0, rawStream>>> (GpuCHW[0].ptr<float>(), GpuCHW[1].ptr<float>(), GpuCHW[2].ptr<float>(), static_cast<__half *>(InputBuff), Yolov5_Dim.width, Yolov5_Dim.height);

	return;
}


void ObjDetection :: postProcess(UInt16_t VideoWidth, UInt16_t VideoHeight)
{
	int32_t Total = DetectionSize * Detections;

	vector<Rect> Boxes;
	vector<Int32_t> Indices;
	vector<UInt8_t> ClassIds;
	vector<float> Confidances;

	float Confidence;
	float ClassScore[4];
	float ObjConf, ClassConf;
	UInt8_t ClassID = 0;

	float *FP32_OutBuff = nullptr;
	dim3 block(1024), grid((Total + 255) / 256);

	vector<float> Output(Total);

	Int16_t CentreX, CentreY, Width, Height;
	Int16_t X1, Y1, X2, Y2;

	struct _TargetData_ DetectData;

	Boxes.clear();
	Indices.clear();
	ClassIds.clear();
	Confidances.clear();
	TargetDataArr.clear();

	// Allocate device memory for FP32
	cudaMalloc(&FP32_OutBuff, Total * sizeof(float));

	// Launch fp16->fp32 conversion
	fp16_to_fp32<<<grid, block, 0, rawStream>>>(static_cast<const __half *>(Bindings[1]), FP32_OutBuff, Total);

	cudaMemcpyAsync(Output.data(), FP32_OutBuff, Output.size() * sizeof(float), cudaMemcpyDeviceToHost);
	cudaFree(FP32_OutBuff);

//	cudaStreamSynchronize(rawStream);
	cvStream.waitForCompletion();


	for(UInt32_t i = 0; i < Detections; i++)
	{
		ObjConf = Output[(i*DetectionSize) + ClassCnt];

		// Skip if Object Confidence is less than Threshold
		if(ObjConf < ConfThreshold || ObjConf > 1.0f || isnan(ObjConf))
		{
			continue;
		}

		for(UInt32_t j = 0; j < ClassCnt; j++)
		{
			ClassScore[j] = Output[(i*DetectionSize) + 5 + j];
		}

		ClassID = max_element(ClassScore, ClassScore + ClassCnt) - ClassScore;
		ClassConf = ClassScore[ClassID];
		Confidence = ObjConf * ClassConf;

		// Calculate Bounding Box Co-Ordinate & Size
		CentreX = Output[i * DetectionSize + 0];
		CentreY = Output[i * DetectionSize + 1];
		Width = Output[i * DetectionSize +  2];
		Height = Output[i * DetectionSize +  3];

		// Skip if Confidence is less than Threshold
		if(CentreX < 0 || CentreX > Yolov5_Dim.width || CentreY < 0 || CentreY > Yolov5_Dim.height || Width <= 0 || Height <= 0 || Width > Yolov5_Dim.width || Height > Yolov5_Dim.height || isnan(CentreX) || isnan(CentreY) || isnan(Width) || isnan(Height))
		{
			continue;
		}

		X1 = FindMax(0, (CentreX - (Width / 2)));
		Y1 = FindMax(0, (CentreY - (Height / 2)));

		X2 = FindMin(VideoWidth - 1, (CentreX + (Width / 2)));
		Y2 = FindMin(VideoHeight - 1, (CentreY + (Height / 2)));

		if(X2 >= X1 && Y2 >= Y1)
		{
			Boxes.emplace_back(Rect(X1, Y1, X2-X1, Y2-Y1));
			Confidances.emplace_back(Confidence);
			ClassIds.emplace_back(ClassID);
		}
	}


	dnn::NMSBoxes(Boxes, Confidances, ConfThreshold, IOUThreshold, Indices);

	for(UInt32_t idx : Indices)
	{
		DetectData.ClassID = ClassIds[idx];
		DetectData.Confidance = Confidances[idx];
		DetectData.BoundingBox = Boxes[idx];
		DetectData.CenterPoint = Point(Boxes[idx].x + Boxes[idx].width/2, Boxes[idx].y + Boxes[idx].height/2);

		TargetDataArr.push_back(DetectData);
	}

	return;
}


void ObjDetection :: drawBoxes(Mat &VideoFrame)
{
	string Label = "";
	double Dist, MinDist = numeric_limits<double> :: max();
	Point FrameCentre(VideoFrame.cols / 2, VideoFrame.rows / 2);

	memset((void *)&TargetData, 0, sizeof(TargetData));

	for(auto &Target : TargetDataArr)
	{
		// Bird & Plane
		if(Target.ClassID == 0 || Target.ClassID == 3)
		{
			rectangle(VideoFrame, Target.BoundingBox, Scalar(255, 255, 255), 1);
			Label = ClassName[Target.ClassID] + " " + to_string((UInt32_t)(Target.Confidance * 100)) + "%";
			putText(VideoFrame, Label, Target.BoundingBox.tl(), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(255, 255, 255), 1);

			// Find out Nearest Target form VideoFrame CentrePoint
			if(BirdPlaneDataFlag == true)
			{
				Dist = norm(Target.CenterPoint - FrameCentre);
				if(Dist < MinDist)
				{
					MinDist = Dist;

					TargetData.ClassID = Target.ClassID;
					TargetData.Confidance = Target.Confidance;
					TargetData.CenterPoint = Target.CenterPoint;
					TargetData.BoundingBox = Target.BoundingBox;

					TargetData.ValidData = 1;
				}
			}
		}

		// Fixed Wing Drone & Hexa Drone
		else if(Target.ClassID == 1 || Target.ClassID == 2)
		{
			rectangle(VideoFrame, Target.BoundingBox, Scalar(255, 255, 255), 1);
			Label = ClassName[Target.ClassID] + " " + to_string((UInt32_t)(Target.Confidance * 100)) + "% (" + to_string(Target.CenterPoint.x - VideoFrame.cols/2) + ", " + to_string(Target.CenterPoint.y - VideoFrame.rows/2) + ")";
			putText(VideoFrame, Label, Target.BoundingBox.tl(), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(255, 255, 255), 1);
			line(VideoFrame, FrameCentre, Target.CenterPoint, Scalar(255, 255, 255), 1);

			// Find out Nearest Target form VideoFrame CentrePoint
			Dist = norm(Target.CenterPoint - FrameCentre);
			if(Dist < MinDist)
			{
				MinDist = Dist;
				TargetData.ClassID = Target.ClassID;
				TargetData.Confidance = Target.Confidance;
				TargetData.CenterPoint = Target.CenterPoint;
				TargetData.BoundingBox = Target.BoundingBox;

				TargetData.ValidData = 1;
			}
		}

		else
		{

		}

		cout << "ID-" << (UInt32_t)Target.ClassID << " Conf-" << Target.Confidance <<  " Cx-" << Target.CenterPoint.x << " Cy-" << Target.CenterPoint.y << " W-" << Target.BoundingBox.width << " H-" << Target.BoundingBox.height << endl << flush;
	}

	return;
}

// Detect Object Function
void ObjDetection :: RunEnqueueV2(Mat &VideoFrame)
{
	// PreProcess
	preProcess(VideoFrame, static_cast<__half *>(Bindings[0]));


#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

	context->enqueueV2(Bindings.data(), rawStream, nullptr);
	cudaStreamSynchronize(rawStream);
	cvStream.waitForCompletion();

#pragma GCC diagnostic pop

	// PostProcess
	postProcess(VideoFrame.cols, VideoFrame.rows);
	drawBoxes(VideoFrame);

	return;
}




