// ============================================================================
// Name		: Seeker.cpp
// Date		: Oct 27, 2025
// ============================================================================


// ---------- Header Inclusion ----------
#include "Seeker.h"


// ---------- Constructor ----------
Seeker :: Seeker(void)
{
	// Create UDP/UDP Socket
	UDPSock = socket(AF_INET, SOCK_DGRAM, 0);
	if(UDPSock < 0)
	{
		cerr << "Error! in opening UDP socket" << endl;
		perror("Socket");
		raise(SIGINT);
	}

	len = sizeof(saddr);
	memset((void *)&saddr, 0, len);

	saddr.sin_family = AF_INET;
	saddr.sin_addr.s_addr = inet_addr(DL_IPAddr);
	saddr.sin_port = htons(DL_UDPPort);


	CAM.open(VideoSource);

	if(!CAM.isOpened())
	{
		cerr << "ERROR! Unable to open video source " << VideoSource << endl;
		SeekerStatus = false;
		raise(SIGINT);
	}

	if(SaveDataFlag == true)
	{
		// Open VideoWriter
		OutVid.open(SavePath + "IPVideo.avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, false);
		if(!OutVid.isOpened())
		{
			cerr << "Error in opening new video file" << endl;
			raise(SIGINT);
		}
	}

	return;
}


// ---------- Destructor ----------
Seeker :: ~Seeker(void)
{
	close(UDPSock);
	CAM.release();
	OutVid.release();

	return;
}


// ---------- Read Frames ----------
void Seeker :: ReadFrames(void)
{
	bool ret;
	Mat VideoFrame;
	string timestamp;
	Int32_t sleepTime;
	struct timespec ts;
	UInt32_t timCntStart, timCntEnd, totalTime;

	ts.tv_sec = 0;

	while(ProcessThreadFlag == true)
	{
		// Start measuring execution time
		timCntStart = AppTimerObj->GetCurrMillis();

		// Reading VideoFrame using OpenCV
		VideoFrame.release();
		ret = CAM.read(VideoFrame);
		if(ret == false)
		{
			cerr << "Error! Failed to read video" << endl;

			if(VideoSource == "/dev/video0")
			{
				CAM.release();
				CAM.open(VideoSource);

				if(!CAM.isOpened())
				{
					cerr << "ERROR! Unable to open video source " << VideoSource << endl;
					SeekerStatus = false;
					break;
				}
			}
			else
			{
				SeekerStatus = false;
				break;
			}
		}

		resize(VideoFrame, VideoFrame, VideoDim);				// Resize it if needed

		// Set and add timestamp in VideoFrame
		timestamp = AppTimerObj->GetTimeStamp();
		putText(VideoFrame, timestamp, Point(10, 20), FONT_HERSHEY_SIMPLEX, 0.4, Scalar(255, 255, 255), 1);

		if(CameraData.FrameFlag == true)
		{
			CameraData.FrameFlag = false;
			cout << "Dropping VideoFrames because inference is slow..." << endl << flush;
		}

		CameraData.VideoFrame.release();
		CameraData.VideoFrame = VideoFrame;
		CameraData.FrameTime = AppTimerObj->GetCurrMillis();
		CameraData.FrameFlag = true;


		if(ObcPortStatus == true)
		{
			 ObcRS422Obj->SendTargetData();
		}

		// Stop Measuring execution time
		timCntEnd =  AppTimerObj->GetCurrMillis();

		// Calculate the reading & sleep time in milliseconds
		totalTime = (timCntEnd < timCntStart) ? ((86400000U + timCntEnd) - timCntStart) : (timCntEnd - timCntStart);
		sleepTime = FrameDelay - totalTime;

		// cout << endl << "Frame Reading Time - " << totalTime << " ms" << endl << flush;

		// Give Delay in Video Reading
		if(VideoSource.find("/dev/video") != 0 &&  sleepTime > 0)
		{
			ts.tv_nsec = (sleepTime * 1000 * 1000) - 50;
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
		}
	}

	CAM.release();

	return;
}


// ---------- Video Stream ----------
void Seeker :: VideoStream(void)
{
	Mat VideoFrame;
	struct timespec ts;
	UInt16_t SaveFrameCnt = 0U;

	UInt32_t FrameCnt = 0U;
	UInt8_t PacketNo = 0U, PacketCnt = 0U;
	UInt32_t PacketStart = 0U, PacketEnd = 0U;
	UInt32_t FrameLength = 0U, QueueLen = 0U;
	const UInt32_t UDPSegSize = 60U * 1024U;

	vector<UInt8_t> DataPacket;
	vector<UInt8_t> FrameBuff;
	vector<Int32_t> FrameCompress = {IMWRITE_JPEG_QUALITY, 60};

	ts.tv_sec = 0;         // seconds
	ts.tv_nsec = 50;       // 50 nanoseconds

	while(VideoStreamThreadFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		if(ProcessedData.FrameFlag == false)
		{
			continue;
		}

		VideoFrame.release();
		VideoFrame = ProcessedData.VideoFrame;
		ProcessedData.VideoFrame = false;

		// Convert VideoFrame to grayscale
		cvtColor(VideoFrame, VideoFrame, COLOR_BGR2GRAY);


		// Video Stream
		PacketNo = 0;
		PacketCnt = 0;
		PacketEnd = 0;
		PacketStart = 0;
		FrameLength = 0;


		imencode(".jpeg", VideoFrame, FrameBuff, FrameCompress);					// Encode to JPEG
		FrameLength = FrameBuff.size();												// Calculate FrameBuff length
		PacketCnt = (FrameLength + (UDPSegSize - 1)) / UDPSegSize;					// Calculate Packet Count

		for(PacketNo = 0; PacketNo < PacketCnt; PacketNo++)
		{
			// Split The VideoFrame data
			PacketStart = PacketNo * UDPSegSize;
			PacketEnd = min(PacketStart + UDPSegSize, FrameLength);

			// Insert the split VideoFrame data Into DataPacket
			DataPacket.insert(DataPacket.begin(), (UInt8_t *)(FrameBuff.data()+PacketStart), (UInt8_t *)(FrameBuff.data()+PacketEnd));

			// Add header in the DataPacket
			DataPacket.insert(DataPacket.begin(), (UInt8_t)(PacketNo));							// Add DataPacket number
			DataPacket.insert(DataPacket.begin(), (UInt8_t)(PacketCnt));						// Add DataPacket count

			// Add VideoFrame number
			DataPacket.insert(DataPacket.begin(), (UInt8_t)((FrameCnt >> 24)&0xFF));			// Frame no 4th byte
			DataPacket.insert(DataPacket.begin(), (UInt8_t)((FrameCnt >> 16)&0xFF));			// Frame no 3rd byte
			DataPacket.insert(DataPacket.begin(), (UInt8_t)((FrameCnt >> 8)&0xFF));				// Frame no 2nd byte
			DataPacket.insert(DataPacket.begin(), (UInt8_t)((FrameCnt >> 0)&0xFF));				// Frame no 1st byte

			// Add Header
			DataPacket.insert(DataPacket.begin(), (UInt8_t)MissileID);							// Add missile id
			DataPacket.insert(DataPacket.begin(), DataLink_ID);									// Add Destination ID
			DataPacket.insert(DataPacket.begin(), IPCard_ID);									// Add Source ID

			cout << "Frame Sent ID-" << (UInt32_t)MissileID << " F-" << FrameCnt << " PC-" <<
				 (UInt32_t)PacketCnt << " PN-" << (UInt32_t)(PacketNo+1) << " FL-" << FrameLength
				 << " PL-" << PacketEnd-PacketStart << " " << endl << flush;

			try
			{
				sendto(UDPSock, (UInt8_t *)DataPacket.data(), PacketEnd-PacketStart+9, 0, (sockaddr *)&saddr, len);
			}
			catch(Exception &e)
			{
				cout << "Error in sending DataPacket..." << endl << flush;
			}

			usleep(3000);

			// Clear all previous DataPacket data
			DataPacket.clear();
			DataPacket.shrink_to_fit();
		}
		FrameCnt++;
		cout << endl;

		FrameBuff.clear();
		FrameBuff.shrink_to_fit();



		if(DisplayFrameFlag == true)
		{
			imshow("IP Card - " + to_string((UInt32_t)MissileID), VideoFrame);
			if(waitKey(1) == 'q')
			{
				ProcessThreadFlag = false;
				VideoStreamThreadFlag = false;
				break;
			}
		}

		if(SaveDataFlag == true)
		{
			OutVid.write(VideoFrame);
		}
	}

	close(UDPSock);
	OutVid.release();

	return;
}


// ---------- Read Frames Thread ----------
void * Seeker :: ReadFramesThread(void *args)
{
	Seeker *Instance = static_cast<Seeker *>(args);

	Instance->ReadFrames();

	pthread_exit(NULL);
	return nullptr;
}


// ---------- Video Stream Thread ----------
void * Seeker :: VideoStreamThread(void *args)
{
	Seeker *Instance = static_cast<Seeker *>(args);

	Instance->VideoStream();

	pthread_exit(NULL);
	return nullptr;
}




