// ============================================================================
// Name		: AppTimer.cpp
// Date		: Oct 27, 2025
// ============================================================================


// ---------- Header Inclusion ----------
#include "AppTimer.h"


// ---------- Constructor ----------
AppTimer :: AppTimer(void)
{
	return;
}


// ---------- Destructor ----------
AppTimer :: ~AppTimer(void)
{
	return;
}


// ---------- Check Leap Year ----------
bool AppTimer :: isLeapYear(UInt16_t year)
{
	return (((year % 4U == 0U) && (year % 100U != 0U)) || (year % 400U == 0U));
}


// ---------- Find Days in Month ----------
UInt8_t AppTimer :: daysInMonth(UInt8_t month, UInt16_t year)
{
    static const UInt8_t days[12] = {31U, 28U, 31U, 30U, 31U, 30U, 31U, 31U, 30U, 31U, 30U, 31U};

    if(month == 2U && isLeapYear(year))
    {
    	return 29U;
    }

    return days[month - 1];
}


// ---------- Timer Function ----------
void AppTimer :: Timer(void)
{
	struct _TimeDate_ t;
	struct timespec next;
	clock_gettime(CLOCK_MONOTONIC, &next);

	while(AppTimerThreadFlag == true)
	{
		next.tv_nsec += 1'000'000; // +1 ms
		if(next.tv_nsec >= 1'000'000'000)
		{
			next.tv_nsec -= 1'000'000'000;
			next.tv_sec++;
		}

		clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, nullptr);

		t = AppTime.load();
		t.millis++;

		if(t.millis >= 86400000U)
		{
			t.millis = 0U;
			t.day++;

			if(t.day > daysInMonth(t.month, t.year))
			{
				t.day = 1U;
				t.month++;
				if(t.month > 12U)
				{
				t.month = 1U;
				t.year++;
				}
			}
		}

		AppTime.store(t, memory_order_relaxed);
	}

	return;
}


// ---------- Timer Thread ----------
void * AppTimer :: TimerThread(void *args)
{
	AppTimer *Instance = static_cast<AppTimer *>(args);

	Instance->Timer();

	pthread_exit(NULL);
	return nullptr;
}


// ---------- Get Current Time ----------
struct _TimeDate_ AppTimer :: GetCurrTime(void)
{
    return AppTime.load(memory_order_relaxed);
}


// ---------- Get Current Time in MilliSeconds ----------
UInt32_t AppTimer :: GetCurrMillis(void)
{
	struct _TimeDate_ t = AppTime.load(memory_order_relaxed);
	return t.millis;
}


// ---------- Get Current TimeStamp ----------
string AppTimer :: GetTimeStamp(void)
{
	_TimeDate_ t;
    stringstream ss;
	UInt16_t Millis;
	UInt8_t Sec, Min, Hr;

	t = AppTime.load(memory_order_relaxed);

	Hr = t.millis / 3600000U;
	Min = (t.millis % 3600000U) / 60000U;
	Sec = (t.millis % 60000U) / 1000U;
	Millis = t.millis % 1000U;

    ss << setfill('0') << setw(2) << (UInt16_t)t.day << "/" << setw(2) << (UInt16_t)t.month << "/" << setw(4) << t.year << " " << setw(2) << (UInt16_t)Hr << ":" << setw(2) << (UInt16_t)Min << ":" << setw(2) << (UInt16_t)Sec << "." << setw(3) << Millis;
    return ss.str();
}


// ---------- Update Time ----------
void AppTimer ::  UpdateTime(UInt8_t day, UInt8_t month, UInt16_t year, UInt32_t millis)
{
	_TimeDate_ t;

	t = AppTime.load(memory_order_relaxed);

	t.day = day;
	t.month = month;
	t.year = year;
	t.millis = millis;

	AppTime.store(t, memory_order_relaxed);

	return;
}




