//============================================================================
// Name			: IPCard-V1.5.0.cpp
// Author		: Solar Industries
// Version		: V01.05.00
// Released On  : 28 Oct 2025
//============================================================================


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "SysConfig.h"

#include "Seeker.h"
#include "AppTimer.h"
#include "CamRS422.h"
#include "ObcRS422.h"
#include "ObjDetection.h"



// ---------- IPCard Status Variables ----------
bool NUCStatus = false;
bool IPAddrStatus = false;
bool SeekerStatus = false;
bool AIStatusFlag = false;
bool ObcPortStatus = true;
bool CamPortStatus = true;


// ---------- Other Flag Variables ----------
bool ObcCmdFlag = false;
bool SaveDataFlag = false;
bool SDCardSaveFlag = false;
bool DisplayFrameFlag = false;


// ---------- AI Flag Variables ----------
bool TargetDataFlag = false;
bool DetectObjectFlag = false;
bool BirdPlaneDataFlag = false;


// ---------- Thread Flag Variables ----------
bool ObcRecvThreadFlag = true;
bool ObcDataThreadFlag = true;
bool ProcessThreadFlag = true;
bool AppTimerThreadFlag = true;
bool VideoStreamThreadFlag = true;
bool CamHandShakeThreadFlag = true;


// ---------- Software Details ----------
UInt16_t SW_CheckSum = 0U;
string SW_Health = "28/10/25 V01.05.00";	// DD/MM/YY V01.00.00


// ---------- Config Parameters ----------
UInt8_t MissileID = 1U;
string EthInterface = "";

// Data Link Configurations
Int8_t DL_IPAddr[16];
Int32_t DL_UDPPort;

// IP Card Configurations
Int8_t IP_IPAddr[16] = "127.0.0.1";
Int8_t NetMask_Addr[16] = "255.255.255.0";
Int8_t GateWay_Addr[16] = "127.0.0.1";


// ---------- Camera Variables ----------
string VideoSource;
UInt32_t VideoFPS = 25U;
Size VideoDim(640, 480);
UInt32_t FrameDelay = (1000U * 1000U) / VideoFPS;	// in MicroSeconds


// ---------- AI Parameters ----------
string ModelPath = "";
Int16_t ROILoc[2] = {320, 240};			// Ny, Nz
UInt16_t ROIDim[2] = {640, 480};		// Width, Height
string ClassName[4] = {"Bird", "Fixed", "Hexa", "Plane"};

struct _TargetData_ TargetData;
//steady_clock :: time_point DataTime;


// ---------- Data Path ----------
string LoadPath = "";
string SavePath = "";
string ParentPath = "";


// ---------- Video & Processed Data Variables ----------
struct _VideoData_ CameraData;
struct _VideoData_ ProcessedData;


// ---------- Class Objects ----------
Seeker *SeekerObj;
AppTimer *AppTimerObj;
CamRS422 *CamRS422Obj;
ObcRS422 *ObcRS422Obj;
ObjDetection *ObjDetectionObj;










int main(Int32_t argc, Int8_t *argv[])
{
	UInt8_t DetectionCnt = 0;
	struct _VideoData_ VideoData;

	pthread_t ObcRecvThread;
	pthread_t ObcDataThread;
	pthread_t AppTimerThread;
	pthread_t ReadFramesThread;
	pthread_t VideoStreamThread;
	pthread_t CamHandShakeThread;

	struct timespec ts;
	UInt32_t timCntStart, timCntEnd, totalTime;

	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 10;		// 10 microseconds

	// Register force stop for CNTL+C
	signal(SIGINT, (void(*)(Int32_t))forceStop);

	SW_CheckSum = getSwCheckSum(getPath(0));

	cout << "Software Details  : " << SW_Health << endl;
	cout << "Software Checksum : 0x" << hex << uppercase << SW_CheckSum << dec << endl;

	// Set load path for the files
	LoadPath = getPath(1);

	// Load config file
	loadConfigData();

	// Check user flags
	checkFlags(argc, argv);

	// Set Saving path for results
	if(SaveDataFlag == true)
	{
		SavePath = getPath(2);
	}

	AppTimerObj = new AppTimer;

	// Start APP Timer Thread
	if(pthread_create(&AppTimerThread, NULL, AppTimerObj->TimerThread, AppTimerObj))
	{
		perror("pthread_create");
		exit(1);
	}

	ObcRS422Obj = new ObcRS422();
	CamRS422Obj = new CamRS422();

	if(ObcPortStatus == true)
	{
		// Start RS422 OBC Receiving Thread
		if(pthread_create(&ObcRecvThread, NULL, ObcRS422Obj->ObcRecvThread, ObcRS422Obj))
		{
			perror("pthread_create");
			delete AppTimerObj;
			delete ObcRS422Obj;
			delete CamRS422Obj;
			exit(1);
		}

		// Start Sending Target Data to Obc
		if(pthread_create(&ObcDataThread, NULL, ObcRS422Obj->ObcDataThread, ObcRS422Obj))
		{
			perror("pthread_create");
			delete AppTimerObj;
			delete ObcRS422Obj;
			delete CamRS422Obj;
			exit(1);
		}
	}

	if(CamPortStatus == true)
	{
		// Start Camera Handshaking Thread
		if(pthread_create(&CamHandShakeThread, NULL, CamRS422Obj->CamHandShakeThread, CamRS422Obj))
		{
			perror("pthread_create");
			delete AppTimerObj;
			delete ObcRS422Obj;
			delete CamRS422Obj;
			exit(1);
		}
	}


	ObjDetectionObj = new ObjDetection();

	// Check for IP Address && Camera Handshake
	while(IPAddrStatus == false || SeekerStatus == false)
	{
		usleep(10 * 1000);
	}

	SeekerObj = new Seeker();

	// Start RS422 OBC Receiving Thread
	if(pthread_create(&ObcRecvThread, NULL, SeekerObj->VideoStreamThread, SeekerObj))
	{
		perror("pthread_create");
		delete SeekerObj;
		delete AppTimerObj;
		delete ObcRS422Obj;
		delete CamRS422Obj;
		delete ObjDetectionObj;
		exit(1);
	}

	// Start Sending Target Data to Obc
	if(pthread_create(&ObcDataThread, NULL, SeekerObj->ReadFramesThread, SeekerObj))
	{
		perror("pthread_create");
		delete SeekerObj;
		delete AppTimerObj;
		delete ObcRS422Obj;
		delete CamRS422Obj;
		delete ObjDetectionObj;
		exit(1);
	}

	cout << endl << endl;

	// Main while loop
	while(ProcessThreadFlag == true)
	{
		if(CameraData.FrameFlag == false)
		{
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
			continue;
		}

		// Start measuring execution time
		timCntStart = AppTimerObj->GetCurrMillis();

		VideoData.VideoFrame.release();
		VideoData = CameraData;
		CameraData.FrameFlag = false;


		// Detect objects
		if(DetectionCnt < 10 || DetectObjectFlag == true)
		{
			VideoData.AIStartTime = AppTimerObj->GetCurrMillis();
			ObjDetectionObj->RunEnqueueV2(VideoData.VideoFrame);

			TargetData.FrameTime = VideoData.FrameTime;
			TargetData.AIStartTime = VideoData.AIStartTime;
			TargetData.AIEndTime = AppTimerObj->GetCurrMillis();
			TargetDataFlag = true;
		}
		if(DetectionCnt <= 15)
		{
			DetectionCnt++;
		}

		// Update Data for VideoStream, Saving & Display
		ProcessedData.VideoFrame.release();
		ProcessedData = VideoData;
		ProcessedData.FrameFlag = true;

		// Stop Measuring execution time
		timCntEnd =  AppTimerObj->GetCurrMillis();

		// Calculate the reading & sleep time in milliseconds
		totalTime = (timCntEnd < timCntStart) ? ((86400000U + timCntEnd) - timCntStart) : (timCntEnd - timCntStart);

		cout << endl << "Total Process Time - " << totalTime << " ms" << endl << flush;
	}


	// Clear all the flags
	ObcRecvThreadFlag = false;
	ObcDataThreadFlag = false;
	ProcessThreadFlag = false;
	AppTimerThreadFlag = false;
	VideoStreamThreadFlag = false;
	CamHandShakeThreadFlag = false;

	destroyAllWindows();
	usleep(1000 * 10);

	// Try to Join Threads
	try
	{
		pthread_cancel(ObcRecvThread);
		pthread_cancel(ObcDataThread);
		pthread_cancel(AppTimerThread);
		pthread_cancel(ReadFramesThread);
		pthread_cancel(VideoStreamThread);
		pthread_cancel(CamHandShakeThread);
	}
	catch(Exception &e)
	{
		cout << "Error : " << e.what() << endl;
	}

	// delete all the objects
	try
	{
		delete SeekerObj;
		delete AppTimerObj;
		delete ObcRS422Obj;
		delete CamRS422Obj;
		delete ObjDetectionObj;
	}
	catch(Exception &e)
	{
		cout << "Error : " << e.what() << endl;
	}

	cout << "Terminated Successfully..." << endl << flush;
	return 0;
}




