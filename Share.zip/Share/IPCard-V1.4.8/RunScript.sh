#============================================================================
# Name        : RunScript.sh
# Author      : Solar Industries
# Date		  : 10 Sep 2025
#============================================================================

#!/bin/bash

# Enable Stress Mode & Clock
# sudo nvpmodel -m 2
# sudo jetson_clocks

# Clear Previous RAM, Caches & kill previous Process
sudo pkill Exe-IPCard
sudo sync && echo 3 | sudo tee /proc/sys/vm/drop_caches

FLAG_S=false
FLAG_SD=false

# -SD Flag in CMD line Args
for arg in "$@"; do
	case  "$arg" in

	-S)
	FLAG_S=true
	;;

	-SD)
	FLAG_SD=true
	;;

	esac

done


# Get absolute path to the script and its executable
EXE_DIR=$(dirname "$(realpath "$0")")


if ! $FLAG_S; then
	# Run the executable
	sudo LD_LIBRARY_PATH=/usr/local/opencv4_gpu/lib "$EXE_DIR"/Exe-IPCard -CR "$@" & program_pid=$!

else
	# Get current date like 06Dec24
	DATE=$(date +"%d%b%y")
	
	# Result directory
	if $FLAG_SD; then RES_DIR="/mnt/sdcard/IPData/Res/$DATE"
	else RES_DIR="$EXE_DIR/Res/$DATE"
	fi
	
	# Create the result directory if it dosent exists
	mkdir -p -m 775 "$RES_DIR"
	
	# Determine the next available test directory
	TEST_NUM=$(ls -d "$RES_DIR"/Test* 2>/dev/null | grep -oP 'Test\K[0-9]+' | sort -nr | head -n1)
	
	if [ -z "$TEST_NUM" ]; then TEST_NUM=0
	else TEST_NUM=$((TEST_NUM + 1))
	fi
	
	# Create the new test directory
	TEST_DIR="$RES_DIR/Test$TEST_NUM"
	mkdir -p -m 775 "$TEST_DIR"
	
	# Define the output log file
	LOG_FILE="$TEST_DIR/RunLog.txt"
	
	# Add Run Time in File
	CURR_TIME=$(date +"%d-%m-%Y %H:%M:%S")
	echo Test Running Time - "$CURR_TIME" >> "$LOG_FILE"
	echo "" >> "$LOG_FILE"
	
	echo Test Running Time - "$CURR_TIME"
	echo ""
	
	# Run the executable
	sudo LD_LIBRARY_PATH=/usr/local/opencv4_gpu/lib stdbuf -oL "$EXE_DIR"/Exe-IPCard -CR -PT "$TEST_DIR/" "$@" 2>&1 | tee -a "$LOG_FILE" & program_pid=$!

fi

handle_sigint() {
	echo "Script Received SIGINT"
	kill -SIGINT "$program_pid"
	wait "$program_pid"
	
	if $FLAG_S; then echo "Output has been saved to : $TEST_DIR"
	else echo "Output Not Saved"
	fi
	
	exit 0
}
trap 'handle_sigint' SIGINT

wait $program_pid

if $FLAG_S; then echo "Output has been saved to : $TEST_DIR"
else echo "Output Not Saved"
fi




