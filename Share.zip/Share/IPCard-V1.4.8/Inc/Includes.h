// ============================================================================
// Name        : Includes.h
// Created On  : 10 Sep 2025
// ============================================================================


#ifndef INCLUDES_H_
#define INCLUDES_H_


// ---------- Header Inclusion ----------
#include <mutex>
#include <regex>
#include <atomic>
#include <chrono>
#include <fstream>
#include <iostream>

#include <elf.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <ifaddrs.h>
#include <termios.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>

#include <nlohmann/json.hpp>

// Warning Depecrartion
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"


// CUDA & TensorRT Includes
#include <memory>
#include <numeric>
#include <NvInfer.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <NvInferRuntime.h>
#include <device_launch_parameters.h>

// OpenCV GPU Includes
#include <opencv2/dnn.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/cudawarping.hpp>
#include <opencv2/cudaarithm.hpp>
#include <opencv2/cudaimgproc.hpp>
#include <opencv2/core/cuda_stream_accessor.hpp>


// ---------- Namespace ----------
using namespace cv;
using namespace std;
using namespace nvinfer1;
using json = nlohmann::json;
using namespace std::chrono;

#pragma GCC diagnostic pop


// ---------- Header Inclusion ----------
#include "DataTypes.h"


#endif /* INCLUDES_H_ */




