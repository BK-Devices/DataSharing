// ============================================================================
// Name		: SysConfig.h
// Date		: Oct 27, 2025
// ============================================================================


#ifndef SYSCONFIG_H_
#define SYSCONFIG_H_


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"

#include "AppTimer.h"



// ---------- IPCard Status Variables ----------
extern bool NUCStatus;
extern bool IPAddrStatus;
extern bool SeekerStatus;

// ---------- Other Flag Variables ----------
extern bool ObcCmdFlag;
extern bool SaveDataFlag;
extern bool SDCardSaveFlag;
extern bool DisplayFrameFlag;

// ---------- AI Flag Variables ----------
extern bool DetectObjectFlag;
extern bool BirdPlaneDataFlag;

// ---------- Thread Flag Variables ----------
extern bool ObcRecvThreadFlag;
extern bool ObcDataThreadFlag;
extern bool ProcessThreadFlag;
extern bool AppTimerThreadFlag;
extern bool VideoStreamThreadFlag;
extern bool CamHandShakeThreadFlag;

// ---------- Config Parameters ----------
extern UInt8_t MissileID;
extern string EthInterface;

// Data Link Configurations
extern Int8_t DL_IPAddr[16];
extern Int32_t DL_UDPPort;

// IP Card Configurations
extern Int8_t IP_IPAddr[16];
extern Int8_t NetMask_Addr[16];
extern Int8_t GateWay_Addr[16];


// ---------- Camera Variables ----------
extern string VideoSource;

// ---------- AI Parameters ----------
extern string ModelPath;

// ---------- Data Path ----------
extern string LoadPath;
extern string SavePath;
extern string ParentPath;

// ---------- Class Objects ----------
extern AppTimer *AppTimerObj;






// ---------- Force stop function for CNTL+C ----------
void forceStop([[maybe_unused]]Int32_t Signal);

// ---------- Validate Integer ----------
bool validateInt(Int8_t *str);

// ---------- Validate IP Address ----------
bool validateIP(const Int8_t *Addr);

// ---------- Validate Port Number ----------
Int32_t validatePORT(Int8_t *Port);

// ---------- Check User Flags ----------
void checkFlags(Int32_t argc, Int8_t *argv[]);

// ---------- CRC16 function ----------
UInt16_t crc16(UInt8_t *Data, UInt64_t Len);

// ---------- Calculate software checksum ----------
UInt16_t getSwCheckSum(string Path);

// ---------- Create Path ----------
string createPath(string Path, UInt8_t Mode);

// ---------- Get Path ----------
string getPath(UInt8_t typ);

// ---------- readFile ----------
string readFile(string path);

// ---------- load Config file Data ----------
void loadConfigData(void);
































#endif /* SYSCONFIG_H_ */




