// ============================================================================
// Name		: Seeker.h
// Date		: Oct 27, 2025
// ============================================================================


#ifndef SEEKER_H_
#define SEEKER_H_


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "AppTimer.h"
#include "ObcRS422.h"


// ---------- IPCard Status Variables ----------
extern bool SeekerStatus;
extern bool ObcPortStatus;


// ---------- Other Flag Variables ----------
extern bool SaveDataFlag;
extern bool DisplayFrameFlag;


// ---------- Thread Flag Variables ----------
extern bool ProcessThreadFlag;
extern bool VideoStreamThreadFlag;


// ---------- Config Parameters ----------
extern UInt8_t MissileID;

// Data Link Configurations
extern Int8_t DL_IPAddr[16];
extern Int32_t DL_UDPPort;


// ---------- Camera Variables ----------
extern string VideoSource;
extern UInt32_t VideoFPS;
extern Size VideoDim;
extern UInt32_t FrameDelay;


// ---------- Data Path ----------
extern string SavePath;


// ---------- Video & Processed Data Variables ----------
extern struct _VideoData_ CameraData;
extern struct _VideoData_ ProcessedData;


// ---------- Class Objects ----------
extern AppTimer *AppTimerObj;
extern ObcRS422 *ObcRS422Obj;


// ---------- Class Declaration ----------
class Seeker
{
private:
	VideoCapture CAM;
	VideoWriter OutVid;

	UInt32_t len;
	Int32_t UDPSock;
	struct sockaddr_in saddr;

public:
	// Constructor
	Seeker(void);

	// Destructor
	~Seeker(void);

	// Read Frames
	void ReadFrames(void);

	// Video Stream
	void VideoStream(void);

	// Read Frames Thread
	static void *ReadFramesThread(void *args);

	// Video Stream Thread
	static void *VideoStreamThread(void *args);
};


#endif /* SEEKER_H_ */




