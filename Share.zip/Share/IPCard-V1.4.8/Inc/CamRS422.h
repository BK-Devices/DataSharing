// ============================================================================
// Name		: CamRS422.h
// Date		: Oct 27, 2025
// ============================================================================


#ifndef CAMRS422_H_
#define CAMRS422_H_


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"


// ---------- IPCard Status Variables ----------
extern bool NUCStatus;
extern bool SeekerStatus;


// ---------- Other Flag Variables ----------
extern bool CamPortStatus;


// ---------- Thread Flag Variables ----------
extern bool CamHandShakeThreadFlag;


// ---------- Class Declaration ----------
class CamRS422
{
private:
	struct termios tty;
	Int32_t SerialPort;
	Int8_t rxBuff[10], Bytes;

public:
	// Constructor
	CamRS422(void);

	// Destructor
	~CamRS422(void);

	// HandShake
	bool HandShake(void);

	// Nuc 1PT
	bool Nuc_1PT(void);

	// HandShake Thread
	static void *HandShakeThread(void *args);
};


#endif /* CAMRS422_H_ */




