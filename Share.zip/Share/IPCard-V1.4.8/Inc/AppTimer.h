// ============================================================================
// Name		: AppTimer.h
// Date		: Oct 27, 2025
// ============================================================================


#ifndef APPTIMER_H_
#define APPTIMER_H_


// ---------- Header Inclusion ----------
#include "Includes.h"
#include "Struct.h"

// ---------- Thread Flag Variables ----------;
extern bool AppTimerThreadFlag;


// ---------- Class Declaration ----------
class AppTimer
{
private:
	atomic<struct _TimeDate_> AppTime;

public:
	// Constructor
	AppTimer(void);

	// Destructor
	~AppTimer(void);

	// Check Leap Year
	bool isLeapYear(UInt16_t year);

	// Find Days in Month
	UInt8_t daysInMonth(UInt8_t month, UInt16_t year);

	// Timer Function
	void Timer(void);

	// Timer Thread
	static void *TimerThread(void *args);

	// Get Current Time
	struct _TimeDate_ GetCurrTime(void);

	// Get Current Time in MilliSeconds
	UInt32_t GetCurrMillis(void);

	// Get Current TimeStamp
	string GetTimeStamp(void);

	// Update Time
	void UpdateTime(UInt8_t day, UInt8_t month, UInt16_t year, UInt32_t millis);
};


#endif /* APPTIMER_H_ */




