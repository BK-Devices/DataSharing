#include <iostream>

#include <atomic>
#include <chrono>
#include <iomanip>
#include <sstream>

#include <sched.h>
#include <unistd.h>
#include <pthread.h>

#include "DataTypes.h"

using namespace std;
using namespace std::chrono;


struct _TimeDate_
{
	UInt8_t day;			// 1 to 31
	UInt8_t month;			// 1 to 12
	UInt16_t year;			// 1 to ....
	UInt32_t millis;		// 0 to 86,399,999

	_TimeDate_(void)
	{
		day = 1;
		month = 1;
		year = 2025;
		millis = 0;

		return;
	}

	_TimeDate_(UInt8_t day, UInt8_t month, UInt16_t year, UInt32_t millis)
	{
		this->day = day;
		this->month = month;
		this->year = year;
		this->millis = millis;

		return;
	}
};

// Global App Timer
atomic<_TimeDate_> AppTime;


bool isLeapYear(UInt16_t year)
{
	return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}


UInt8_t daysInMonth(UInt8_t month, UInt16_t year)
{
    static const UInt8_t days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if(month == 2 && isLeapYear(year))
    {
    	return 29;
    }

    return days[month - 1];
}


void *appTimerThread(void *args)
{
#if 0

    _TimeDate_ t;
    milliseconds elapsed;
    steady_clock::time_point prev, now;

    prev = steady_clock::now();

    while(true)
    {
        now = steady_clock::now();
        elapsed = duration_cast<milliseconds>(now - prev);

        if(elapsed.count() >= 1)
        {
            prev += milliseconds(1);

            t = AppTime.load();
            t.millis++;

            if(t.millis >= 86400000)
            {
                t.millis = 0;
                t.day++;

                if(t.day > daysInMonth(t.month, t.year))
                {
                    t.day = 1;
                    t.month++;
                    if(t.month > 12)
                    {
                        t.month = 1;
                        t.year++;
                    }
                }
            }

            AppTime.store(t, memory_order_relaxed);
        }
        // sched_yield();
    }

    pthread_exit(NULL);
    return nullptr;

#endif


#if 1
    _TimeDate_ t;
    struct timespec next;
    clock_gettime(CLOCK_MONOTONIC, &next);

    while(true)
    {
        next.tv_nsec += 1'000'000; // +1 ms
        if(next.tv_nsec >= 1'000'000'000)
        {
            next.tv_nsec -= 1'000'000'000;
            next.tv_sec++;
        }

        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, nullptr);

        t = AppTime.load();
        t.millis++;

        if(t.millis >= 86400000)
        {
            t.millis = 0;
            t.day++;

            if(t.day > daysInMonth(t.month, t.year))
            {
                t.day = 1;
                t.month++;
                if(t.month > 12)
                {
                t.month = 1;
                t.year++;
                }
            }
        }

        AppTime.store(t, memory_order_relaxed);
    }

    pthread_exit(NULL);
    return nullptr;
#endif

}


_TimeDate_ getCurrTime(void)
{
    return AppTime.load(memory_order_relaxed);
}


UInt32_t getCurrMillis(void)
{
	_TimeDate_ t = getCurrTime();
	return t.millis;
}


string getTimeStamp(void)
{
	_TimeDate_ t;
    stringstream ss;
	UInt16_t Millis;
	UInt8_t Sec, Min, Hr;

	t = getCurrTime();

	Hr = t.millis / 3600000;
	Min = (t.millis % 3600000) / 60000;
	Sec = (t.millis % 60000) / 1000;
	Millis = t.millis % 1000;

    ss << setfill('0') << setw(2) << (UInt16_t)t.day << "/" << setw(2) << (UInt16_t)t.month << "/" << setw(4) << t.year << " " << setw(2) << (UInt16_t)Hr << ":" << setw(2) << (UInt16_t)Min << ":" << setw(2) << (UInt16_t)Sec << "." << setw(3) << Millis;
    return ss.str();
}


int main()
{
    // Initialize AppTime
    AppTime.store({26, 10, 2025, 0});

    // Create pthread for timer
    pthread_t timerThread;
    pthread_create(&timerThread, nullptr, appTimerThread, nullptr);
    pthread_detach(timerThread);

    cout << "App timer started....\n";
    cout << "Start: " << getTimeStamp() << endl;

    sleep(1);

    cout << "Tim1: " << getTimeStamp() << endl;

    usleep(10000);

    cout << "Tim2: " << getTimeStamp() << endl;

    sleep(1);

	cout << "Tim3: " << getTimeStamp() << endl;

	usleep(264999);

	cout << "Tim4: " << getTimeStamp() << endl;

    return 0;
}




